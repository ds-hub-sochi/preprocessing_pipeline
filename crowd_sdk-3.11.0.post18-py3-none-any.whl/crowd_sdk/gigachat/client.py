import logging
from typing import Any, AsyncGenerator, Dict, Generator, Iterable, List, Optional

from dacite import from_dict
from tqdm.auto import tqdm

from crowd_sdk.core.utils.aiopool import AIOPool
from crowd_sdk.core.utils.common import urljoin_with_path
from crowd_sdk.core.utils.http import http

from .config import GC_TIMEOUT, GigaChatConfig
from .datacls import DevicesChatResponse, Message, RoleType  # pylint: disable=W0611

# need to simplofy imports

logger = logging.getLogger(__file__)


def prepare_json(
    model: str,
    params: Dict,
    messages: List[Message],
    stream: Optional[bool] = None,
) -> dict:
    data = params
    data["profanity"] = False
    data["model"] = model
    data["messages"] = [_.asdict() for _ in messages]
    if stream is not None:
        data["stream"] = stream
    return data


class ChatClient:
    def __init__(self, config: GigaChatConfig) -> None:
        self.config: GigaChatConfig = config

    @staticmethod
    def __add_start_prompt(
        start_prompts: Iterable[Message], messages: List[List[Message]]
    ) -> Generator[List[Message], None, None]:
        for message in messages:
            message = list(start_prompts) + message
            yield message

    async def chat_completion(
        self, _messages: List[Message], temperature: Optional[float] = None, model: Optional[str] = None
    ) -> Optional[DevicesChatResponse]:
        raise NotImplementedError

    async def chat_completion_batch(
        self, chats: List[List[Message]], start_prompts: Iterable[Message] = (), tqdm_off: bool = False
    ) -> AsyncGenerator[DevicesChatResponse, Any]:
        with AIOPool(workers=self.config.n_threads) as pool:
            async for result in tqdm(
                pool.map_async(self.chat_completion, self.__add_start_prompt(start_prompts, chats)),
                total=len(chats),
                disable=tqdm_off,
            ):
                yield result


class GigaChatClient(ChatClient):
    async def get_models(self) -> dict:
        url = urljoin_with_path(self.config.base_url, "/models")
        if self.config.token:
            headers = {"Authorization": "Bearer " + self.config.token}
        else:
            headers = {}
        response = await http.get(
            url=url,
            headers=headers,
            timeout=GC_TIMEOUT,
            verify_ssl=False,
        )
        response = await response.json()
        return response

    async def chat_completion(
        self, messages: List[Message], temperature: Optional[float] = None, model: Optional[str] = None
    ) -> DevicesChatResponse:
        model = model or self.config.model
        params = self.config.params.asdict(ignore_none=True)

        if temperature is not None:
            params['temperature'] = temperature
        logger.debug("Params: %s", params)
        logger.debug("Messages: %s", messages)

        if self.config.raw_api:
            url = urljoin_with_path(self.config.base_url, "/chat")
        else:
            url = urljoin_with_path(self.config.base_url, "/chat/completions")
        data = prepare_json(model=model, params=params, messages=messages, stream=False)
        if self.config.token:
            headers = {"Authorization": "Bearer " + self.config.token}
        else:
            headers = {}
        response = await http.post(
            url=url,
            data=None,
            json=data,
            headers=headers,
            timeout=GC_TIMEOUT,
            verify_ssl=False,
        )
        if response.status < 200 or response.status >= 300:
            raise RuntimeError(f'Failed to do chat_completion: {response.status} {response.text}')
        response = await response.json()
        if response is not None:
            return from_dict(data_class=DevicesChatResponse, data=response)
        raise ValueError(f'response is none for {messages}')

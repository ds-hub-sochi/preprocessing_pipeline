from dataclasses import dataclass
from enum import Enum
from typing import Optional


@dataclass
class TaskQuality:
    uid: str
    name: str
    items_count: int
    quality: Optional[float]
    consistency: Optional[float]
    reward: float
    complete_data: bool = True


@dataclass
class ItemQuality:
    uid: str
    task_id: str
    quality: Optional[float]
    consistency: float
    reward: Optional[float]
    complete_data: bool = True


class StatsOutputType(Enum):
    TASK = 'task'
    ITEM = 'item'

import json
import logging
from typing import Any, Dict, List

import click
import pandas as pd

from crowd_sdk.core.utils.common import get_event_loop
from crowd_sdk.gigachat.client import GigaChatClient, GigaChatConfig, Message, RoleType
from crowd_sdk.tagme import DEFAULT_CONFIG
from crowd_sdk.tagme.cli.group import tagme_commands

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def make_text_batches(results: pd.Series) -> List[str]:
    result: List[str] = []
    for item in results:
        if pd.isnull(item):
            continue
        if len(result) == 0 or len(result) + len(item) >= 2000:
            result.append('')
        if not pd.isna(item) and len(item) > 0:
            result[-1] += f'\n{item}'
    return result


class Summarizer:
    def __init__(self, gigachat_client: GigaChatClient):
        self._client = gigachat_client

    async def summarize(self, text: str) -> str:
        chat = [
            Message(
                role=RoleType.SYSTEM.value,
                content="Ты умный ассистент который умеет суммаризировать отзывы пользователей.",
            ),
            Message(role=RoleType.USER.value, content=f'Суммаризируй отзывы пользователей:\n{text}'),
        ]
        response = await self._client.chat_completion(chat)
        logger.info(f'Gigachat response: {response}')
        return response.choices[0].message.content

    async def summarize_texts(self, left: str, right: str) -> str:
        return await self.summarize(text=f'{left}\n{right}')


async def summarize_surveys(survey_results: pd.DataFrame, gigachat_client: GigaChatClient, output: str) -> None:
    columns_names = survey_results.columns.values
    numeric_columns: List[str] = []
    string_columns: List[str] = []
    for name in columns_names:
        if 'OUTPUT' not in name:
            continue
        if pd.api.types.is_numeric_dtype(survey_results[name]) or pd.api.types.is_float_dtype(survey_results[name]):
            numeric_columns.append(name)
        elif pd.api.types.is_object_dtype(survey_results[name]):
            string_columns.append(name)
    result: Dict[str, Any] = {}
    summarizer = Summarizer(gigachat_client)
    for column_name in string_columns:
        column_batched = await make_text_batches(survey_results[column_name])
        column_mapped = [await summarizer.summarize(item) for item in column_batched]
        reduced = column_mapped[0]
        for item in column_mapped[1:]:
            reduced = await summarizer.summarize_texts(reduced, item)
        result[column_name] = {'summarization': reduced}

    for column_name in numeric_columns:
        result[column_name] = {
            'mean': survey_results.loc[:, column_name].mean(),
            'var': survey_results.loc[:, column_name].var(),
            'csi': (survey_results.loc[:, column_name] == 5.0).sum() / survey_results.loc[:, column_name].count(),
        }

    with open(output, 'w') as f:
        json.dump(result, f, ensure_ascii=False)


@tagme_commands.command(name='summarize_surveys')
@click.option(
    '-f',
    '--filename',
    type=click.Path(exists=True),
    help='Path to file with table with results',
)
@click.option(
    '-o',
    '--output',
    type=click.Path(exists=True),
    help='Output file',
    default='result.json',
)
@click.option(
    '-c',
    '--config-path',
    type=click.Path(exists=True),
    help='Path to TagMe .cfg file',
    default=DEFAULT_CONFIG,
)
def survey_summarizer_cli(filename: str, config_path: str, output: str) -> None:
    survey_results = pd.read_excel(filename)
    gigachat_config = GigaChatConfig.from_path(config_path)
    gigachat_client = GigaChatClient(gigachat_config)
    get_event_loop().run_until_complete(summarize_surveys(survey_results, gigachat_client, output))

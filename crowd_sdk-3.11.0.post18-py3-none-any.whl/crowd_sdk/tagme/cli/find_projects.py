import asyncio
import csv
import logging.config
from dataclasses import dataclass
from itertools import chain
from pathlib import Path
from typing import Any, Dict, List, Union

import click

from crowd_sdk.core.utils.common import chunks, get_event_loop
from crowd_sdk.core.utils.http_client import APIResponseError
from crowd_sdk.tagme import DEFAULT_CONFIG, TagmeClientAdvanced, TagmeConfig
from crowd_sdk.tagme.cli.group import tagme_commands
from crowd_sdk.tagme.types import Organization, Person, Project


@dataclass
class ProjectMeta:
    name: str
    author: str
    organization: str
    project: Project


async def get_projects_with_emails(
    client: TagmeClientAdvanced, organization: Organization, verbose: bool = False
) -> List[ProjectMeta]:
    projects = await client.get_projects(organization_id=organization.uid)
    person_ids = [project.person_id for project in projects]

    persons: List[Person] = []
    tqdm_on: Union[str, bool] = f'Fetching persons for organization "{organization.name}"' if verbose else bool(False)
    for person_ids_ in chunks(person_ids, 100, tqdm_on=tqdm_on):
        persons.extend(await client.get_persons(person_ids=person_ids_, organization_id=organization.uid))
    if verbose:
        logging.info(f'Successfuly fetched persons for organization "{organization.name}"')

    person_to_email = {person.uid: person.email for person in persons}
    result: List[ProjectMeta] = []
    for project in projects:
        if project.person_id not in person_to_email:
            logging.warning(f'Not found user with id {project.person_id} in organization "{organization.name}"')
            continue
        result.append(
            ProjectMeta(
                name=project.name,
                author=person_to_email[project.person_id],
                organization=organization.name,
                project=project,
            )
        )
    return result


async def get_projects(
    client: TagmeClientAdvanced, organizations: List[Organization], verbose: bool = False
) -> List[ProjectMeta]:
    result: List[ProjectMeta] = []
    for organizations_ in chunks(organizations, 5, tqdm_on='Fetching projects'):
        result.extend(
            chain(
                *(
                    await asyncio.gather(
                        *(get_projects_with_emails(client, organization, verbose) for organization in organizations_)
                    )
                )
            )
        )
    return result


def apply_predicate(project: Project, predicate: str) -> bool:  # pylint: disable=W0613
    exec_dict: Dict[str, Any] = {'project': project}
    exec(f'value = {predicate}', globals(), exec_dict)  # pylint: disable=W0122
    return exec_dict['value']


async def filter_projects_batch(
    client: TagmeClientAdvanced, projects: List[ProjectMeta], predicate: str
) -> List[ProjectMeta]:
    result: List[ProjectMeta] = []
    for project in projects:
        try:
            await client.load_project_method(project.project)
        except APIResponseError as ex:
            if ex.status == 403:
                logging.warning(f'Have not loaded method for project {project.name} (permission denied)')
                continue
            raise
        if apply_predicate(project.project, predicate):
            result.append(project)
    return result


async def filter_projects(
    client: TagmeClientAdvanced, projects: List[ProjectMeta], predicate: str
) -> List[ProjectMeta]:
    result: List[ProjectMeta] = []
    for project_ids_ in chunks(projects, 50, tqdm_on='Filtering projects'):
        result.extend(await filter_projects_batch(client, project_ids_, predicate))
    return result


def save_results(
    projects: List[ProjectMeta],
    filename: str,
) -> None:
    with open(filename, 'w') as f:
        w = csv.DictWriter(f, ('Автор', 'Проект', 'Организация'))
        w.writeheader()
        w.writerows(
            {
                'Автор': project.author,
                'Проект': project.name,
                'Организация': project.organization,
            }
            for project in projects
        )


async def find_projects_by_predicate(config: TagmeConfig, predicate: str, filename: str, verbose: bool) -> None:
    async with TagmeClientAdvanced(config) as client:
        organizations = await client.get_organizations()
        projects = await get_projects(client, organizations, verbose)
        filtered_projects = await filter_projects(client, projects, predicate)
    save_results(filtered_projects, filename)


@tagme_commands.command(name="find_projects_by_predicate")
@click.option(
    '-p',
    '--predicate',
    required=True,
    help="Predicate in Python code which depends on project of type crowd_sdk.tagme.types.Project"
    "(e.g. 'project.name == \"Tiger Segmentation\"')",
)
@click.option('-f', '--filename', required=True, type=click.Path(exists=False), help='Path to output file')
@click.option('-v', '--verbose', is_flag=True)
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
def find_projects_by_predicate_cli(predicate: str, config_path: Union[str, Path], filename: str, verbose: bool) -> None:
    config = TagmeConfig.from_any(config_path)
    config.prompt_user_and_password_if_missing()
    get_event_loop().run_until_complete(find_projects_by_predicate(config, predicate, filename, verbose))

from typing import Callable

import click


@click.group()
def tagme_commands() -> Callable:
    pass

import logging
from typing import Optional

import click

from crowd_sdk.core.utils.common import get_event_loop
from crowd_sdk.tagme import DEFAULT_CONFIG, TagmeClientAdvanced, TagmeConfig
from crowd_sdk.tagme.cli.group import tagme_commands

logger = logging.getLogger(__name__)


async def download_task_data(
    config: TagmeConfig, task_id: str, destination_dir: str, organization_id: Optional[str] = None
) -> None:
    async with TagmeClientAdvanced(config=config) as client:
        await client.download_task_data(
            task_id=task_id,
            destination_dir=destination_dir,
            organization_id=organization_id,
        )


async def download_dataset_data(
    config: TagmeConfig, dataset_id: str, destination_dir: str, organization_id: Optional[str] = None
) -> None:
    async with TagmeClientAdvanced(config=config) as client:
        await client.download_dataset_data(
            dataset_id=dataset_id,
            destination_dir=destination_dir,
            organization_id=organization_id,
        )


@tagme_commands.command(name='download_src_dir')
@click.option('-d', '--destination-dir', required=True, help='Destination directory to save source dataset')
@click.option('-t', '--task-id', required=True, help='Task identifier')
@click.option('-o', '--organization-name', required=False, help='Organization key')
@click.option('--organization-id', required=False, help='Organization id')
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
def download_task_data_cli(
    destination_dir: str,
    task_id: str,
    config_path: str,
    organization_name: Optional[str],
    organization_id: Optional[str],
) -> None:
    """
    Download dataset (as files) from task to specified directory
    """
    config = TagmeConfig.cli_initialize(config_path, organization_name, organization_id)
    file_count = get_event_loop().run_until_complete(
        download_task_data(config, task_id, destination_dir, organization_id)
    )
    if file_count:
        logger.info(f'Downloaded {file_count} files to {destination_dir}!')


@tagme_commands.command(name='download_dataset_dir')
@click.option('-d', '--destination-dir', required=True, help='Destination directory to save source dataset')
@click.option('-s', '--dataset-id', required=True, help='Dataset identifier')
@click.option('-o', '--organization-name', required=False, help='Organization key')
@click.option('--organization-id', required=False, help='Organization id')
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
def download_dataset_data_cli(
    destination_dir: str,
    dataset_id: str,
    config_path: str,
    organization_name: Optional[str],
    organization_id: Optional[str],
) -> None:
    """
    Download dataset (as files) from dataset to specified directory
    """
    config = TagmeConfig.cli_initialize(config_path, organization_name, organization_id)
    file_count = get_event_loop().run_until_complete(
        download_dataset_data(config, dataset_id, destination_dir, organization_id)
    )
    if file_count:
        logger.info(f'Downloaded {file_count} files to {destination_dir}!')

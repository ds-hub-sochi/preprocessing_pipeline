import logging
from dataclasses import asdict
from pathlib import Path
from typing import List, Optional, Union

import click

from crowd_sdk.core.utils.common import get_event_loop
from crowd_sdk.core.utils.table import save_results
from crowd_sdk.tagme import DEFAULT_CONFIG, CrowdTagmeConfig, TagmeClientAdvanced
from crowd_sdk.tagme.cli.group import tagme_commands
from crowd_sdk.tagme.config import TagmeConfig
from crowd_sdk.tagme.http_client.client import Assignment

logger = logging.getLogger(__name__)

DEFAULT_FORMAT = 'tsv'
DEFAULT_RESULTS = 'results.tsv'
EXTRA_FIELDS = [
    'price sum',
    'time_spent sum',
    'marker_id count',
    'time_spent mean',
    'control_passed mean',
    'consistency mean',
]


async def download_task_results(
    config: TagmeConfig,
    task_id: str,
    destination: str,
    organization_id: Optional[str] = None,
) -> None:
    async with TagmeClientAdvanced(config=config) as client:
        await client.download_task_results(
            task_id=task_id,
            destination=destination,
            organization_id=organization_id,
        )


def filter_results(results: List[Assignment], date: str) -> List[Assignment]:
    res: List[Assignment] = []
    for result in results:
        assert result.end_date
        if date in result.end_date.isoformat():
            res.append(result)
    return res


async def download_task_table(
    client: TagmeClientAdvanced,
    task_id: str,
    destination: str,
    ext: str,
    join_markers: bool,
    date: Optional[str],
    group_markers: bool,
    close: bool = False,
    join_input: bool = False,
    organization_id: Optional[str] = None,
) -> int:
    assignments_results = await client.get_task_assignments(
        task_id,
        join_markers=join_markers,
        with_input_data=join_input,
        date_from=date,
        date_to=date,
        organization_id=organization_id,
    )
    results = [asdict(result) for result in assignments_results]

    if group_markers:
        import pandas as pd  # pylint: disable=import-outside-toplevel

        df = pd.DataFrame(results)
        df['control_passed'] = pd.to_numeric(df['control_passed'], downcast='float')
        df['consistency'] = pd.to_numeric(df['consistency'], downcast='float')
        df = df.groupby(['marker_id', 'email', 'status']).agg(
            {
                'start_date': ['min'],
                'end_date': ['max'],
                'price': ['sum'],
                'marker_id': ['count'],
                'time_spent': ['mean', 'sum'],
                'control_passed': ['mean'],
                'consistency': ['mean'],
            }
        )
        df.columns = [' '.join(str(i) for i in col) for col in df.columns]
        df.replace('', float('NaN'), inplace=True)
        df.dropna(how='all', axis=1, inplace=True)
        df.rename(columns={'marker_id count': 'items count'}, inplace=True)
        df.reset_index(inplace=True)
        results = df.to_dict('records')

    save_results(results, destination, ext)

    if close:
        await client.close()
    return len(results)


async def download_task_attachments(
    config: CrowdTagmeConfig,
    task_id: str,
    destination: str,
    organization_id: Optional[str] = None,
) -> int:
    async with TagmeClientAdvanced(config=config) as client:
        assignments_results = await client.download_attachments(
            task_id=task_id, dir_path=destination, organization_id=organization_id
        )
    logger.debug(assignments_results)

    return len(assignments_results)


@tagme_commands.command(name='download_results')
@click.option('-d', '--destination', required=True, help='Destination file to save markup')
@click.option('-t', '--task-id', required=True, help='Task identifier')
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
@click.option('-o', '--organization-name', required=False, help='Organization key')
@click.option('--organization-id', required=False, help='Organization id')
def download_task_results_cli(
    destination: str,
    task_id: str,
    config_path: Union[str, Path],
    organization_name: Optional[str],
    organization_id: Optional[str],
) -> None:
    """
    Download task results json to specified destination file
    """

    config = TagmeConfig.cli_initialize(config_path, organization_name, organization_id)
    file_count = get_event_loop().run_until_complete(
        download_task_results(config=config, task_id=task_id, destination=destination, organization_id=organization_id)
    )

    logger.info(f'Downloaded {file_count} files to {destination}!')


@tagme_commands.command(name='download_result_table')
@click.option('-t', '--task-id', required=True, help='Task identifier')
@click.option('-d', '--destination', help='Destination file to save markup', default=DEFAULT_RESULTS)
@click.option(
    '-e',
    '--ext',
    type=click.Choice(['csv', 'tsv', 'json', 'xlsx'], case_sensitive=False),
    help='Format',
    default=DEFAULT_FORMAT,
)
@click.option('-j', '--join_markers', is_flag=True, default=False)
@click.option('-i', '--join_input', is_flag=True, default=False)
@click.option('-a', '--date', help='Date to filter')
@click.option('-g', '--group_markers', is_flag=True, default=False, help='Aggregate table by marker')
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
@click.option('-o', '--organization-name', required=False, help='Organization key')
@click.option('--organization-id', required=False, help='Organization id')
def download_table_cli(
    task_id: str,
    destination: str,
    ext: str,
    join_markers: bool,
    join_input: bool,
    date: str,
    group_markers: bool,
    config_path: Union[str, Path],
    organization_name: Optional[str],
    organization_id: Optional[str],
) -> None:
    """
    Download task results table to specified destination file
    """

    config = CrowdTagmeConfig.cli_initialize(config_path, organization_name, organization_id)
    client = TagmeClientAdvanced(config=config)
    file_count = get_event_loop().run_until_complete(
        download_task_table(
            client=client,
            task_id=task_id,
            destination=destination,
            ext=ext,
            join_markers=join_markers,
            join_input=join_input,
            date=date,
            group_markers=group_markers,
            close=False,
            organization_id=organization_id,
        )
    )

    logger.info(f'Downloaded {file_count} files to {destination}!')


@tagme_commands.command(name='download_attachments')
@click.option('-d', '--destination', required=True, help='Destination folder to save attachments')
@click.option('-t', '--task-id', required=True, help='Task identifier')
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
@click.option('-o', '--organization-name', required=False, help='Organization key')
@click.option('--organization-id', required=False, help='Organization id')
def download_task_attachments_cli(
    destination: str,
    task_id: str,
    config_path: Union[str, Path],
    organization_name: Optional[str],
    organization_id: Optional[str],
) -> None:
    """
    Download task results json to specified destination file
    """

    config = TagmeConfig.cli_initialize(config_path, organization_name, organization_id)
    file_count = get_event_loop().run_until_complete(
        download_task_attachments(
            config=config, task_id=task_id, destination=destination, organization_id=organization_id
        )
    )

    logger.info(f'Downloaded {file_count} files to {destination}!')

from typing import List, Optional, Tuple

import click

from crowd_sdk.core.utils.common import get_event_loop
from crowd_sdk.tagme import DEFAULT_CONFIG, TagmeClientAdvanced
from crowd_sdk.tagme.cli.group import tagme_commands
from crowd_sdk.tagme.config import TagmeConfig
from crowd_sdk.tagme.http_client.datacls import TaskDataRequest
from crowd_sdk.tagme.types import MethodData, MethodForms
from crowd_sdk.toloka.config import TolokaConfig
from crowd_sdk.toloka.http_client.client import TolokaClient

MINIMAL_DATETIME = '1970-01-01T00:00:00.000'
MINIMAL_POOL_LAST_STARTED_AT = '2023-06-01T00:00:00.000'
TASKS_IN_PROJECT_LIMIT = 10
TOLOKA_PROJECT_URL_TEMPLATE = '<a href="https://platform.toloka.ai/requester/project/{}">Проект в Толоке</a>{}'
TM_BLOCK_WRAPPER_TEMPLATE = '<tm-block dynamicWidth>{}</tm-block>'


def construct_method_html(toloka_project: dict) -> str:
    return (
        TM_BLOCK_WRAPPER_TEMPLATE.replace('<button', '<tm-button')
        .replace('<title', '<tm-title')
        .format(toloka_project['task_spec']['view_spec']['markup'])
    )


def construct_method_js(toloka_project: dict) -> str:
    return (
        toloka_project['task_spec']['view_spec']['script']
        .replace('TolokaHandlebarsTask', 'HandlebarsTask')
        .replace('getTask().input_values', 'task.jsonResult')
    )


async def update_method(
    toloka_project: dict,
    method_id: str,
    organization_id: str,
    tagme_client: TagmeClientAdvanced,
) -> None:
    method_data = MethodData(
        uid=method_id,
        name='method',
        forms=MethodForms(
            html=construct_method_html(toloka_project),
            css=toloka_project['task_spec']['view_spec']['styles'],
            js=construct_method_js(toloka_project),
        ),
        marker_brief=TOLOKA_PROJECT_URL_TEMPLATE.format(toloka_project['id'], toloka_project['public_instructions']),
    )

    await tagme_client.update_method(method_data, organization_id=organization_id)


async def clone_tasks(
    pools: List[dict],
    tagme_project_id: str,
    organization_id: str,
    toloka_client: TolokaClient,
    tagme_client: TagmeClientAdvanced,
) -> None:
    tasks_counter = 0

    for pool in pools:
        if tasks_counter >= TASKS_IN_PROJECT_LIMIT:
            break

        tasks = toloka_client.get_tasks(pool_id=pool['id'])
        json_tasks = []
        async for task in tasks:
            json_tasks.append(
                {
                    'task': task['input_values'],
                }
            )
            tasks_counter += 1
            if tasks_counter >= TASKS_IN_PROJECT_LIMIT:
                break

        if len(json_tasks) == 0:
            continue

        new_task = await tagme_client.create_task(
            organization_id=organization_id,
            task=TaskDataRequest(
                project_id=tagme_project_id,
                name=pool['private_name'],
                organization_id=organization_id,
            ),
        )

        await tagme_client.upload_json_data(
            task_id=new_task.uid,
            json_data=json_tasks,
            organization_id=organization_id,
        )


async def do_clone(
    toloka_project: dict,
    toloka_client: TolokaClient,
    tagme_client: TagmeClientAdvanced,
    organization_id: Optional[str] = None,
) -> Optional[str]:
    toloka_project_id = toloka_project['id']

    if toloka_project['task_spec']['view_spec']['type'] != 'classic':
        print(f'Toloka project {toloka_project_id} was not cloned due to using of template builder')
        return None

    last_pool_started = MINIMAL_DATETIME

    pools = []
    async for pool in toloka_client.get_pools(project_id=toloka_project['id']):
        pools.append(pool)
        if 'last_started' in pool:
            last_pool_started = max(last_pool_started, pool['last_started'])

    if last_pool_started < MINIMAL_POOL_LAST_STARTED_AT:
        print(f'Toloka project {toloka_project_id} was not cloned because it is too old')
        return None

    new_project = await tagme_client.create_project(
        name=toloka_project['public_name'],
        description=toloka_project['public_description'],
        inner_comment=toloka_project['private_comment'],
        organization_id=organization_id,
    )

    await update_method(toloka_project, new_project.method_id, new_project.organization_id, tagme_client)
    await clone_tasks(pools, new_project.uid, new_project.organization_id, toloka_client, tagme_client)

    print(f'Toloka project {toloka_project_id} was successfully cloned to new Tagme project {new_project.uid}')
    return new_project.uid


async def clone_all_recent_projects_from_toloka(
    toloka_config: TolokaConfig,
    tagme_config: TagmeConfig,
    organization_id: Optional[str] = None,
) -> Tuple[int, int]:
    toloka_client = TolokaClient(config=toloka_config)

    projects = toloka_client.get_projects()
    cloned, skipped = 0, 0
    async for project in projects:
        async with TagmeClientAdvanced(config=tagme_config) as tagme_client:
            project_id = await do_clone(project, toloka_client, tagme_client, organization_id)
        if project_id is not None:
            cloned += 1
        else:
            skipped += 1

    return cloned, skipped


async def clone_project_from_toloka(
    project_id: int,
    toloka_config: TolokaConfig,
    tagme_config: TagmeConfig,
    organization_id: Optional[str] = None,
) -> bool:
    toloka_client = TolokaClient(config=toloka_config)

    project = await toloka_client.get_project(project_id)

    async with TagmeClientAdvanced(config=tagme_config) as tagme_client:
        new_project_id = await do_clone(project, toloka_client, tagme_client, organization_id)
    return new_project_id is not None


@tagme_commands.command(name='clone_from_toloka')
@click.option('-p', '--project-id', required=False, help='Project id at Toloka')
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
@click.option('-o', '--organization-name', required=False, help='Organization key to clone project to')
@click.option('--organization-id', required=False, help='Organization id to clone project to')
def clone_from_toloka_cli(
    project_id: Optional[int], config_path: str, organization_name: Optional[str], organization_id: Optional[str]
) -> None:
    """
    clone project from Toloka with name, description, instructions and some tasks for preview
    """
    tagme_config = TagmeConfig.cli_initialize(config_path, organization_name, organization_id)
    toloka_config = TolokaConfig.from_global_config(config_path)

    if project_id is None:
        cloned, skipped = get_event_loop().run_until_complete(
            clone_all_recent_projects_from_toloka(toloka_config, tagme_config, organization_id)
        )
        print(f'Cloned projects: {cloned}')
        print(f'Skipped projects: {skipped}')
    else:
        get_event_loop().run_until_complete(
            clone_project_from_toloka(project_id, toloka_config, tagme_config, organization_id)
        )

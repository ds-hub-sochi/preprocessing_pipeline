import csv
import json
import logging
import sys
from dataclasses import asdict, dataclass, fields
from enum import Enum
from itertools import chain
from pathlib import Path
from typing import IO, Iterable, Optional, Sequence, Tuple, Union

import click

from crowd_sdk.core.utils.common import get_event_loop
from crowd_sdk.tagme import DEFAULT_CONFIG, TagmeClientAdvanced
from crowd_sdk.tagme.cli.group import tagme_commands
from crowd_sdk.tagme.config import TagmeConfig
from crowd_sdk.tagme.types import ItemQuality, StatsOutputType, TaskQuality

logger = logging.getLogger(__name__)


class OutputFormat(Enum):
    JSON = 'json'
    CSV = 'csv'
    # TSV = 'tsv'


@dataclass
class OutputParams:
    type: StatsOutputType
    format: OutputFormat
    destination_file: Optional[Path]


@tagme_commands.command(name='get_quality_stats')
@click.option('-o', '--organization', required=False, help='Organization key')
@click.option(
    '-f', '--out-format', required=True, help='Output format', type=click.Choice([x.value for x in OutputFormat])
)
@click.option(
    '-O',
    '--out-type',
    required=True,
    help='Group stats by tasks or task items',
    type=click.Choice([x.value for x in StatsOutputType]),
)
@click.option('-t', '--task-id', 'task_ids', required=False, help='Filter by tasks (multiple allowed)', multiple=True)
@click.option(
    '-p', '--project-id', 'project_ids', required=False, help='Filter by projects (multiple allowed)', multiple=True
)
@click.option('-d', '--destination-file', required=False, help='Destination file to save result', type=click.Path())
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
def get_quality_stats_cli(
    organization: Optional[str],
    out_type: str,
    out_format: str,
    task_ids: Optional[Tuple[str]],
    project_ids: Optional[Tuple[str]],
    destination_file: Optional[str],
    config_path: Union[str, Path],
) -> None:
    """
    Make a report with quality statistics
    """
    output = OutputParams(
        type=StatsOutputType(out_type),
        format=OutputFormat(out_format),
        destination_file=Path(destination_file) if destination_file else None,
    )
    logger.info(output)

    config = TagmeConfig.from_any(config_path)
    config.prompt_user_and_password_if_missing()

    get_event_loop().run_until_complete(
        get_quality_stats_cli_(
            organization=organization or config.org,
            output=output,
            config_path=config_path,
            task_ids=task_ids,
            project_ids=project_ids,
        )
    )


async def get_quality_stats_cli_(
    organization: Optional[str],
    output: OutputParams,
    config_path: Union[str, Path],
    task_ids: Optional[Tuple[str]],
    project_ids: Optional[Tuple[str]],
) -> None:
    client = TagmeClientAdvanced(config=config_path)
    org = await (client.get_organization(organization) if organization else client.client.get_current_organization())
    logger.info(f'org {org.name}')

    result = await client.get_quality_stats(org.uid, output.type, task_ids, project_ids)
    result = [x for x in result if x is not None]

    if not result:
        logger.warning('empty result')
        return

    if output.destination_file is None:
        file = sys.stdout

    else:
        file = open(output.destination_file, 'w')  # pylint: disable=R1732

    if output.type == StatsOutputType.ITEM:
        iterator = map(asdict, chain(*result))  # type: ignore
        header = [x.name for x in fields(ItemQuality)]

    elif output.type == StatsOutputType.TASK:
        iterator = map(asdict, result)
        header = [x.name for x in fields(TaskQuality)]

    else:
        raise NotImplementedError

    print_result(output.format, iterator, file, header)

    if output.destination_file is not None:
        file.close()


def print_result(out_format: OutputFormat, iterator: Iterable, file: IO, header: Sequence[str]) -> None:
    if out_format == OutputFormat.CSV:
        writer = csv.DictWriter(file, fieldnames=header)
        writer.writeheader()
        writer.writerows(iterator)

    elif out_format == OutputFormat.JSON:
        json.dump(list(iterator), file)

    else:
        raise NotImplementedError

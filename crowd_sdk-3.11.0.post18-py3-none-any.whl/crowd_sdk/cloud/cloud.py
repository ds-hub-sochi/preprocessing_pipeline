"""
Script to manage voice_misc datasets in cepth
"""

import logging
import os
import re
import tempfile
from functools import partial
from multiprocessing import Pool
from pathlib import Path
from typing import Any, Callable, Dict, Generator, Iterable, List, Optional, Tuple, TypeVar, Union

import boto3
import botocore
import botocore.exceptions
import requests
import requests.packages
import urllib3
from botocore.config import Config
from botocore.exceptions import ClientError
from tqdm.autonotebook import tqdm

from crowd_sdk.core.utils.common import chunks
from crowd_sdk.core.utils.func import Runnable
from crowd_sdk.core.utils.http import (
    BaseSyncHttpWrapper,
    ExponentialBackoffPolicy,
    retry_request_sync,
    retry_request_sync_supress,
)
from crowd_sdk.core.utils.os import TempDir, TmpFile, walk

from .compress import pack_single_file

logger = logging.getLogger(__name__)
Item = TypeVar("Item")


class Cloud(Runnable):  # pylint: disable=too-many-public-methods
    """
    Wrapper for the boto3 client, to simplify handling config and to store default params
    """

    EXPIRE = 3

    # static variable only for multiprocessing parallelization
    static_mp_client = None
    httpwrapper = BaseSyncHttpWrapper()

    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    def __init__(self, config: dict, threads_num: int = 8, **params: Any) -> None:
        # TODO(volerog): use cloud config
        if params:
            logger.warning('Specified unused params for Cloud constructor: %s', params)
        self.expire = self.EXPIRE * 24 * 3600
        self.endpoint = config['endpoint']
        self.real_endpoint = config.get('real_endpoint')
        self.client = Cloud.get_s3_client(config)
        self.config = config
        self.threads_num = threads_num

        self.test_connection(config.get('test_buckets', []))

    def test_connection(self, buckets: list) -> None:
        if not buckets:
            return None
        logger.info("Test cloud...")
        filename = 'test_asset.txt'

        with tempfile.TemporaryDirectory() as tmp_dir_name:
            ds_path = os.path.join(tmp_dir_name, filename)
            dse_path = os.path.join("test_dir", filename)

            with open(ds_path, "wt") as f:
                f.write("Hello world!")

            for bucket in buckets:
                self.upload(src=ds_path, dst=dse_path, bucket=bucket)
                self.publish(path=dse_path, bucket=bucket)
        return None

    def _construct_url(self, bucket: str, file_name: str) -> str:
        return self.client.generate_presigned_url(
            "get_object", Params={"Bucket": bucket, "Key": file_name}, ExpiresIn=self.expire
        )

    def _key_existing_size(self, bucket: str, key: str) -> Optional[int]:
        """
        :return: the key's size if it exist, else None
        """
        response = self.client.list_objects_v2(Bucket=bucket, Prefix=key)
        for obj in response.get('Contents', []):
            if obj['Key'] == key:
                return obj['Size']
        return None

    @staticmethod
    @retry_request_sync(attempts=13, retry_policy=ExponentialBackoffPolicy(backoff_factor=1.8))
    def get_s3_client(config: dict) -> Any:
        boto_config = {
            'service_name': 's3',
            'region_name': config.get('region', 'ru'),
            'verify': False,
            'aws_access_key_id': None,
            'aws_secret_access_key': None,
            'endpoint_url': None,
        }
        config_with_retries = Config(retries={'max_attempts': 50})
        boto_config.update(
            {
                'aws_access_key_id': config['key'],
                'aws_secret_access_key': config['secret'],
                'endpoint_url': config['endpoint'],
                'config': config_with_retries,
            }
        )
        s3obj = boto3.client(**boto_config)
        return s3obj

    @staticmethod
    def initialize_mp_s3(config: dict) -> None:
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        Cloud.static_mp_client = Cloud.get_s3_client(config)

    @staticmethod
    def chunks(lst: List[Item], n: int) -> Generator[List[Item], None, None]:
        yield from chunks(lst=lst, n=n)

    def is_dir(self, bucket: str, key: str) -> bool:
        if not key.endswith('/'):
            key = key + '/'
        response = self.client.list_objects_v2(Bucket=bucket, Prefix=key)
        exists = len(response.get('Contents', [])) > 0
        is_file_ = len([o for o in response.get('Contents', []) if o['Key'] == key]) > 0
        return exists and not is_file_

    def is_file(self, bucket: str, key: str) -> bool:
        response = self.client.list_objects_v2(Bucket=bucket, Prefix=key)
        is_file_ = len([o for o in response.get('Contents', []) if o['Key'] == key]) > 0
        return is_file_

    @staticmethod
    @retry_request_sync(attempts=13, retry_policy=ExponentialBackoffPolicy(backoff_factor=1.8))
    def publish_process(args: Tuple[str, str], unpublish: bool) -> None:
        """args: Tuple(bucket, src_path)"""
        bucket, src_path = args
        assert Cloud.static_mp_client is not None, 'Run static_mp_client initialized before publish_process'
        client = Cloud.static_mp_client
        client.put_object_acl(Bucket=bucket, Key=src_path, ACL=('private' if unpublish else 'public-read'))

    def publish(
        self, bucket: str, path: Optional[str] = None, unpublish: bool = False, tqdm_off: bool = False
    ) -> List[str]:
        res = []
        debug_mode = (logging.root.level == logging.DEBUG) or tqdm_off
        sources = self.walk(bucket, path)
        logging.debug('s3://%s/%s', bucket, path)
        bucket_and_src_paths = []
        for _, src_path in sources:
            url = self.endpoint + '/' + bucket + '/' + src_path
            res.append(url)
            bucket_and_src_paths.append((bucket, src_path))

        pub_part_func = partial(Cloud.publish_process, unpublish=unpublish)
        with Pool(self.threads_num, initializer=Cloud.initialize_mp_s3, initargs=(self.config,)) as pool:
            list(
                tqdm(
                    pool.imap(pub_part_func, bucket_and_src_paths), total=len(bucket_and_src_paths), disable=debug_mode
                )
            )
        return res

    def publish_from_url_list(self, s3_urls: List[str], unpublish: bool = False, tqdm_off: bool = False) -> None:
        debug_mode = (logging.root.level == logging.DEBUG) or tqdm_off

        bucket_and_src_paths_set = set()
        for url in s3_urls:
            bucket, s3_path = re.sub(
                r'^{0}'.format(re.escape(self.endpoint + '/')), '', url  # pylint: disable=C0209
            ).split('/', 1)
            bucket_and_src_paths_set.add((bucket, s3_path))

        bucket_and_src_paths = list(bucket_and_src_paths_set)

        pub_part_func = partial(Cloud.publish_process, unpublish=unpublish)
        with Pool(self.threads_num, initializer=Cloud.initialize_mp_s3, initargs=(self.config,)) as pool:
            list(
                tqdm(
                    pool.imap(pub_part_func, bucket_and_src_paths), total=len(bucket_and_src_paths), disable=debug_mode
                )
            )

    def check_bucket(self, bucket_name: str) -> bool:
        """
        Test if bucket_name exists on the object endpoint.
        """
        try:
            self.client.head_bucket(Bucket=bucket_name)
            logger.debug("Bucket Exists!")
            return True
        except botocore.exceptions.ClientError as err:
            error_code = int(err.response['Error']['Code'])
            if error_code == 403:
                logger.debug("Private Bucket. Access forbidden!")
                return True
            elif error_code == 404:
                logger.debug("Bucket does not exist!")
                return False
            raise

    @staticmethod
    @retry_request_sync(attempts=13, retry_policy=ExponentialBackoffPolicy(backoff_factor=1.8))
    def upload_process(
        args: Tuple[str, str], bucket: Optional[str], dryrun: bool, skip_existing: bool
    ) -> Optional[Tuple[str, str]]:
        """
        Uploads something to the cloud

        Args:
            args: pair for local_src -> remote_dst
            bucket: buket name
            dryrun: for debugging, will ignore real actions
            skip_existing: don't reupload existing files

        Returns:
            pair local_src, remote_dst for copied files or None for sipped
        """
        src_path, dst_path = args
        if not bucket:
            bucket = dst_path.split('/')[0]
            dst_path = '/'.join(dst_path.split('/')[1:])
        assert Cloud.static_mp_client is not None, 'Run static_mp_client initialized before upload_process'
        client = Cloud.static_mp_client
        try:
            client.head_bucket(Bucket=bucket)
        except (client.exceptions.NoSuchBucket, client.exceptions.ClientError):
            client.create_bucket(Bucket=bucket)
        response = client.list_objects_v2(Bucket=bucket, Prefix=dst_path)
        is_file_ = len([o for o in response.get('Contents', []) if o['Key'] == dst_path]) > 0
        if skip_existing:
            if is_file_:
                logger.debug('Skip existing cp %s s3://%s/%s', src_path, bucket, dst_path)
                return bucket, dst_path
            logger.debug('cp %s s3://%s/%s', src_path, bucket, dst_path)
        if not dryrun:
            extra_args = {}
            if src_path.endswith('.wav'):
                extra_args = {'ContentType': 'audio/wav'}
            elif src_path.endswith('.mp3'):
                extra_args = {'ContentType': 'audio/mpeg'}
            client.upload_file(src_path, bucket, dst_path, ExtraArgs=extra_args)
        return bucket, dst_path

    @staticmethod
    @retry_request_sync(attempts=13, retry_policy=ExponentialBackoffPolicy(backoff_factor=1.8))
    def upload_backup_process(
        args: Tuple[Union[str, Path], str], bucket: Union[None, str], dryrun: bool, skip_existing: bool, key: str
    ) -> Tuple[str, str]:
        """
        Uploads and packs file with some secret to the cloud

        Args:
            args: pair for local_src -> remote_dst
            bucket: buket name
            dryrun: for debugging, will ignore real actions
            skip_existing: don't reupload existing files
            key: key for encrypting archives uploaded to the cloud

        Returns:
            pair local_src, remote_dst for copied files or None for sipped
        """
        src_path, dst_path = args
        src_path = Path(src_path)
        src_path = pack_single_file(src_path, str(key))

        if not bucket:
            bucket = dst_path.split('/')[0]
            dst_path = '/'.join(dst_path.split('/')[1:])

        dst_path = str(Path(dst_path).parent / src_path.name)
        src_path = str(src_path)
        args = (src_path, dst_path)
        with TmpFile(src_path) as _src_path:
            Cloud.upload_process(args, bucket, dryrun, skip_existing)
        return bucket, dst_path

    def create_bucket(self, bucket: str) -> None:
        self.client.create_bucket(Bucket=bucket)

    def upload(  # pylint: disable=R0912
        self,
        src: Union[str, List[str]],
        dst: str,
        bucket: Optional[str] = None,
        dryrun: bool = False,
        skip_existing: bool = False,
        tqdm_off: bool = False,
        backup_config: Optional[dict] = None,
    ) -> List[Tuple[str, str]]:
        """
        Uploads and bakups something to the cloud

        Args:
            src: local src
            bucket: buket name
            dst: remote dst
            dryrun: for debugging, will ignore real actions
            skip_existing:
            tqdm_off:
            backup_config:

        Returns:
            List of pair local_src, remote_dst for copied files or None for sipped
        """
        if not bucket:
            if isinstance(dst, str):
                bucket = dst.split('/')[0]
                dst = '/'.join(dst.split('/')[1:])
            else:
                raise ValueError('Doent\'t support for biting off a bucket from list of destinations')
        if not self.check_bucket(bucket):
            self.client.create_bucket(Bucket=bucket)
        if isinstance(src, list) and isinstance(dst, list):
            assert len(src) == len(dst), f'len of src ({len(src)}) != len of dst({len(dst)})'
            sources = [[src_file, dst_file] for src_file, dst_file in zip(src, dst)]
        elif isinstance(src, list):
            sources = [[src_file, os.path.join(dst, src_file.split('/')[-1])] for src_file in src]
        else:
            src = os.path.expanduser(src)

            dst_is_dir = False
            src_is_dir = os.path.isdir(src)
            if self.is_dir(bucket, dst):
                dst_is_dir = True
            elif not self.is_file(bucket, dst):
                dst_is_dir = src_is_dir
            dst_src = os.path.join(dst, os.path.basename(src))

            if src_is_dir and not dst_is_dir:
                raise RuntimeError(f'Couldn\' copy: src {src} is dir and {dst} is file')

            if src_is_dir:
                sources = [[abs_path, os.path.join(dst_src, rel_path)] for rel_path, abs_path in walk(src)]
            elif dst_is_dir:
                sources = [[src, dst_src]]
            else:
                sources = [[src, dst]]

        debug_mode = (logging.root.level == logging.DEBUG) or tqdm_off

        upl_part_func = partial(Cloud.upload_process, bucket=bucket, dryrun=dryrun, skip_existing=skip_existing)
        with Pool(self.threads_num, initializer=Cloud.initialize_mp_s3, initargs=(self.config,)) as pool:
            result = list(tqdm(pool.imap(upl_part_func, sources), total=len(sources), disable=debug_mode))

        if backup_config:
            upl_backup_part_func = partial(
                Cloud.upload_backup_process,
                bucket=bucket,
                dryrun=dryrun,
                skip_existing=skip_existing,
                key=backup_config['password'],
            )
            with Pool(self.threads_num, initializer=Cloud.initialize_mp_s3, initargs=(backup_config,)) as pool:
                backup_result = list(
                    tqdm(pool.imap(upl_backup_part_func, sources), total=len(sources), disable=debug_mode)
                )

            if len(backup_result) > 0:
                link_example = os.path.join(backup_config['endpoint'], backup_result[0][0], backup_result[0][1])
                logger.debug(f'Backup link example: {link_example}')

        return result

    def upload_backup_from_urls_list(
        self,
        s3_urls: List[str],
        backup_config: dict,
        dryrun: bool = False,
        skip_existing: bool = False,
        tqdm_off: bool = False,
    ) -> Dict[str, str]:
        debug_mode = (logging.root.level == logging.DEBUG) or tqdm_off
        s3_urls = list(set(s3_urls))
        backup_result = []
        for s3_urls_chunk in Cloud.chunks(s3_urls, 10000):
            with TempDir() as tmp_dir:
                self.download_from_url_list(s3_urls_chunk, dst=tmp_dir, tqdm_off=True)
                sources = []
                for url in s3_urls_chunk:
                    src_file = os.path.join(tmp_dir, url.split('/')[-1])
                    prefix = self.endpoint + '/'
                    dst_file = url[url.startswith(prefix) and len(prefix) :]
                    sources.append([src_file, dst_file])

                upl_backup_part_func = partial(
                    Cloud.upload_backup_process,
                    bucket=None,
                    dryrun=dryrun,
                    skip_existing=skip_existing,
                    key=backup_config['password'],
                )
                with Pool(self.threads_num, initializer=Cloud.initialize_mp_s3, initargs=(backup_config,)) as pool:
                    backup_result_chunk = list(
                        tqdm(pool.imap(upl_backup_part_func, sources), total=len(sources), disable=debug_mode)
                    )
                backup_result += backup_result_chunk

        name_to_url_dict = {url.split('/')[-1]: url for url in s3_urls}
        src_url_to_dst_url_dict = {}
        for backup_bucket, backup_path in backup_result:
            fname = backup_path.split('/')[-1].split('.enc')[0]
            src_url = name_to_url_dict[fname]
            dst_url = os.path.join(backup_config['endpoint'], backup_bucket, backup_path)
            src_url_to_dst_url_dict[src_url] = dst_url
        return src_url_to_dst_url_dict

    def walk(self, bucket: str, path: Optional[str] = None, tqdm_off: bool = False) -> List[List[str]]:
        debug_mode = (logging.root.level == logging.DEBUG) or tqdm_off

        if path is not None and self.is_file(bucket, path):
            return [['', path]]
        result = []

        if path is not None:
            paginate = self.client.get_paginator('list_objects').paginate(Bucket=bucket, Prefix=path)
            if not path.endswith('/'):
                path = path + '/'
        else:
            paginate = self.client.get_paginator('list_objects').paginate(Bucket=bucket)
            path = ''

        pbar = tqdm() if debug_mode else None

        for page in paginate:
            if 'Contents' not in page:
                logger.debug('There is no such remote path: %s', path)
                break
            for item in page['Contents']:
                rel_path = item['Key'][len(path) :].lstrip('/')
                result.append([rel_path, item['Key']])

                if pbar is not None:
                    pbar.update(1)

        return result

    @staticmethod
    @retry_request_sync(attempts=13, retry_policy=ExponentialBackoffPolicy(backoff_factor=1.8))
    def download_process(args: Tuple[str, str], bucket: str, dst: str, dryrun: bool) -> None:
        rel_path, src_path = args
        assert Cloud.static_mp_client is not None, 'Run static_mp_client initialized before download_process'
        client = Cloud.static_mp_client
        if not rel_path:
            object_target_path = os.path.join(dst, os.path.basename(src_path))
        else:
            object_target_path = os.path.join(dst, os.path.basename(src_path), rel_path)
        if not os.path.exists(os.path.dirname(object_target_path)):
            os.makedirs(os.path.dirname(object_target_path), exist_ok=True)
        logger.debug('cp s3://%s/%s %s', bucket, src_path, object_target_path)
        if not dryrun:
            client.download_file(bucket, src_path, object_target_path)

    def download(
        self,
        bucket: str,
        src: str,
        dst: str,
        dryrun: bool = False,
        num_samples: Optional[int] = None,
        tqdm_off: bool = False,
    ) -> None:
        debug_mode = (logging.root.level == logging.DEBUG) or tqdm_off
        sources = self.walk(bucket=bucket, path=src)
        if os.path.isfile(dst) and len(src) > 0:
            raise ValueError('Couldn\'t copy dir to file')
        if num_samples is not None:
            sources = sources[:num_samples]
        down_part_func = partial(Cloud.download_process, bucket=bucket, dst=dst, dryrun=dryrun)

        with Pool(self.threads_num, initializer=Cloud.initialize_mp_s3, initargs=(self.config,)) as pool:
            list(tqdm(pool.imap(down_part_func, sources), total=len(sources), disable=debug_mode))

    @staticmethod
    @retry_request_sync(attempts=13, retry_policy=ExponentialBackoffPolicy(backoff_factor=1.8))
    def download_from_url_list_process(
        args: List[str], dryrun: bool, skip_existing: bool = False, callback: Optional[Callable] = None
    ) -> None:
        bucket, src, dst, callback_data = args
        if skip_existing and os.path.exists(dst):
            return

        assert (
            Cloud.static_mp_client is not None
        ), 'Run static_mp_client initialized before download_from_url_list_process'
        client = Cloud.static_mp_client
        assert client is not None
        logger.debug('cp s3://%s/%s %s', bucket, src, dst)
        if dryrun:
            return

        retries_left = 10
        done = False
        while not done and retries_left > 0:
            try:
                client.download_file(bucket, src, dst)
                done = True
            except (botocore.exceptions.BotoCoreError, urllib3.exceptions.ProtocolError) as exc:
                if retries_left == 0:
                    raise exc
                retries_left -= 1
                logger.error('Downloading failed with error %s. Retries left=%s', exc, retries_left)

        if callback is not None:
            callback(bucket, src, dst, callback_data)

    def download_from_url_list(
        self,
        s3_urls: List[str],
        dst: str,
        dryrun: bool = False,
        tqdm_off: bool = False,
        skip_existing: bool = False,
        callback_data: Optional[List[Any]] = None,
        callback: Optional[Callable] = None,
    ) -> None:
        debug_mode = (logging.root.level == logging.DEBUG) or tqdm_off

        if not isinstance(dst, list) and not os.path.exists(os.path.dirname(dst)):
            os.makedirs(os.path.dirname(dst), exist_ok=True)

        set_to_download = set()
        for i, line in enumerate(s3_urls):
            bucket, s3_path = re.sub(
                r'^{0}'.format(re.escape(self.endpoint + '/')), '', line  # pylint: disable=C0209
            ).split('/', 1)

            if isinstance(dst, list):
                local_path = str(dst[i])
            else:
                filename = os.path.split(s3_path)[-1]
                local_path = os.path.join(dst, filename)

            if callback_data is not None:
                callback_data_for_download = callback_data[i]
            else:
                callback_data_for_download = None
            set_to_download.add((bucket, s3_path, local_path, callback_data_for_download))

        args = list(set_to_download)
        down_part_func = partial(
            Cloud.download_from_url_list_process, skip_existing=skip_existing, dryrun=dryrun, callback=callback
        )
        with Pool(self.threads_num, initializer=Cloud.initialize_mp_s3, initargs=(self.config,)) as pool:
            list(tqdm(pool.imap(down_part_func, args), total=len(set_to_download), disable=debug_mode))

    @staticmethod
    @retry_request_sync(attempts=13, retry_policy=ExponentialBackoffPolicy(backoff_factor=1.8))
    def delete_process(src_path: str, bucket: str) -> Tuple[str, str]:
        assert Cloud.static_mp_client is not None, 'Run static_mp_client initialized before delete_process'
        client = Cloud.static_mp_client
        logger.debug('rm s3://%s/%s', bucket, src_path)
        client.delete_object(Bucket=bucket, Key=src_path)
        return bucket, src_path

    def delete(self, bucket: str, src: str, force: bool = False, tqdm_off: bool = False) -> List[str]:
        """
        Deletes file or folder from s3
        If folder is deleted, it is also deleted from DATASETS_LIST_FILE
        """
        debug_mode = (logging.root.level == logging.DEBUG) or tqdm_off

        sources: List[str] = []
        if self.is_dir(bucket, src):
            sources = [path for _, path in self.walk(bucket=bucket, path=src)]
        elif self.is_file(bucket, src):
            sources = [src]
        else:
            raise RuntimeError(f'No such target to delete: s3://{bucket}/{src}')

        if not force:
            print(f'Are you sure you want to delete s3://{bucket}/{src}?')
            if input('(Y/N) << ').lower() not in ['yes', 'y']:
                raise RuntimeError(f'Stop deletion of: s3://{bucket}/{src}')

        del_part_func = partial(Cloud.delete_process, bucket=bucket)
        with Pool(self.threads_num, initializer=Cloud.initialize_mp_s3, initargs=(self.config,)) as pool:
            deleted_instances = list(tqdm(pool.imap(del_part_func, sources), total=len(sources), disable=debug_mode))

        return deleted_instances

    @staticmethod
    @retry_request_sync(attempts=13, retry_policy=ExponentialBackoffPolicy(backoff_factor=1.8))
    def delete_file_process(file: Tuple[str, str]) -> bool:
        assert Cloud.static_mp_client is not None, 'Run static_mp_client initialized before delete_process'
        bucket, src = file
        client = Cloud.static_mp_client
        response = client.list_objects_v2(Bucket=bucket, Prefix=src)
        files = len([o for o in response.get('Contents', []) if o['Key'] == src])
        if files == 1:
            client.delete_object(Bucket=bucket, Key=src)
            logger.info('Deleted file in bucket: %s, src: %s', bucket, src)
            return True
        elif files > 1:
            logger.info('More than 1 file in bucket: %s, src: %s', bucket, src)
        else:
            logger.info('No such file in bucket: %s, src: %s', bucket, src)
        return False

    def delete_from_urls_list(self, urls: List[str], tqdm_off: bool = False) -> List[str]:
        debug_mode = (logging.root.level == logging.DEBUG) or tqdm_off

        urls_main_endpoint: List[str] = []
        valid_urls: List[str] = []
        for url in urls:
            if url.startswith(self.endpoint):
                urls_main_endpoint.append(url)
                valid_urls.append(url)
            elif self.real_endpoint and url.startswith(self.real_endpoint):
                urls_main_endpoint.append(url.replace(self.real_endpoint, self.endpoint))
                valid_urls.append(url)
            else:
                logger.warning('bad endpoint: %s', url)

        n = self.endpoint.count('/')
        files = [
            ('/'.join(url.split('/')[n + 1 : n + 2]), '/'.join(url.split('/')[n + 2 :])) for url in urls_main_endpoint
        ]

        with Pool(self.threads_num, initializer=Cloud.initialize_mp_s3, initargs=(self.config,)) as pool:
            deleted_files = list(tqdm(pool.imap(self.delete_file_process, files), total=len(files), disable=debug_mode))
        deleted_files = [url for f, url in zip(deleted_files, valid_urls) if f]
        logger.info('Deleted %s files from cloud', len(deleted_files))
        return deleted_files

    def get_tree(self, bucket: str, path: Optional[str] = None, flat: bool = False) -> List[str]:
        src = [path or '']
        res = []
        while src:
            src_new = []
            for prefix in src:
                is_truncated = True
                continuation_token = None
                while is_truncated:
                    kwargs = {
                        'Bucket': bucket,
                        'Delimiter': '/',
                    }
                    if prefix != '':
                        kwargs['Prefix'] = prefix
                    if continuation_token is not None:
                        kwargs['ContinuationToken'] = continuation_token

                    list_objects = self.client.list_objects_v2(**kwargs)

                    for obj in list_objects.get('CommonPrefixes') or []:
                        if obj.get('Prefix') != prefix:
                            res += [obj.get('Prefix')]
                            src_new += [obj.get('Prefix')]

                    continuation_token = list_objects.get('NextContinuationToken')
                    is_truncated = list_objects.get('IsTruncated')
            src = src_new
            if flat:
                # if want to look at only level
                break
        return res

    def ls_folder(self, bucket: str, folder: str) -> List[str]:
        """
        Prints content of folder with depth == 1 (not recursively)
        """
        if self.is_file(bucket, folder):
            return [folder]

        if not self.is_dir(bucket, folder):
            raise RuntimeError(f'No such file or directory! {bucket}/{folder}')

        if not folder.endswith('/'):
            folder += '/'

        pages = []
        first_page = self.client.list_objects(Bucket=bucket, Prefix=folder, Delimiter='/')
        pages.append(first_page)

        next_continuation_token = first_page.get('NextContinuationToken')
        while next_continuation_token:
            page = self.client.list_objects_v2(
                Bucket=bucket, Prefix=folder, Delimeter='/', ContinuationToken=next_continuation_token
            )
            pages.append(page)
            next_continuation_token = page.get('NextContinuationToken')

        objects = []

        for page in pages:
            # Looking for directories inside folder
            dirs = page.get('CommonPrefixes')
            if dirs and len(dirs) > 1:
                for obj in tqdm(dirs):
                    objects.append(obj.get('Prefix'))

            # Looking for files inside folder
            files = page.get('Contents')
            if files:
                for obj in tqdm(files):
                    objects.append(obj.get('Key'))

        return objects

    @staticmethod
    @retry_request_sync_supress(attempts=4)
    def validate_url(url: str, debug_mode: bool = False) -> Tuple[str, str, bool]:
        fname = os.path.split(url)[1]
        response = Cloud.httpwrapper.head(url, verify=False)
        if not debug_mode:
            assert 200 <= response.status_code < 300, f'File {fname} wasnt published! Its urls path is {url}'
        return fname, url, response.status_code == requests.codes.ok  # pylint: disable=no-member

    def validate_urls(
        self, urls_list: Iterable[str], debug_mode: bool = False, tqdm_off: bool = False
    ) -> List[Tuple[str, str, bool]]:
        urls_list = set(urls_list)
        valid_part_func = partial(Cloud.validate_url, debug_mode=debug_mode)
        with Pool(self.threads_num, initializer=Cloud.initialize_mp_s3, initargs=(self.config,)) as pool:
            results = list(tqdm(pool.imap(valid_part_func, urls_list), total=len(urls_list), disable=tqdm_off))
        overall_results: List[Tuple[str, str, bool]] = []
        for result, url in zip(results, urls_list):
            if result is not None:
                overall_results.append(result)
                continue
            fname = os.path.split(url)[1]
            overall_results.append((fname, url, False))  # validation url raise error after retries
        return overall_results

    def upload_publish_validate(
        self,
        src: Union[str, List[str]],
        dst: str,
        bucket: Optional[str] = None,
        debug_mode: bool = False,
        tqdm_off: bool = False,
        backup_config: Optional[dict] = None,
        return_real_urls: bool = True,
    ) -> List[Tuple[str, str, bool]]:
        if not isinstance(src, list) and os.path.isdir(src) and not src.endswith('/'):
            src = src + '/'

        upl_args = self.upload(
            src=src,
            bucket=bucket,
            dst=dst,
            dryrun=False,
            skip_existing=False,
            tqdm_off=tqdm_off,
            backup_config=backup_config,
        )

        pub_args = [(bucket, dst_path) for _, dst_path in upl_args]
        pub_part_func = partial(Cloud.publish_process, unpublish=False)
        with Pool(self.threads_num, initializer=Cloud.initialize_mp_s3, initargs=(self.config,)) as pool:
            list(tqdm(pool.imap(pub_part_func, pub_args), total=len(pub_args), disable=tqdm_off))
        url2path = {
            os.path.join(self.endpoint, bucket_name, dst_path): (bucket_name, dst_path)
            for bucket_name, dst_path in upl_args
        }
        upl_urls = [os.path.join(self.endpoint, bucket_name, dst_path) for bucket_name, dst_path in upl_args]
        res = self.validate_urls(urls_list=upl_urls, debug_mode=debug_mode, tqdm_off=tqdm_off)
        if upl_urls:
            logger.info('Uploaded URL example: %s %d', upl_urls[0], len(upl_urls))

        if return_real_urls and self.real_endpoint is not None:
            result: List[Tuple[str, str, bool]] = []
            for fname, url, status in res:
                bucket_name, dst_path = url2path[url]
                new_url = os.path.join(self.real_endpoint, bucket_name, dst_path)
                result.append((fname, new_url, status))
        else:
            if return_real_urls:
                logger.debug("Not found 'real_endpoint' in config. Returns urls with 'endpoint' as base.")
            result = res

        return result

    @staticmethod
    @retry_request_sync(attempts=13, retry_policy=ExponentialBackoffPolicy(backoff_factor=1.8))
    def copy_to_yourself_process(src_path: str) -> None:
        assert Cloud.static_mp_client is not None, 'Run static_mp_client initialized before copy_to_yourself_process'
        client = Cloud.static_mp_client
        bucket, path = src_path.split('/', 1)
        copy_source = {'Bucket': bucket, 'Key': path}
        try:
            client.copy_object(
                Bucket=bucket,
                Key=path,
                CopySource=copy_source,
                Metadata={},
                MetadataDirective='REPLACE',
            )
        except botocore.exceptions.ClientError as err:
            error_code = str(err.response['Error']['Code'])
            if error_code == '404':
                logger.debug('HeadObject operation: Not Found!')
                return
            if error_code == 'NoSuchKey':
                logger.debug(
                    'An error occurred (NoSuchKey) when calling the '
                    'CopyObject operation: The specified key does not exist.'
                )
                return
            raise

    def copy_to_yourself(
        self,
        urls_list: List[str],
        tqdm_off: bool = False,
    ) -> None:
        debug_mode = (logging.root.level == logging.DEBUG) or tqdm_off

        src_pathes = set()
        for url in urls_list:
            bucket, s3_path = re.sub(
                r'^{0}'.format(re.escape(self.endpoint + '/')), '', url  # pylint: disable=C0209
            ).split('/', 1)
            src_pathes.add(f'{bucket}/{s3_path}')

        with Pool(self.threads_num, initializer=Cloud.initialize_mp_s3, initargs=(self.config,)) as pool:
            list(
                tqdm(
                    pool.imap(Cloud.copy_to_yourself_process, list(src_pathes)),
                    total=len(src_pathes),
                    disable=debug_mode,
                )
            )

    @staticmethod
    @retry_request_sync(attempts=1, retry_policy=ExponentialBackoffPolicy(backoff_factor=1.8))
    def check_url_on_cloud(file: Tuple[str, str, str], debug_mode: bool = True) -> Tuple[str, bool]:
        _, bucket, src = file
        assert Cloud.static_mp_client is not None, 'Run static_mp_client initialized before download_process'
        client = Cloud.static_mp_client
        status = False
        try:
            _ = client.head_object(Bucket=bucket, Key=src)
            status = True
        except botocore.exceptions.ClientError as err:
            error_code = int(err.response['Error']['Code'])
            if debug_mode and error_code == 404:
                logger.debug("FIle does not exist on cloud!")
            else:
                raise
        return '/'.join(file), status  # pylint: disable=E1101

    def check_urls_on_cloud(
        self,
        urls_list: List[str],
        debug_mode: bool = True,
        tqdm_off: bool = False,
    ) -> List[Tuple[str, bool]]:
        debug_mode = (logging.root.level == logging.DEBUG) or debug_mode

        src_pathes = set()
        for url in urls_list:
            bucket, s3_path = re.sub(
                r'^{0}'.format(re.escape(self.endpoint + '/')), '', url  # pylint: disable=C0209
            ).split('/', 1)
            src_pathes.add((self.endpoint, bucket, s3_path))

        check_url_on_cloud_func = partial(Cloud.check_url_on_cloud, debug_mode=debug_mode)
        with Pool(self.threads_num, initializer=Cloud.initialize_mp_s3, initargs=(self.config,)) as pool:
            check_res = list(
                tqdm(
                    pool.imap(check_url_on_cloud_func, list(src_pathes)),
                    total=len(src_pathes),
                    disable=(logging.root.level == logging.DEBUG) or tqdm_off,
                )
            )
        return check_res

    def add_public_cors(self, bucket: str, urls: List[str]) -> Dict:
        try:
            cors = self.client.get_bucket_cors(Bucket=bucket).get('CORSRules', [])
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchCORSConfiguration':
                cors = []
            else:
                logger.exception(e)
                raise
        cors.append(
            {
                "AllowedHeaders": ["*"],
                "AllowedMethods": ["GET", "HEAD"],
                "AllowedOrigins": urls,
                "ExposeHeaders": ["*"],
                "MaxAgeSeconds": 30000,
            }
        )
        self.client.put_bucket_cors(Bucket=bucket, CORSConfiguration={'CORSRules': cors})
        return cors

import logging
import sys
from pathlib import Path
from typing import Union

import click

from crowd_sdk.cloud import Clouds
from crowd_sdk.core.utils.common import get_event_loop
from crowd_sdk.tagme import DEFAULT_CONFIG, CrowdTagmeConfig, TagmeClientAdvanced
from crowd_sdk.tagme.cli.group import tagme_commands

logger = logging.getLogger(__name__)


async def upload_pdfs(config_path: Union[str, Path], task_id: str, folder: Union[str, Path]) -> None:
    config = CrowdTagmeConfig.from_any(config_path)
    config.prompt_user_and_password_if_missing()

    client = TagmeClientAdvanced(config=config)
    cloud_client = Clouds(config_path).get('main')

    logger.info('Preprocessing uploading info.')

    result = await client.upload_folder_pdf(task_id=task_id, folder=folder, cloud_client=cloud_client)

    logger.info(f'Files successfully uploaded {result}')

    await client.close()


@tagme_commands.command(name='upload_pdf')
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
@click.option(
    '-t',
    '--task-id',
    required=True,
    help='Task id to upload file',
)
@click.option('-d', '--folder', type=click.Path(exists=True), required=True, help='Directory path')
def upload_pdf_cli(
    config_path: Union[str, Path],
    task_id: str,
    folder: Union[str, Path],
) -> None:
    """
    Upload files script
    """
    try:
        import fitz  # pylint: disable=C0415,W0611
    except ModuleNotFoundError:
        logging.error('Couldn\'t run upload_pdf without pymupdf module\nInstall:\npip install pymupdf==1.19.2\n')
        sys.exit(1)
    assert fitz.version[0] >= '1.19.2', 'pymupdf >= 1.19.2 required. Install: pip install pymupdf==1.19.2'

    get_event_loop().run_until_complete(
        upload_pdfs(
            config_path,
            task_id,
            folder,
        )
    )

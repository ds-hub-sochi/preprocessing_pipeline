import base64
import json
import logging
import random
import sys
import uuid
from io import BytesIO
from pathlib import Path
from typing import Union

import click

logger = logging.getLogger(__name__)


def image_segmentation_yolo2validation(image_folder_path: Union[str, Path], dest_folder_path: Union[str, Path]) -> None:
    try:
        from PIL import Image  # pylint:disable=C0415
    except ModuleNotFoundError:
        print('pip install Pillow')
        sys.exit(-1)

    image_folder_path = Path(image_folder_path)
    dest_folder_path = Path(dest_folder_path)
    dest_folder_path.mkdir(parents=True, exist_ok=True)
    class2entities(image_folder_path, dest_folder_path)
    for image_path in image_folder_path.glob('*.jpg'):
        yolo_path = image_path.with_suffix('.txt')
        image = Image.open(image_path)
        width, height = image.size

        marks_list = []
        with open(yolo_path) as yolo_file:
            yolo_lines = yolo_file.readlines()
            for line in yolo_lines:
                parts = line.split()
                dest_set = {
                    'id': str(uuid.uuid1()),
                    'entityId': f'entity-{parts[0]}',
                    'type': 'bbox',
                    'position': {
                        'x': float(parts[1]) * width - (float(parts[3]) * width / 2),
                        'y': float(parts[2]) * height - (float(parts[4]) * height / 2),
                        'width': float(parts[3]) * width,
                        'height': float(parts[4]) * height,
                    },
                }
                marks_list.append(dest_set)

        buffered = BytesIO()
        image.save(buffered, format='JPEG')
        img_str = base64.b64encode(buffered.getvalue()).decode('utf-8')
        to_json = {'image': img_str, 'marks': marks_list}
        with open((dest_folder_path / image_path.with_suffix('.json').name), 'w') as f:
            json.dump(to_json, f)


def class2entities(image_folder_path: Union[str, Path], dest_folder_path: Union[str, Path]) -> None:
    image_folder_path = Path(image_folder_path)
    dest_folder_path = Path(dest_folder_path)
    for class_path in image_folder_path.glob('classes.txt'):
        with open(class_path) as class_file:
            entitiy_list = []
            for idx, line in enumerate(class_file):
                dest_set = {
                    'id': f'entity-{idx}',
                    'name': line.rstrip('\r\n'),
                    'color': '#' + ''.join([random.choice('ABCDEF0123456789') for _ in range(6)]),
                    'tool': 'bbox',
                    'fields': [],
                }
                entitiy_list.append(dest_set)
            # to_json = {'entities': entitiy_list}
            # was specified, but not used
            with open((dest_folder_path / Path(class_path).with_suffix('.entities.json').name), 'w') as f:
                f.write('const ENTITIES = ')
                json.dump(entitiy_list, f)
                f.write(';')


@click.command()
@click.option('-f', '--src-folder', required=True, type=click.Path(exists=True), help='Folder with source files')
@click.option('-d', '--destination', required=True, help='Destination folder to save validation json-data for task')
def image_segmentation_yolo2validation_cli(
    src_folder: str,
    destination: str,
) -> None:
    """
    ImageSegmentation. Process image + yolo.txt to create data for validation task
    Outputs a JSON file for upload to TagMe to an image validation task
    """
    image_segmentation_yolo2validation(image_folder_path=src_folder, dest_folder_path=destination)
    logger.info('PrepareValidationData done')

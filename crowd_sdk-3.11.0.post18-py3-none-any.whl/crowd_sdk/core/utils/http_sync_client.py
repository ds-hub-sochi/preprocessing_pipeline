import json
import logging
from json.decoder import JSONDecodeError
from pathlib import Path
from typing import Any, Dict, Generator, List, Optional, Tuple, Union

import aiohttp
import requests.exceptions
from requests import HTTPError

from crowd_sdk.core.utils.common import urljoin_with_path
from crowd_sdk.core.utils.http import RETRY_HTTP_CODES, SyncHttpWrapper, retry_request_sync_supress
from crowd_sdk.core.utils.http_client import APIResponseError, AuthType, HttpMethod, ResponseType, add_trace_header

logger = logging.getLogger(__file__)


class JsonSyncAPI:
    def __init__(
        self,
        url: str,
        token: Optional[str] = None,
        http: Optional[SyncHttpWrapper] = None,
        auth_type: Union[AuthType, str] = AuthType.OAUTH,
    ) -> None:
        self.http = http or SyncHttpWrapper()
        self.url = url

        self.auth_type: str = auth_type.value if isinstance(auth_type, AuthType) else auth_type
        self.token = token
        assert self.auth_type, 'auth_type doesnt\'t set'

    @staticmethod
    def format_response(response_text: Optional[str]) -> Optional[str]:
        if response_text:
            try:
                response_text = json.dumps(json.loads(response_text), ensure_ascii=False, indent=2)
                return f'\nResponse: \n{response_text}'
            except json.JSONDecodeError:
                return f'\nResponse: {response_text}'

        return None

    def make_url(self, url: str) -> str:
        target_url = urljoin_with_path(self.url, url) if self.url else url
        return target_url

    def _request(  # pylint: disable=R0912, R0915
        self,
        method: HttpMethod,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        form: Optional[List[Dict[str, Any]]] = None,
        response_type: ResponseType = ResponseType.JSON_RESPONSE,
        ignore_statuses: Union[None, int, Tuple[int]] = None,
        raise_for_status: bool = True,
        **kwargs: Any,
    ) -> Any:
        """
        Send request and return json/text/raw response.

        Args:
            method (HttpMethod): http method to do request.
            url (str): target url.
            response_type (ResponseType, optional): json/text/raw type response. Defaults to ResponseType.JSON_RESPONSE.

        Raises:
            exc: automatically raise exception if response status is not in [200 .. 300) .

        Returns:
            Any: json/text/raw response.
        """

        kwargs['headers'] = headers or {}
        add_trace_header(kwargs['headers'])

        if form is not None:
            form_data = aiohttp.FormData(quote_fields=False)
            for field in form:
                form_data.add_field(**field)
            kwargs['data'] = form_data

        response = None
        response_text = None

        target_url = self.make_url(url)

        try:
            response = self.http.request(method=method.value, url=target_url, **kwargs)

            if response_type != ResponseType.RAW_RESPONSE:
                response_text = response.text

            if raise_for_status:
                response.raise_for_status()

            if response_type is ResponseType.RAW_RESPONSE:
                return response.content
            elif response_type is ResponseType.TEXT_RESPONSE:
                return response_text
            else:
                return response.json()

        except UnicodeDecodeError as exc:
            if response is not None:
                log_file = Path("~/UnicodeDecodeError.dump").expanduser()
                logger.exception(
                    'Processing the response caused an exception UnicodeDecodeError.'
                    'The response will be written to a file: %s',
                    log_file,
                    exc_info=exc,
                )
                with open(log_file, "wb") as f:
                    data_dump = response.read()
                    f.write(data_dump)
            raise

        except (JSONDecodeError, requests.exceptions.JSONDecodeError) as exc:
            if response is None or response.status_code >= 400:
                logger.error('Request to %s %s "%s" failed with json decode error', method.value, url, response)
                logger.exception(exc)
                raise

            logger.warning('Request to %s %s "%s" failed with json decode error', method.value, url, response)
            return None

        except HTTPError as exc:
            if ignore_statuses and exc.response:
                if isinstance(ignore_statuses, tuple) and exc.response.status_code in ignore_statuses:
                    return None
                if isinstance(ignore_statuses, int) and exc.response.status_code == ignore_statuses:
                    return None

            json_error = None
            if response is not None:
                try:
                    response_text = response.text
                    json_error = json.loads(response_text)

                except json.JSONDecodeError:
                    pass

            error_text = self.format_response(response_text)
            logger.error(
                'Request to %s %s failed with status code %s%s', method.value, url, exc.response.status_code, error_text
            )
            if exc.response.status_code == 403:
                logger.error('Headers %s', str(kwargs['headers']))
            raise APIResponseError.from_http_error(exc, json_error) from exc

        except Exception:
            error_text = self.format_response(response_text)
            logger.exception('Request to %s %s failed %s', method.value, url, error_text)
            raise

    def request(self, method: HttpMethod, url: str, headers: Optional[Dict[str, str]] = None, **kwargs: Any) -> Any:
        """
        Send request and return json/text/raw response.

        Args:
            method (HttpMethod): http method to do request.
            url (str): target url.

        Returns:
            Any: json/text/raw response.
        """
        headers = headers or {}
        if 'Authorization' not in headers:
            assert self.token, 'token doesnt\'t set'
            headers['Authorization'] = f'{self.auth_type} {self.token}'
        return self._request(method, url, headers=headers, **kwargs)

    async def raw_request(
        self, method: HttpMethod, url: str, headers: Optional[Dict[str, str]] = None, **kwargs: Any
    ) -> Any:
        """
        Send request and return raw response.

        Args:
            method: HttpMethod enum
            url (str): target url.
            **kwargs: any qiorequests params

        Returns:
            raw data from the response
        """
        headers = headers or {}
        if 'Authorization' not in headers:
            assert self.token, 'token doesnt\'t set'
            headers['Authorization'] = f'{self.auth_type} {self.token}'
        kwargs.update(headers=headers)
        kwargs.update(ssl=False)
        target_url = self.make_url(url)
        try:
            return self.http.request(method=method.value, url=target_url, **kwargs)
        except Exception as exc:
            logger.exception('Request to %s failed: [method %s, kwargs %s]', url, method, kwargs)
            raise exc

    @retry_request_sync_supress(statuses=RETRY_HTTP_CODES)
    def post(self, url: str, **kwargs: Any) -> Any:
        return self.request(method=HttpMethod.POST, url=url, **kwargs)

    @retry_request_sync_supress(statuses=RETRY_HTTP_CODES)
    def get(self, url: str, **kwargs: Any) -> Any:
        return self.request(method=HttpMethod.GET, url=url, **kwargs)

    @retry_request_sync_supress(statuses=RETRY_HTTP_CODES)
    def put(self, url: str, **kwargs: Any) -> Any:
        return self.request(method=HttpMethod.PUT, url=url, **kwargs)

    @retry_request_sync_supress(statuses=RETRY_HTTP_CODES)
    def patch(self, url: str, **kwargs: Any) -> Any:
        return self.request(method=HttpMethod.PATCH, url=url, **kwargs)

    @retry_request_sync_supress(statuses=RETRY_HTTP_CODES)
    def delete(self, url: str, **kwargs: Any) -> Any:
        return self.request(method=HttpMethod.DELETE, url=url, **kwargs)

    def gather(self, url: str, **kwargs: Any) -> Generator:
        has_more = True
        kwargs.update(sort=(kwargs.get('sort') or 'id'))

        while has_more:
            pools = self.get(url, params=kwargs)
            assert pools
            has_more = pools.get('has_more', False)
            for item in pools.get('items', []):
                yield item

            if has_more:
                kwargs.update(id_gt=pools['items'][-1]['id'])

    def close(self) -> None:
        pass

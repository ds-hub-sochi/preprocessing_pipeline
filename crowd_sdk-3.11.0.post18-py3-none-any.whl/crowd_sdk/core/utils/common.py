import asyncio
import datetime
import hashlib
import json
import logging
import sys
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass
from enum import Enum
from functools import partial
from pathlib import Path
from typing import Any, Callable, Dict, Generator, Iterable, List, Optional, Sequence, Tuple, TypeVar, Union, cast
from urllib.parse import urljoin, urlparse

import yaml
from dacite import Config, DaciteError, from_dict
from tqdm import tqdm

from crowd_sdk import DEFAULT_CONFIG

try:
    from envsubst import envsubst
except ImportError:

    def envsubst(x: Any) -> Any:
        return x


logger = logging.getLogger(__name__)

JsonObject = TypeVar("JsonObject", dict, float, int, list, str)
Item = TypeVar("Item")

DEFAULT_TAGME_REALM = 'tagme-public'
DATE_TIME_FORMATS = ('%Y-%m-%dT%H:%M:%S.%f', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M:%S.%f', '%Y-%m-%d %H:%M:%S')
DATE_TIME_UTC_FORMATS = ('%Y-%m-%dT%H:%M:%S.%f%z', '%Y-%m-%dT%H:%M:%S%z')
TASK_SUBMIT_DATETIME_FORMAT = '%Y-%m-%dT%H:%M:%S.%fz'
DATE_TIME_TOLOKA_FORMAT = '%Y-%m-%dT%H:%M:%S'
MSK_TIMEZONE = datetime.timezone(datetime.timedelta(hours=3))


@dataclass
class AuthConfig:
    url: Optional[str] = None
    auth_url: Optional[str] = None
    user: Optional[str] = None
    password: Optional[str] = None
    token: Optional[str] = None
    client_secret: Optional[str] = None
    client_cert_path: Optional[str] = None
    client_id: Optional[str] = None
    realm: Optional[str] = None

    @staticmethod
    def from_path(config_path: Union[Path, str] = DEFAULT_CONFIG) -> 'AuthConfig':
        config_path = Path(config_path).expanduser()

        if not config_path.is_file():
            raise ValueError(f'Config path is not a file: {config_path}')

        with config_path.open('r') as f:
            config_data = envsubst(f.read())
            file_data = yaml.safe_load(config_data)

        try:
            return from_dict(data_class=AuthConfig, data=file_data)
        except DaciteError as exp:
            raise TypeError(f'Expecting {config_path} to be a dict compatible to AuthConfig') from exp

    @staticmethod
    def from_any(
        config: Union[str, Path, dict, 'AuthConfig'] = DEFAULT_CONFIG,
    ) -> 'AuthConfig':
        config_path = ''  # for logging purposes, will not show any if no path specified

        if isinstance(config, AuthConfig):
            return config
        if isinstance(config, (str, Path)):
            config_path = str(config)
            return AuthConfig.from_path(config_path)
        if isinstance(config, dict):
            return from_dict(data_class=AuthConfig, data=config)

        raise TypeError(f'Wrong type for the config {type(config)}')

    def __post_init__(self) -> None:
        if not self.realm:
            self.realm = DEFAULT_TAGME_REALM
        if not self.client_id:
            raise ValueError('no client_id set for auth config')
        if not self.url:
            raise ValueError('no url set for auth config')
        if not self.auth_url:
            raise ValueError('no auth_url set for auth config')


def load_json(path: Union[str, Path]) -> JsonObject:
    """
    Load data from *.json file.

    Args:
        path (pathlib.Path): path to *.json file.

    Returns:
        JsonObject: data from file.
    """
    with open(path) as f:
        return json.load(f)


def dump_json(data: JsonObject, path: Union[str, Path]) -> None:
    """
    Dump data to *.json file.

    Args:
        data (JsonObject): any serializable to json python object.
        path (Path): path to output file.
    """
    with open(path, 'w') as f:
        json.dump(data, f)


def get_config(config_path: Union[str, Path] = DEFAULT_CONFIG) -> Dict[str, Any]:
    """
    Read config from *.yaml file.

    Args:
        config_path (Union[str, Path], optional): path to *.yaml file with config. Defaults to CONFIG_PATH.

    Returns:
        Dict[str, Any]: *.yaml file contents as python dict.
    """
    with open(config_path) as f:
        config = yaml.safe_load(f)
    return config


def custom_dict_factory(exclude: Tuple[str, ...] = cast(Tuple[str], ())) -> Callable[[Any], Dict[str, Any]]:
    """
    Functions factory returning dictionary factory.

    Args:
        exclude (Tuple[str], optional): ignored keys. Defaults to cast(Tuple[str], ()).

    Returns:
        Callable[[Any], Dict[str, Any]]: dictionary factory.
    """

    def wrapper(data: Any) -> Dict[str, Any]:
        """
        Convert dataclass as dictionary to request parameters.

        Args:
            data (Any): input data from dataclass.

        Returns:
            Dict[str, Any]: data in dictionary representation.
        """

        def convert(obj: Any) -> Any:
            """
            Convert dictionary value to right format.

            Args:
                obj (Any): dictionary value.

            Returns:
                Any: converted value.
            """
            if isinstance(obj, (list, tuple)):
                return [convert(item) for item in obj]

            obj_base_type = type(obj).mro()[-2]
            if obj_base_type in CAST_FROM_TYPES:
                return CAST_FROM_TYPES[obj_base_type](obj)

            return obj

        return dict((k, convert(v)) for k, v in data if v is not None and k not in exclude)

    return wrapper


def inplace_map_keys(dict_representation: Dict[str, Any], map_keys: Optional[List[Tuple[str, str]]]) -> None:
    if map_keys is not None:
        for previous_key, new_key in map_keys:
            if previous_key not in dict_representation:
                continue

            value = dict_representation.pop(previous_key)
            dict_representation[new_key] = value


def cast_params(map_keys: Optional[List[Tuple[str, str]]] = None, **kwargs: Any) -> Dict[str, Any]:
    def convert(obj: Any) -> Any:
        if isinstance(obj, bool):
            return str(obj).lower()

        if isinstance(obj, Enum):
            return obj.value

        if isinstance(obj, (list, tuple)) and obj and isinstance(obj[0], Enum):
            return [item.value for item in obj]

        return obj

    as_dict_representation = dict((k, convert(v)) for k, v in kwargs.items() if v is not None)
    inplace_map_keys(as_dict_representation, map_keys)
    return as_dict_representation


def dataclass_to_dict(
    datacls: Any, exclude: Tuple[str, ...] = cast(Tuple[str], ()), map_keys: Optional[List[Tuple[str, str]]] = None
) -> Dict[str, Any]:
    """
    Convert dataclass to request parameters.

    Args:
        datacls (Any): input dataclass.
        exclude (Tuple[str], optional): ignored dataclass attributes. Defaults to cast(Tuple[str], ()).
        map_keys (Optional[List[Tuple[str, str]]], optional): renameable attributes in dictionary. Defaults to None.

    Returns:
        Dict[str, Any]: dataclass in dictionary representation.
    """
    as_dict_representation = asdict(datacls, dict_factory=custom_dict_factory(exclude=exclude))
    inplace_map_keys(as_dict_representation, map_keys)
    return as_dict_representation


def str_to_bool(val: Union[bool, str, None]) -> Optional[bool]:
    """
    Convert string to bool.

    Args:
        val (Union[bool, str]): input string.

    Returns:
        Optional[bool]: bool or None.

    Example:
        str_to_bool('TrUe') -> True
        str_to_bool('false') -> False
        str_to_bool('not bool') -> None
    """
    if isinstance(val, bool):
        return val
    if isinstance(val, str):
        val = val.lower()
        if val in ('y', 'yes', 't', 'true', 'on', '1'):
            return True
        elif val in ('n', 'no', 'f', 'false', 'off', '0'):
            return False
        else:
            return None
    else:
        return None


def chunks(lst: Sequence[Item], n: int, tqdm_on: Union[bool, str] = False) -> Generator[List[Item], None, None]:
    """
    Iterate through the sequence in chunks.

    Args:
        lst (List[Item]): input sequence.
        n (int): chunk size.
        tqdm_on (Union[bool, str]): enable tqdm and set description

    Yields:
        Iterator[List[Item]]: chunk.
    """
    with tqdm(total=len(lst), desc=tqdm_on if isinstance(tqdm_on, str) else None, disable=(not tqdm_on)) as counter:
        for i in range(0, len(lst), n):
            chunk = list(lst[i : i + n])
            yield chunk

            counter.update(len(chunk))


def get_event_loop() -> asyncio.AbstractEventLoop:
    """
    Safe get event loop.

    Returns:
        asyncio.AbstractEventLoop: existing or created event loop
    """
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
    return loop


def md5(fname: Union[str, Path]) -> str:
    """
    Return md5 hash of file.

    Args:
        fname (Union[str, Path]): input file

    Returns:
        str: md5 hash
    """
    hash_md5 = hashlib.md5()
    with open(fname, 'rb') as f:
        for chunk in iter(lambda: f.read(4096), b''):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


def md5_str(text: str) -> str:
    """
    Return md5 hash of string.

    Args:
        text str: input string

    Returns:
        str: md5 hash
    """
    hash_md5 = hashlib.md5()
    hash_md5.update(text.encode())
    return hash_md5.hexdigest()


def md5_with_filename(fname: Union[str, Path]) -> Tuple[str, str]:
    """
    Return filename with md5 hash of file.

    Args:
        fname (Union[str, Path]): input file

    Returns:
        str: file name and md5 hash
    """
    return Path(fname).stem, md5(fname=fname)


def md5_mp(fnames: List[Union[str, Path]], n_pools: int, tqdm_off: bool = False) -> Dict[str, str]:
    """Return mapping of filename and it's md5 hash"""
    with ProcessPoolExecutor(max_workers=n_pools) as pool:
        hashes_dict = {
            Path(fname).name: hash_id
            for fname, hash_id in list(tqdm(pool.map(md5_with_filename, fnames), disable=tqdm_off))
        }
    return hashes_dict


def urljoin_with_path(url: str, additional_url: str) -> str:
    """
    urljoin with extra handler for case when url contains path part

    Args:
        url (str):
        additional_url (str):

    Returns:
        str

    Examples:
        urljoin_with_path('host:80/some_path', '/api/v1/get_value') -> 'host:80/some_path/api/v1/get_value'
        urljoin_with_path('host:80/some_path/', '/api/v1/get_value') -> 'host:80/some_path/api/v1/get_value'
        urljoin_with_path('host:80/some_path/', 'api/v1/get_value') -> 'host:80/some_path/api/v1/get_value'
        urljoin_with_path('host:80/', '/api/v1/get_value') -> 'host:80/api/v1/get_value'
        urljoin_with_path('host', '/api/v1/get_value') -> 'host/api/v1/get_value'
    """

    parsed_url = urlparse(url)
    result_url = url.rstrip('/') + '/' + additional_url.lstrip('/') if parsed_url.path else urljoin(url, additional_url)
    return result_url


def load_yaml(yaml_path: Union[str, Path]) -> Dict[str, Any]:
    with open(yaml_path, 'r') as stream:
        return yaml.safe_load(stream)


def merge(a: dict, b: dict, path: Optional[List[str]] = None, override: bool = False) -> Dict:
    """merges b into a"""
    if path is None:
        path = []

    for key in b:
        if key in a:
            if isinstance(a[key], dict) and isinstance(b[key], dict):
                merge(a[key], b[key], path + [str(key)])
            elif a[key] == b[key]:
                pass  # same leaf value
            else:
                if override:
                    a[key] = b[key]

                # print('Conflict at', '.'.join(path + [str(key)]), [a[key], b[key]])
        else:
            a[key] = b[key]
    return a


def parse_date(str_date: str, datetime_formats: Optional[Iterable[str]] = None) -> datetime.datetime:
    datetime_formats = datetime_formats or DATE_TIME_FORMATS
    ret: Optional[datetime.datetime] = None

    for data_fmt in datetime_formats:
        try:
            ret = datetime.datetime.strptime(str_date, data_fmt)
        except ValueError:
            pass

    if ret is None:
        raise ValueError(f"Can't parse date: '{str_date}' with patterns: {datetime_formats}")

    return ret


def parse_iso_date(str_date: str) -> datetime.datetime:
    """
    Alternate to datetime.fromisoformat for 3.6- compatibility
    """
    str_date = str_date.replace(' ', 'T').rstrip('Z')
    tz_sign = '+' if '+' in str_date else '-' if '-' in str_date.split('T', 1)[-1] else None

    if tz_sign:
        if sys.version_info.minor <= 6:
            date, tz = str_date.rsplit(tz_sign, 1)
            str_date = tz_sign.join((date, tz.replace(':', '')))

        if len(str_date) > 25:
            dt = datetime.datetime.strptime(str_date, '%Y-%m-%dT%H:%M:%S.%f%z')
        else:
            dt = datetime.datetime.strptime(str_date, '%Y-%m-%dT%H:%M:%S%z')

    else:
        if len(str_date) > 19:
            dt = datetime.datetime.strptime(str_date, '%Y-%m-%dT%H:%M:%S.%f').replace(tzinfo=datetime.timezone.utc)
        else:
            dt = datetime.datetime.strptime(str_date, '%Y-%m-%dT%H:%M:%S').replace(tzinfo=datetime.timezone.utc)

    return dt


def format_datetime_for_toloka(datetime_: datetime.datetime) -> str:
    return datetime_.strftime(DATE_TIME_TOLOKA_FORMAT)


def cast_to_datetime(value: str) -> datetime.datetime:
    return parse_iso_date(value).astimezone(tz=MSK_TIMEZONE)


def cast_to_date(value: str) -> datetime.date:
    return datetime.date(*map(int, value.split('-')))


CAST_FROM_TYPES = {
    Enum: lambda x: x.value,
    datetime.datetime: lambda x: x.isoformat(),
    datetime.date: lambda x: x.isoformat(),
}

CAST_TO_TYPES = {
    datetime.datetime: cast_to_datetime,
    datetime.date: cast_to_date,
}

dataclass_from_dict = partial(from_dict, config=Config(type_hooks=CAST_TO_TYPES, cast=[Enum, Tuple, int, float]))

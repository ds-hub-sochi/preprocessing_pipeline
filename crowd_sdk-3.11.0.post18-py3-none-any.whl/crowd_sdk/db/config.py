from dataclasses import dataclass
from typing import Optional

from crowd_sdk.core.config import CrowdConfig
from crowd_sdk.core.utils.common import dataclass_to_dict

SECTION_NAME = 'db'


@CrowdConfig.crowd_config_section(SECTION_NAME)
@dataclass
class DBConfig:
    host: str
    database: str
    user: str
    password: str
    port: Optional[int]

    def to_dict(self) -> dict:
        return dataclass_to_dict(self)

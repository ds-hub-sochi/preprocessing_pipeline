from dataclasses import dataclass
from typing import Any, List

import pandas as pd
from crowdkit.aggregation import DawidSkene as CrowdKitDawidSkene  # pylint: disable=import-error

DEFAULT_N_ITER = 100


@dataclass
class DawidSkeneEntryDataclass:
    task: str
    worker: str
    label: Any


@dataclass
class DawidSkeneResultDataclass:
    task: str
    pred: Any
    proba: float


def get_dawidskene_pred(
    data: List[DawidSkeneEntryDataclass], threshold: float, n_iter: int = DEFAULT_N_ITER
) -> List[DawidSkeneResultDataclass]:
    labels = {row.label for row in data}
    assert 'task' not in labels, 'Labels cant contains the name "task"!'
    aggregated_labels: pd.DataFrame = CrowdKitDawidSkene(n_iter=n_iter).fit_predict_proba(pd.DataFrame(data))
    aggregated_labels_list = aggregated_labels.reset_index().to_dict('records')
    aggregated_data = []
    for row in aggregated_labels_list:
        tmp_dict = {val: key for key, val in row.items() if key in labels}
        max_item_proba = max(tmp_dict)
        if max_item_proba >= threshold:
            key_with_max_value = tmp_dict[max_item_proba]
            aggregated_row = DawidSkeneResultDataclass(task=row['task'], pred=key_with_max_value, proba=max_item_proba)
            aggregated_data.append(aggregated_row)
    return aggregated_data

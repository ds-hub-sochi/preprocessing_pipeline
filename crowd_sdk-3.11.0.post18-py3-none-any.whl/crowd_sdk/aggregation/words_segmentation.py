import logging
import operator
from collections import defaultdict
from dataclasses import dataclass
from typing import List, Optional

import numpy as np
from scipy import stats

from crowd_sdk.aggregation.majority import MajorityEntryDataclass, aggregate_field

WORDS_THRESHOLD = 0.6
MAX_SEGMENT_LENGTH = 2

logger = logging.getLogger(__file__)


@dataclass
class WordsSegmentationEntryDataclass:
    task: str
    worker: str
    word_type: str
    word: str
    start: float
    end: float


@dataclass
class WordsSegmentationInnerDataclass:
    task: str
    word_type_pred: Optional[str]
    word_pred: Optional[str]
    start_pred: float
    end_pred: float


@dataclass
class WordsSegmentationResultDataclass:
    task: str
    word_type_pred: str
    word_pred: Optional[str]
    start_pred: float
    end_pred: float


def get_alternative_to_mean(data: List[float], is_start: bool) -> float:
    min_data = float(np.min(data))
    max_data = float(np.max(data))
    median_data = float(np.median(data))
    if is_start:
        return min(median_data, (min_data + max_data) * 0.5)
    else:
        return max(median_data, (min_data + max_data) * 0.5)


def get_mean_wout_tails(data: List[float], conf_level: float, is_start: bool) -> float:
    if len(set(data)) < 4:
        return get_alternative_to_mean(data=data, is_start=is_start)
    mean, sigma = np.mean(data), np.std(data)
    conf_min, conf_max = stats.norm.interval(conf_level, loc=mean, scale=sigma)
    return get_alternative_to_mean(data=[t for t in data if conf_min < t < conf_max], is_start=is_start)


def aggregate_one_segment(
    segment_data: List[WordsSegmentationEntryDataclass],
    distribution_threshold: float,
    words_threshold: float = WORDS_THRESHOLD,
) -> WordsSegmentationInnerDataclass:
    assert segment_data, 'Empty data!'

    task = segment_data[0].task

    starts = [row.start for row in segment_data]
    ends = [row.end for row in segment_data]

    start_pred = get_mean_wout_tails(data=starts, conf_level=distribution_threshold, is_start=True)
    end_pred = get_mean_wout_tails(data=ends, conf_level=distribution_threshold, is_start=False)

    # predict word
    words_to_agg_data = [
        MajorityEntryDataclass(task=row.task, worker=row.worker, label=row.word.lower().strip()) for row in segment_data
    ]
    word_pred_list = aggregate_field(data=words_to_agg_data, threshold=words_threshold)
    word_pred = str(word_pred_list[0].pred) if word_pred_list else None

    # predict word type
    words_types_to_agg_data = [
        MajorityEntryDataclass(task=row.task, worker=row.worker, label=row.word_type) for row in segment_data
    ]
    word_types_pred_list = aggregate_field(data=words_types_to_agg_data, threshold=words_threshold)
    word_type_pred = str(word_types_pred_list[0].pred) if word_types_pred_list else None

    return WordsSegmentationInnerDataclass(
        task=task, word_type_pred=word_type_pred, word_pred=word_pred, start_pred=start_pred, end_pred=end_pred
    )


def aggregate_one_task(
    task_segments: List[WordsSegmentationEntryDataclass],
    distribution_threshold: float,
    words_threshold: float = WORDS_THRESHOLD,
) -> List[WordsSegmentationResultDataclass]:
    task_segments = [i for i in task_segments if i.start is not None]

    if not task_segments:
        return []

    task_segments_sorted = sorted(task_segments, key=operator.attrgetter('start'))

    segmentation_result: List[WordsSegmentationResultDataclass] = []
    met_workers = set([task_segments_sorted[0].worker])
    workers_count = len({row.worker for row in task_segments})
    need_sum = max(2, workers_count * 0.25)

    union_start, union_end = task_segments_sorted[0].start, task_segments_sorted[0].end
    segment_data_for_agg: List[WordsSegmentationEntryDataclass] = [task_segments_sorted[0]]
    for segment in task_segments_sorted[1:]:
        if segment.end - segment.start > MAX_SEGMENT_LENGTH:
            logger.info(f'Segment length larger then {MAX_SEGMENT_LENGTH} seconds.')
            continue
        # тут проблема в том, что если 1 запись 1 человек размечал 2 раза,
        # то создастся несколько сегментов
        # поэтому добавляем условие, что если тот же автор,
        # то большая часть его сегмента лежит внутри рассматриваемого отрезка
        if union_start < segment.start < union_end and (
            segment.worker not in met_workers or ((union_end - segment.start) * 1.5 > (segment.end - segment.start))
        ):
            segment_data_for_agg.append(segment)
            union_end = max(union_end, segment.end)
            met_workers.add(segment.worker)
        else:
            if len(segment_data_for_agg) >= need_sum:
                one_segment = aggregate_one_segment(
                    segment_data=segment_data_for_agg,
                    distribution_threshold=distribution_threshold,
                    words_threshold=words_threshold,
                )
                if one_segment.word_type_pred is not None:
                    segmentation_result.append(
                        WordsSegmentationResultDataclass(
                            task=one_segment.task,
                            word_type_pred=one_segment.word_type_pred,
                            word_pred=one_segment.word_pred,
                            start_pred=one_segment.start_pred,
                            end_pred=one_segment.end_pred,
                        )
                    )
            segment_data_for_agg = [segment]
            met_workers = set([segment.worker])
            union_start = segment.start
            union_end = segment.end
    if len(segment_data_for_agg) >= need_sum:
        one_segment = aggregate_one_segment(
            segment_data=segment_data_for_agg,
            distribution_threshold=distribution_threshold,
            words_threshold=words_threshold,
        )
        if one_segment.word_type_pred is not None:
            segmentation_result.append(
                WordsSegmentationResultDataclass(
                    task=one_segment.task,
                    word_type_pred=one_segment.word_type_pred,
                    word_pred=one_segment.word_pred,
                    start_pred=one_segment.start_pred,
                    end_pred=one_segment.end_pred,
                )
            )
    return segmentation_result


def aggregate_segments(
    data: List[WordsSegmentationEntryDataclass],
    distribution_threshold: float,
    words_threshold: float = WORDS_THRESHOLD,
) -> List[WordsSegmentationResultDataclass]:
    tasks_segments_dict: defaultdict = defaultdict(list)
    for segment_data in data:
        tasks_segments_dict[segment_data.task].append(segment_data)

    aggregated_segments: List[WordsSegmentationResultDataclass] = []
    for _, task_segmets in tasks_segments_dict.items():
        task_pred = aggregate_one_task(
            task_segments=task_segmets,
            distribution_threshold=distribution_threshold,
            words_threshold=words_threshold,
        )
        if task_pred is not None:
            aggregated_segments.extend(task_pred)
    return aggregated_segments

from collections import defaultdict
from copy import deepcopy
from enum import Enum, unique
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple, Union

import attr
import numpy as np
import pandas as pd
from crowdkit.aggregation.annotations import (  # pylint: disable=import-error
    TASKS_TEXTS,
    TEXT_DATA,
    Annotation,
    manage_docstring,
)
from crowdkit.aggregation.base import BaseTextsAggregator  # pylint: disable=import-error
from tqdm.auto import tqdm

from crowd_sdk.core.utils.common import load_json

EMPTY_HYP_THRLD = 0.5
DEFAULT_MAX_CER = 100
MIN_MAJORITY_HYP_LEN = 2
MAJORITY_HYP_THRLD = 0.3
MIN_MAJORITY_HYP_FULL_QNT = 4
LEN_DST_THLD = 0.4
MIN_LONGEST_HYP_FILTER = 4
MIN_AGG_HYP_QNT = 3
MAX_HYP_LEN_CER_PRIORITY_MODE = 2
DEFAULT_AUTHOR_WER = 0.15
ALIGN_DEL_OPER_DIST = 1.5
BADAGG_CONF_THRLD = 0.3


class ClusterReference:
    """Class to load and contain cluster_values and cluster_index"""

    def __init__(self, cluster_reference_json_file: Union[str, Path]):
        cluster_values = defaultdict(list)
        cluster_index = {}
        data = load_json(cluster_reference_json_file)
        for entity in data:
            center_lower = entity['center'].lower()
            for cluster_reference in entity['cluster_values']:
                ref_lower = cluster_reference.lower()
                if ref_lower in cluster_index:
                    continue
                cluster_index[ref_lower] = center_lower
                cluster_values[center_lower].append(ref_lower)
            # sort in ascending order to do less computation during error calculation
            cluster_values[center_lower].sort(key=len)

        self.cluster_values = cluster_values
        self.cluster_index = cluster_index


@unique
class AlignmentAction(Enum):
    DELETION = 'DELETION'
    SUBSTITUTION = 'SUBSTITUTION'
    INSERTION = 'INSERTION'
    CORRECT = 'CORRECT'


@attr.s
class AlignmentEdge:
    value: Dict[str, Dict[str, float]] = attr.ib()
    sources_count: int = attr.ib()
    authors_wer: float = attr.ib()
    authors_wer_agg: float = attr.ib()
    norm_value: str = attr.ib()


@attr.s
@manage_docstring
class TunedROVER(BaseTextsAggregator):
    """
    Tuned Recognizer Output Voting Error Reduction (ROVER).
    """

    tokenizer: Callable[[str], List[str]] = attr.ib()
    detokenizer: Callable[[List[str]], str] = attr.ib()
    silent: bool = attr.ib(default=True)

    @manage_docstring
    def fit(  # pylint: disable=too-many-statements, too-many-branches, too-many-locals, arguments-differ
        self,
        data: TEXT_DATA,
        cl_ref: Optional[ClusterReference] = None,
        normalizer: Optional[Callable] = None,
    ) -> Annotation(type='TunedROVER', title='self'):  # type: ignore
        """
        Fits the model. The aggregated results are saved to the `texts_` attribute.
        """

        result = {}
        result_badagg = {}

        grouped_tasks = data.groupby('task') if self.silent else tqdm(data.groupby('task'))
        for task, df in grouped_tasks:
            # empty hyps issue fix
            df['text'] = df['text'].fillna('')
            if float(df.query("text == ''").shape[0]) / df.shape[0] > EMPTY_HYP_THRLD:
                result[task] = ''
                continue
            df = df.query("text != ''")

            # getting best hyp via voting, taking into account author's markup quality
            # if no quality info provided or it's default 0 -  don't consider it when choosing
            hyps_dict: Dict[str, Tuple[int, float]] = {}
            for _, row in df.iterrows():
                text = row['text']
                cer = row['cer']
                if text in hyps_dict:
                    text_counter, tmp_quality = hyps_dict[text]
                    text_counter += 1
                    hyps_dict[row['text']] = (text_counter, min(tmp_quality, cer) if cer > 0 else tmp_quality)
                    continue
                hyps_dict[row['text']] = (1, cer if cer and cer > 0 else DEFAULT_MAX_CER)

            # sorting by text_counter (descending) and by CER (ascending) for equal text_counters
            most_common_hyp = sorted(hyps_dict.items(), key=lambda item: (-item[1][0], item[1][1]))[0]
            most_voting_text = most_common_hyp[0]
            voting_value = most_common_hyp[1][0]

            # returning most voted hyp as agg. result if selected hyp is long enough
            # and more than MAJORITY_HYP_THRLD hyps voted for it
            if (
                len(most_voting_text.split(' ')) > MIN_MAJORITY_HYP_LEN
                and voting_value > df.shape[0] * MAJORITY_HYP_THRLD
                and df.shape[0] >= MIN_MAJORITY_HYP_FULL_QNT
            ):
                result[task] = most_voting_text
                continue

            all_texts = list(df.text)
            longest = sorted(all_texts, key=lambda txt: len(txt.split(' ')))[-1]

            longest_len = len(longest.split(' '))

            # removing too short hyps, as they corrupt alignment
            for text in all_texts:
                if longest_len >= MIN_LONGEST_HYP_FILTER and len(text.split(' ')) < longest_len * LEN_DST_THLD:
                    df = df[df['text'] != text]

            # TODO: insert check before majority agg?
            if df.shape[0] < MIN_AGG_HYP_QNT:
                result_badagg[task] = most_voting_text
                continue

            # prioritize hyp aggregated CER for short hyps
            cer_priority_mode = bool(longest_len <= MAX_HYP_LEN_CER_PRIORITY_MODE)

            hypotheses = [self.tokenizer(text) for _, text in enumerate(df['text'])]

            # build dict with every token stemming to be used in alignment, WTN construction, edge-voting
            norm_hyps = {}
            if normalizer:
                for _, text in enumerate(df['text']):
                    norm_hyps.update({word: normalizer(word) for word in text.split(' ')})

            # fill-up empty author's CER with default value
            if not 'cer' in df.columns:
                df['cer'] = None
            authors_wer = df['cer'].fillna(DEFAULT_AUTHOR_WER).to_list()

            # init dict for token incorrect repeat check during edge join
            max_token_repeat = {}
            max_token_repeat[''] = float('inf')

            edges = self._build_word_transition_network(
                hypotheses, authors_wer, max_token_repeat, cer_priority_mode, cl_ref, norm_hyps
            )
            rover_result, is_badagg = self._get_result(edges, max_token_repeat, cer_priority_mode)

            text = self.detokenizer([value for value in rover_result if value != ''])
            if not is_badagg:
                result[task] = text
            else:
                result_badagg[task] = text

        result_series = pd.Series(result, name='text')
        result_series.index.name = 'task'
        self.texts_ = result_series  # pylint: disable=attribute-defined-outside-init

        result_badagg_series = pd.Series(result_badagg, name='text')
        result_badagg_series.index.name = 'task'
        self.texts_badagg_ = result_badagg_series  # pylint: disable=attribute-defined-outside-init

        return self

    @manage_docstring
    def fit_predict(  # pylint: disable=arguments-differ
        self,
        data: TEXT_DATA,
        cluster_reference_path: Optional[Union[str, Path]] = None,
        normalizer: Optional[Callable] = None,
    ) -> TASKS_TEXTS:
        """
        Fit the model and return the aggregated texts.
        """
        cl_ref = (
            ClusterReference(cluster_reference_json_file=cluster_reference_path) if cluster_reference_path else None
        )

        self.fit(data, cl_ref, normalizer=normalizer)
        return self.texts_, self.texts_badagg_

    def _build_word_transition_network(
        self,
        hypotheses: List[List[str]],
        authors_wer: List[float],
        max_token_repeat: Optional[Dict[str, float]],
        cer_priority_mode: bool,
        cl_ref: Optional[ClusterReference],
        norm_hyps: Optional[Dict[str, str]],
    ) -> List[Dict[str, AlignmentEdge]]:
        # choosing longest hyp. as BASE WTN
        if not cer_priority_mode:
            hypotheses, authors_wer = zip(  # type: ignore
                *sorted(zip(hypotheses, authors_wer), key=lambda hyp: (len(hyp[0]), -hyp[1]), reverse=True)
            )
        else:
            hypotheses, authors_wer = zip(  # type: ignore
                *sorted(zip(hypotheses, authors_wer), key=lambda hyp: (-hyp[1], len(hyp[0])), reverse=True)
            )

        edges = [
            {edge.norm_value: edge}
            for edge in self._get_edges_for_words(hypotheses[0], authors_wer[0], norm_hyps, max_token_repeat)
        ]
        for sources_count, hyp in enumerate(hypotheses[1:], start=1):
            edges = self._align(
                edges,
                self._get_edges_for_words(hyp, authors_wer[sources_count], norm_hyps, max_token_repeat),
                sources_count,
                cl_ref,
            )
        return edges

    @staticmethod
    def _get_edges_for_words(
        words: List[str],
        cur_author_wer: float,
        norm_hyps: Optional[Dict[str, str]],
        max_token_repeat: Optional[Dict[str, float]] = None,
    ) -> List[AlignmentEdge]:
        norm_hyps = norm_hyps or {}
        if max_token_repeat:
            word_last_idx: Dict[str, int] = {}
            word_repeat_qnt: Dict[str, int] = {}

            # filling-up dict to check token incorrect repeatings during edge join
            for idx, word in enumerate(words):
                if word in word_last_idx and (idx - word_last_idx[word]) == 1:
                    word_last_idx[word] = idx
                    word_repeat_qnt[word] += 1

                    if word not in max_token_repeat:
                        max_token_repeat[word] = word_repeat_qnt[word]
                    else:
                        max_token_repeat[word] = max(max_token_repeat[word], word_repeat_qnt[word])

                    continue

                word_last_idx[word] = idx
                word_repeat_qnt[word] = 1

                if word not in max_token_repeat:
                    max_token_repeat[word] = 1

        # special treatment of negative prefix "не" as it is often splitted/joined
        # with next word differently within same hyps set
        edges_res = []
        prefix = False

        prev_word = '@'
        for word in words:
            if word == 'не':
                # in case of multiple 'не' repeated
                if prev_word == 'не':
                    edges_res.append(
                        AlignmentEdge(
                            {'не': {'cer': cur_author_wer, 'source_count': 1}},
                            1,
                            cur_author_wer,
                            1.0,
                            norm_hyps.get(word, word),
                        )
                    )
                    continue

                prev_word = word
                prefix = True
                continue

            if prefix:
                edges_res.append(
                    AlignmentEdge(
                        {f'не {word}': {'cer': cur_author_wer, 'source_count': 1}},
                        1,
                        cur_author_wer,
                        1.0,
                        norm_hyps.get(word, word),
                    )
                )
                prefix = False
            else:
                edges_res.append(
                    AlignmentEdge(
                        {word: {'cer': cur_author_wer, 'source_count': 1}},
                        1,
                        cur_author_wer,
                        1.0,
                        norm_hyps.get(word, word),
                    )
                )

            prev_word = word

        if prefix:
            edges_res.append(
                AlignmentEdge(
                    {'не': {'cer': cur_author_wer, 'source_count': 1}},
                    1,
                    cur_author_wer,
                    1.0,
                    norm_hyps.get('не', 'не'),
                )
            )

        return edges_res

    @staticmethod
    def _align(  # pylint: disable=too-many-branches, too-many-statements
        ref_edges_sets: List[Dict[str, AlignmentEdge]],
        hyp_edges: List[AlignmentEdge],
        sources_count: int,
        cl_ref: Optional[ClusterReference] = None,
    ) -> List[Dict[str, AlignmentEdge]]:
        """Sequence alignment algorithm implementation.

        Aligns a sequence of sets of tokens (edges) with a sequence of tokens using dynamic programming algorithm. Look
        for section 2.1 in https://doi.org/10.1109/ASRU.1997.659110 for implementation details. Penalty for
        insert/deletion or mismatch is 1.

        Args:
           ref_edges_sets: Sequence of sets formed from previously aligned sequences.
           hyp_edges: Tokens from hypothesis (currently aligned) sequence.
           sources_count: Number of previously aligned sequences.
        """

        distance = np.zeros((len(hyp_edges) + 1, len(ref_edges_sets) + 1))
        distance[:, 0] = np.arange(len(hyp_edges) + 1)
        distance[0, :] = np.arange(len(ref_edges_sets) + 1)

        memoization: List[List[Optional[Tuple[AlignmentAction, dict, AlignmentEdge]]]] = [
            [None] * (len(ref_edges_sets) + 1) for _ in range(len(hyp_edges) + 1)
        ]
        for i, hyp_edge in enumerate(hyp_edges, start=1):
            memoization[i][0] = (
                AlignmentAction.INSERTION,
                {
                    '': AlignmentEdge({'': {'cer': 1.0, 'source_count': 1}}, 1, 0.5, 0.5, '')
                },  # passing 1.0 as initial source_count
                hyp_edge,
            )
        for i, ref_edges in enumerate(ref_edges_sets, start=1):
            memoization[0][i] = (
                AlignmentAction.DELETION,
                ref_edges,
                AlignmentEdge({'': {'cer': 1.0, 'source_count': 1}}, 1, 0.5, 0.5, ''),
            )

        # find alignment minimal cost using dynamic programming algorithm
        for i, hyp_edge in enumerate(hyp_edges, start=1):  # pylint: disable=too-many-nested-blocks
            hyp_word_norm = hyp_edge and hyp_edge.norm_value
            for j, ref_edges in enumerate(ref_edges_sets, start=1):
                ref_words_set = ref_edges.keys()

                # using word stem instead of word itsef for more robust alignment
                is_hyp_word_in_ref = hyp_word_norm in ref_words_set

                # checking for word cluster values
                if cl_ref and (not is_hyp_word_in_ref):
                    if hyp_word_norm and hyp_word_norm in cl_ref.cluster_values:
                        for cluster_value in cl_ref.cluster_values[hyp_word_norm]:
                            if cluster_value in ref_words_set:
                                is_hyp_word_in_ref = True

                                break

                options = []

                if is_hyp_word_in_ref:
                    options.append(
                        (
                            distance[i - 1, j - 1],
                            (AlignmentAction.CORRECT, ref_edges, hyp_edge),
                        )
                    )
                else:
                    options.append(
                        (
                            distance[i - 1, j - 1] + 1,
                            (AlignmentAction.SUBSTITUTION, ref_edges, hyp_edge),
                        )
                    )
                options.append(
                    (
                        distance[i, j - 1] + ALIGN_DEL_OPER_DIST,  # custom deletion penalty
                        (
                            AlignmentAction.DELETION,
                            ref_edges,
                            AlignmentEdge({'': {'cer': 1.0, 'source_count': 1}}, 1, 0.5, 1.0, ''),
                        ),
                    )
                )
                options.append(
                    (
                        distance[i - 1, j] + 1.0,
                        (
                            AlignmentAction.INSERTION,
                            {'': AlignmentEdge({'': {'cer': 1.0, 'source_count': 1}}, sources_count, 0.5, 1.0, '')},
                            hyp_edge,
                        ),
                    )
                )

                # custom AlignmentActions comparator for determined operation sorting
                # def cmpr(opt: Tuple[float, Tuple[AlignmentAction, Union[Dict[str: AlignmentEdge],
                #               AlignmentEdge], Union[Dict[str: AlignmentEdge], AlignmentEdge]]]):
                def cmpr(opt):  # type: ignore
                    oper_num = -1

                    if opt[1][0] == AlignmentAction.CORRECT:
                        oper_num = 0
                    if opt[1][0] == AlignmentAction.DELETION:
                        oper_num = 1
                    elif opt[1][0] == AlignmentAction.INSERTION:
                        oper_num = 2
                    elif opt[1][0] == AlignmentAction.SUBSTITUTION:
                        oper_num = 3

                    return (opt[0], oper_num)

                distance[i, j], memoization[i][j] = min(options, key=cmpr)

        alignment = []
        i = len(hyp_edges)
        j = len(ref_edges_sets)

        # reconstruct answer from dp array
        while i != 0 or j != 0:
            align_item = memoization[i][j]
            assert align_item is not None, f"Memoization is: {memoization}"
            action, ref_edges, hyp_edge = align_item
            joined_edges = deepcopy(ref_edges)
            hyp_edge_word = hyp_edge.norm_value
            if hyp_edge_word not in joined_edges:
                joined_edges[hyp_edge_word] = hyp_edge
            else:
                # if word is already in set increment sources count for future score calculation
                cur_unnorm_word = list(hyp_edge.value.keys())[0]
                if cur_unnorm_word in joined_edges[hyp_edge_word].value:
                    joined_edges[hyp_edge_word].value[cur_unnorm_word]['source_count'] += 1
                    joined_edges[hyp_edge_word].value[cur_unnorm_word]['cer'] = min(
                        joined_edges[hyp_edge_word].value[cur_unnorm_word]['cer'],
                        hyp_edge.value[cur_unnorm_word]['cer'],
                    )
                else:
                    joined_edges[hyp_edge_word].value[cur_unnorm_word] = hyp_edge.value[cur_unnorm_word]

                joined_edges[hyp_edge_word].sources_count += 1
                joined_edges[hyp_edge_word].authors_wer += hyp_edge.authors_wer

            joined_edges[hyp_edge_word].authors_wer_agg = np.tanh(
                1.0 - float(joined_edges[hyp_edge_word].authors_wer) / joined_edges[hyp_edge_word].sources_count
            )

            alignment.append(joined_edges)
            if action in (AlignmentAction.CORRECT, AlignmentAction.SUBSTITUTION):
                i -= 1
                j -= 1
            elif action == AlignmentAction.INSERTION:
                i -= 1
            # action == AlignmentAction.DELETION
            else:
                j -= 1

        return alignment[::-1]

    @staticmethod
    def _get_result(
        edges: List[Dict[str, AlignmentEdge]], max_token_repeat: Dict[str, float], cer_priority_mode: bool = False
    ) -> Tuple[List[str], bool]:
        result = []

        # checking for incorrect token repeatings using dict build up before alignment
        repeats_left: Union[float, int] = -1

        # setting initial value as non-existing token
        prev_value = '@'

        single_hyp_edges_count = 0
        for edges_set in edges:
            # conditioned edge sorting order
            if not cer_priority_mode:
                _, _, _, _, values = max(
                    (
                        x.sources_count,
                        (x.authors_wer_agg**2) * x.sources_count,
                        max(len(cur_key) for cur_key in x.value.keys()),
                        max(x.value.keys()),
                        x.value,
                    )
                    for x in edges_set.values()
                )
            else:
                _, _, _, _, values = max(
                    (
                        (x.authors_wer_agg**2) * x.sources_count,
                        x.sources_count,
                        max(len(cur_key) for cur_key in x.value.keys()),
                        max(x.value.keys()),
                        x.value,
                    )
                    for x in edges_set.values()
                )

            # voting within edge for different forms of words with same stem (norm_word)
            value, _ = sorted(values.items(), key=lambda item: (-item[1]['source_count'], item[1]['cer']))[0]

            # checking for bad_agg
            cur_max_source_count = max(x.sources_count if x.value != '' else 0 for x in edges_set.values())
            if cur_max_source_count == 1:
                single_hyp_edges_count += 1

            # TODO: check other possible values if repeat limit is overreached for max val chosen firstly
            if value.split(' ')[0] != prev_value:
                repeats_left = -1
            else:
                if repeats_left == -1:
                    repeats_left = max_token_repeat[value.split(' ')[0]] - 1
                else:
                    repeats_left -= 1

                if repeats_left <= 0:
                    if len(value.split(' ')) > 1:
                        result.append(value.split(' ')[-1])
                        prev_value = value.split(' ')[-1]
                        repeats_left = -1
                    continue

            if value and value != ' ' and value != '':
                prev_value = value.split(' ')[-1]
                if len(value.split(' ')) > 1:
                    repeats_left = -1

            result.append(value)

        is_badagg = bool(float(single_hyp_edges_count) / len(edges) >= BADAGG_CONF_THRLD)

        return result, is_badagg

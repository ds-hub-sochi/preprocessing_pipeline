import logging
import re
from asyncio import AbstractEventLoop
from dataclasses import asdict
from functools import partial
from typing import Any, Callable, Coroutine, Dict, List, Optional

from aiogram import Bot, Dispatcher, executor  # pylint: disable=import-error
from aiogram.bot.api import TelegramAPIServer  # pylint: disable=import-error
from aiogram.types import ContentType, InputFile, Message  # pylint: disable=import-error,unused-import
from aiogram.utils.exceptions import NetworkError  # pylint: disable=import-error
from aiohttp.client_exceptions import ClientConnectionError

from crowd_sdk.telegram.common import filter_bot_commands, filter_by_chat, multiple_filters
from crowd_sdk.telegram.datacls import HandlerTools, TGBotConfig, TGHandler


class HandlersComposite:
    def __init__(self, tools: HandlerTools, start_handler: Optional[Callable[[Any], Coroutine]] = None):
        self.handlers: List[TGHandler] = []
        self.tools = tools
        self.start_handler = start_handler

    async def __call__(self, message: Message, content_type: ContentType) -> None:
        for handler in self.handlers:
            if handler.content_type is not content_type:
                continue
            match = re.match(handler.pattern, message.text)
            if match:
                kwargs = self.create_handler_kwargs(handler=handler, match=match)
                kwargs['message'] = message
                kwargs['tools'] = self.tools
                try:
                    await handler.func(**kwargs)
                except NetworkError as error:
                    logging.error(error, exc_info=True)
                    await message.reply('Сервер не отвечает, попробуй чуть позже.')
                except ClientConnectionError as error:
                    logging.error(error, exc_info=True)
                    await message.reply('Ошибка сервера, попробуй позже еще раз.')

    @staticmethod
    def get_handler_params(handler: Callable) -> List[str]:
        params = []
        for n, item in enumerate(handler.__code__.co_varnames):
            if item in ['self']:
                continue
            if n >= handler.__code__.co_argcount:
                break
            params.append(item)
        # remove first argument - message and last - tools in handler
        params = params[1:-1]
        return params

    @staticmethod
    def create_handler_kwargs(handler: TGHandler, match: Any) -> Dict[str, Any]:
        params = HandlersComposite.get_handler_params(handler.func)
        kwargs = {}
        for index, name in enumerate(params):
            try:
                kwargs[name] = match.group(index + 1)
            except IndexError:
                kwargs[name] = None
        return kwargs

    async def start(self, message: Message) -> None:  # pylint: disable=W0613
        if self.start_handler is None:
            await self.help(message=message)
        else:
            await self.start_handler(message)

    async def help(self, message: Message) -> None:  # pylint: disable=W0613
        commands: List[str] = []
        for handler in self.handlers:
            if handler.ignore_help:
                continue
            commands.append(
                f'Команда {handler.func.__name__}  включается по шаблону {handler.pattern}, его параметры: '
                + " ".join(self.get_handler_params(handler.func))
            )
        await message.reply(text='\n'.join(commands) or 'Нет обработчика /help и не найдены обработчики команд')

    def add_handler(
        self, pattern: str, help_: str = '', ignore_help: bool = False, content_type: ContentType = ContentType.TEXT
    ) -> Callable:
        def add(handler_func: Callable) -> Callable:
            self.handlers.append(
                TGHandler(
                    func=handler_func, pattern=pattern, help_=help_, ignore_help=ignore_help, content_type=content_type
                )
            )
            return handler_func

        return add


async def echo_callback(message: Message) -> None:  # pylint: disable=W0613
    await message.reply(text=message.text)


def _dummy_filter(_: Message) -> bool:
    return True


class TGBot:
    """
    filter_chats_by_name: bot works only in chats
    filter_commands: bot works only with commands
    """

    def __init__(
        self,
        config: TGBotConfig,
        handlers_composite: HandlersComposite,
        chats: Optional[List[int]] = None,
        test_mode: Optional[bool] = False,
        bot_name: Optional[str] = None,
    ) -> None:
        self.config = config
        self.handlers_composite = handlers_composite
        self.chats = chats or []
        self.test_mode = test_mode
        self.bot_name = bot_name or ''
        bot_config = asdict(config)
        token = bot_config.pop('token')
        self.bot = Bot(token=token, server=TelegramAPIServer(base=config.base, file=config.file))
        self.dispatcher = Dispatcher(self.bot)
        self._init_handler()

    def _init_handler(self) -> None:
        chat_filter = filter_by_chat(self.chats) if self.chats else _dummy_filter
        msg_filter: Callable[[Any], bool] = _dummy_filter
        if self.bot_name:
            msg_filter = multiple_filters([chat_filter, partial(filter_bot_commands, bot_commands=self.bot_name)])
        self.dispatcher.message_handler(chat_filter, commands=['start'])(self.handlers_composite.start)
        self.dispatcher.message_handler(chat_filter, commands=['help'])(self.handlers_composite.help)
        for content_type in {handler.content_type for handler in self.handlers_composite.handlers}:
            self.dispatcher.message_handler(msg_filter, content_types=content_type)(
                partial(self.handlers_composite, content_type=content_type)
            )
        handlers_names = ', '.join(handler.func.__name__ for handler in self.handlers_composite.handlers)
        logging.info('Added Handler with handle_funcs: %s', handlers_names)

    def run(
        self, loop: Optional[AbstractEventLoop] = None, timeout: int = 20, relax: float = 0.5, fast: bool = True
    ) -> None:
        executor.start_polling(self.dispatcher, skip_updates=True, loop=loop, timeout=timeout, relax=relax, fast=fast)

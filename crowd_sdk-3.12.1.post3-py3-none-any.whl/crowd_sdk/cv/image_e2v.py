import base64
import json
import logging
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import click
from click import DateTime

from crowd_sdk.core.utils.common import dataclass_to_dict, get_event_loop
from crowd_sdk.tagme import DEFAULT_CONFIG, TagmeClientAdvanced
from crowd_sdk.tagme.config import TagmeConfig
from crowd_sdk.tagme.const import TASK_SUBMIT_DATETIME_FORMAT, PeriodEnum

logger = logging.getLogger(__name__)


async def image_segmentation_export2validation(
    config: TagmeConfig,
    export_file: Union[str, Path],
    destination_file: Union[str, Path],
    as_base64: bool,
    organization_name: Optional[str],
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
) -> None:
    client = TagmeClientAdvanced(config=config)
    config.org = organization_name or config.org
    destination_file = Path(destination_file)
    export_file = Path(export_file)
    destination_file.mkdir(parents=True, exist_ok=True)

    markers = await client.get_employees(with_info=True)
    marker_info_dict = {marker.person_id: marker.person for marker in markers}

    with open(export_file, encoding='utf-8') as export_f:
        templates: List[Dict[str, Any]] = json.load(export_f)

    for item in templates:
        entity_id = item['entity_id']
        task_id = item['task_id']

        for marker in item['result']:
            if start_date and end_date:
                submit_date = datetime.strptime(item['result'][marker]['submit_date'], TASK_SUBMIT_DATETIME_FORMAT)
                if not start_date <= submit_date.date() <= end_date:
                    continue

            marks = item['result'][marker]['result']['marks']

            final_path = destination_file / task_id
            final_path.mkdir(parents=True, exist_ok=True)

            if as_base64:
                if marker in marker_info_dict:
                    marker_info = dataclass_to_dict(marker_info_dict.get(marker))
                else:
                    marker_info = None
                to_json = {
                    'filename': f'{client.url}/ui/storage/{task_id}/{entity_id}',
                    'marks': marks,
                    'marker': marker_info,
                    'original_filename': item['file_name'],
                }
            else:
                image = await client.download_file(task_id, entity_id)
                to_json = {'image': base64.b64encode(image).decode('utf-8'), 'marks': marks}
            with open(final_path / (entity_id + '.json'), 'w') as f:
                json.dump(to_json, f)
    await client.close()


@click.command()
@click.option('-e', '--export-file', required=True, help='Exported file from ImageSegmentation task')
@click.option('-d', '--destination-file', required=True, help='Destination file to save extended result')
@click.option('--base64', 'as_base64', is_flag=True, default=False, help='Download image data and encode into base64')
@click.option('-o', '--organization-name', help='Organization name')
@click.option(
    '-p',
    '--period',
    type=click.Choice(list(stand.value for stand in PeriodEnum)),
    default=PeriodEnum.all.value,
    help=f'Time period for results. Available options: {list(stand.value for stand in PeriodEnum)}',
)
@click.option(
    '--exact-date', type=DateTime(formats=["%Y-%m-%d"]), help='Results for selected date for --period="exact-date"'
)
@click.option('--date-start', type=DateTime(formats=["%Y-%m-%d"]), help='Results start date for --period="period"')
@click.option('--date-end', type=DateTime(formats=["%Y-%m-%d"]), help='Results end date for --period="period"')
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
def image_segmentation_export2validation_cli(
    export_file: str,
    destination_file: str,
    as_base64: bool,
    organization_name: Optional[str],
    config_path: str,
    period: str,
    exact_date: datetime,
    date_start: datetime,
    date_end: datetime,
) -> None:
    """
    ImageSegmentation. Process TagMe export file to create data for validation task

    From source images that were uploaded to a task and task export file creates extended data for validation task
    Outputs a collection of json files for upload to TagMe to an image validation task

    IMPORTANT: task should be adapted for JSON file processing:
        const MARKUP_SETTINGS = {
         async prepareTask(task) {
           const res = await fetch(task.filename);
           let content = await res.json();
           return {
             title: "Разметка изображений",
             shortDescription: "Выберите класс и выделите часть картинки",
             image: content.filename,
             marks: content.marks,
             ...

    P.S.: if original task was created with premarkup (uploaded JSON and not images) then script has to be modified
    or JS validation tasks
    """

    config = TagmeConfig.from_any(config_path)
    config.prompt_user_and_password_if_missing()

    start_date, end_date = PeriodEnum[period].get_start_and_end_date(
        exact_date=exact_date and exact_date.date(),
        date_start=date_start and date_start.date(),
        date_end=date_end and date_end.date(),
    )

    get_event_loop().run_until_complete(
        image_segmentation_export2validation(
            config=config,
            export_file=export_file,
            destination_file=destination_file,
            as_base64=as_base64,
            organization_name=organization_name,
            start_date=start_date,
            end_date=end_date,
        )
    )

    logger.info('PrepareValidationData done')

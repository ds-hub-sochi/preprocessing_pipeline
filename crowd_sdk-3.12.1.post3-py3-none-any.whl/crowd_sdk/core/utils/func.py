import logging
from typing import Any

logger = logging.getLogger(__name__)


class Runnable:
    def run_command(self, command: str, **kwargs: Any) -> Any:
        """
        This wrapper attempts to fill all keyword arguments in command
        with data from kwargs and runs the command

        :param command: command to run
        :param kwargs: arguments dict to search keyword args in
        """

        param_str = ' '.join([f'{k}={v}' for k, v in kwargs.items()])
        logger.debug(f'{command}: {param_str}')
        try:
            func = getattr(self, command)
        except AttributeError as e:
            raise NotImplementedError(command) from e
        params = {}
        for n, item in enumerate(func.__code__.co_varnames):
            if item == 'self':
                continue
            if n >= func.__code__.co_argcount:
                break
            if item in kwargs:
                params[item] = kwargs.get(item)
        return func(**params)

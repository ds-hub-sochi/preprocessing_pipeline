from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Tuple, Type, TypeVar, Union

from dacite import from_dict

from crowd_sdk.core.utils.common import load_json, load_yaml

Class = TypeVar("Class")

#################################### MIXINS ####################################


@dataclass
class FromDictMixin:
    @classmethod
    def from_dict(cls: Type[Class], data: Dict[str, Any]) -> Class:
        return from_dict(data_class=cls, data=data)


@dataclass
class FromPathMixin:
    @classmethod
    def from_path(cls: Type[Class], path: Union[str, Path], file_type: str) -> Class:
        if file_type == 'json':
            data = load_json(path)
        elif file_type == 'yaml':
            data = load_yaml(path)
        else:
            raise ValueError(f"Strange file type: '{file_type}'")

        return from_dict(data_class=cls, data=data)


@dataclass
class AsDictMixin:
    def asdict(self, ignore_attrs: Tuple[str, ...] = (), ignore_none: bool = False) -> Dict[str, Any]:
        data = asdict(self)
        if ignore_none:
            data = {k: v for k, v in data.items() if v is not None}
        return {k: v for k, v in data.items() if k not in ignore_attrs}

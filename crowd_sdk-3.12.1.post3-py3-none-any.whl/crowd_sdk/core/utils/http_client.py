import json
import logging
import random
import string
from asyncio import AbstractEventLoop
from enum import Enum
from json.decoder import JSONDecodeError
from pathlib import Path
from ssl import SSLContext
from typing import Any, AsyncIterable, AsyncIterator, Awaitable, Callable, Dict, Iterable, List, Optional, Tuple, Union

import aiohttp
from aiohttp import ClientConnectionError, ClientResponse, ClientResponseError, RequestInfo
from aiohttp.typedefs import LooseHeaders
from requests import HTTPError

from crowd_sdk.core.utils.common import urljoin_with_path
from crowd_sdk.core.utils.http import DEFAULT_RATE_LIMIT, RETRY_HTTP_CODES, HttpWrapper, RateLimiter, retry_request

logger = logging.getLogger(__name__)
TRACE_KEY = 'X-Request-Id'
TRACE_ID_ALPHABET = string.ascii_letters.lower() + string.digits.lower()


class AuthType(Enum):
    OAUTH = 'OAuth'
    BEARER = 'Bearer'
    APIKEY = 'ApiKey'


class HttpMethod(Enum):
    GET = 'GET'
    POST = 'POST'
    PUT = 'PUT'
    DELETE = 'DELETE'
    PATCH = 'PATCH'


class ResponseType(Enum):
    TEXT_RESPONSE = 'TEXT'
    JSON_RESPONSE = 'JSON'
    RAW_RESPONSE = 'RAW'
    FILE_RESPONSE = 'FILE'


class APIResponseError(ClientResponseError):
    def __init__(
        self,
        request_info: Optional[RequestInfo],
        history: Tuple[ClientResponse, ...],
        json_error: Optional[dict] = None,
        *,
        code: Optional[int] = None,
        status: Optional[int] = None,
        message: str = "",
        headers: Optional[LooseHeaders] = None,
    ) -> None:
        super().__init__(request_info, history, code=code, status=status, message=message, headers=headers)
        self.json_error = json_error
        self.args: tuple = self.args + (self.json_error,)

    def __str__(self) -> str:
        res = super().__str__()
        json_error = json.dumps(self.json_error, ensure_ascii=False)
        return f'{res}, json_error={json_error}'

    def __repr__(self) -> str:
        res = super().__repr__()
        json_error = json.dumps(self.json_error, ensure_ascii=False)
        return f'{res[:-1]}, json_error={json_error})'

    @classmethod
    def from_client_response_error(cls, exc: ClientResponseError, json_error: Optional[dict]) -> 'APIResponseError':
        return cls(
            exc.request_info, exc.history, json_error, status=exc.status, message=exc.message, headers=exc.headers
        )

    @classmethod
    def from_http_error(cls, exc: HTTPError, json_error: Optional[dict]) -> 'APIResponseError':
        return cls(
            None,
            (),
            json_error,
            status=exc.response.status_code,
            message=str(exc),
            headers=exc.request and exc.request.headers,
        )


def add_trace_header(headers: Dict[str, str]) -> None:
    if TRACE_KEY not in headers:
        headers[TRACE_KEY] = ''.join(random.choice(TRACE_ID_ALPHABET) for _ in range(32))


class JsonAPI:
    def __init__(
        self,
        url: str,
        token: Optional[str] = None,
        http: Optional[HttpWrapper] = None,
        auth_type: Union[AuthType, str] = AuthType.OAUTH,
        rate_limit: int = DEFAULT_RATE_LIMIT,
    ) -> None:
        self.http = http or HttpWrapper()
        self.url = url

        self.auth_type: str = auth_type.value if isinstance(auth_type, AuthType) else auth_type
        self.token = token
        assert self.auth_type, 'auth_type doesnt\'t set'
        self.limiter = RateLimiter(rps=rate_limit)

    @staticmethod
    def format_response(response_text: Optional[str]) -> Optional[str]:
        if response_text:
            try:
                response_text = json.dumps(json.loads(response_text), ensure_ascii=False, indent=2)
                return f'\nResponse: \n{response_text}'
            except json.JSONDecodeError:
                return f'\nResponse: {response_text}'

        return None

    def make_url(self, url: str) -> str:
        target_url = urljoin_with_path(self.url, url) if self.url else url
        return target_url

    async def _request(  # pylint: disable=R0912, R0915
        self,
        method: HttpMethod,
        url: str,
        ssl_context: Optional[SSLContext] = None,
        headers: Optional[Dict[str, str]] = None,
        form: Optional[List[Dict[str, Any]]] = None,
        response_type: ResponseType = ResponseType.JSON_RESPONSE,
        ignore_statuses: Union[None, int, Tuple[int]] = None,
        raise_for_status: bool = True,
        **kwargs: Any,
    ) -> Any:
        """
        Send request and return json/text/raw response.

        Args:
            method (HttpMethod): http method to do request.
            url (str): target url.
            response_type (ResponseType, optional): json/text/raw type response. Defaults to ResponseType.JSON_RESPONSE.

        Raises:
            exc: automatically raise exception if response status is not in [200 .. 300) .

        Returns:
            Any: json/text/raw response.
        """

        kwargs['headers'] = headers or {}
        add_trace_header(kwargs['headers'])
        if not ssl_context:
            kwargs.update(ssl=False)
        else:
            kwargs.update(ssl=ssl_context)

        if form is not None:
            form_data = aiohttp.FormData(quote_fields=False)
            for field in form:
                form_data.add_field(**field)
            kwargs['data'] = form_data

        response = None
        response_text = None

        target_url = self.make_url(url)

        try:
            async with self.limiter:
                response = await self.http.request(method=method.value, url=target_url, **kwargs)

            if response_type not in (ResponseType.RAW_RESPONSE, ResponseType.FILE_RESPONSE):
                response_text = await response.text()

            if raise_for_status:
                response.raise_for_status()

            if response_type is ResponseType.RAW_RESPONSE:
                return await response.read()
            elif response_type is ResponseType.FILE_RESPONSE:
                return (response.content_type, await response.read())
            elif response_type is ResponseType.TEXT_RESPONSE:
                return response_text
            else:
                return await response.json(content_type=None)

        except UnicodeDecodeError as exc:
            if response is not None:
                log_file = Path("~/UnicodeDecodeError.dump").expanduser()
                logger.exception(
                    'Processing the response caused an exception UnicodeDecodeError.'
                    'The response will be written to a file: %s',
                    log_file,
                    exc_info=exc,
                )
                with open(log_file, "wb") as f:
                    data_dump = await response.read()
                    f.write(data_dump)
            raise

        except JSONDecodeError as exc:
            if response is None or (response is not None and not 200 <= response.status < 300):
                logger.error('Request to %s %s "%s" failed with json decode error', method.value, url, response)
                logger.exception(exc)
                raise

            logger.warning('Request to %s %s "%s" failed with json decode error', method.value, url, response)
            return None

        except ClientResponseError as exc:
            if ignore_statuses:
                if isinstance(ignore_statuses, Iterable) and exc.status in ignore_statuses:  # type: ignore
                    return None
                if isinstance(ignore_statuses, int) and exc.status == ignore_statuses:
                    return None

            json_error = None
            if response is not None:
                try:
                    response_text = await response.text()
                    json_error = json.loads(response_text)

                except (json.JSONDecodeError, ClientConnectionError):
                    pass

            error_text = self.format_response(response_text)
            logger.error('Request to %s %s failed with status code %s %s', method.value, url, exc.status, error_text)
            if exc.status == 403:
                logger.error('Headers %s', str(kwargs['headers']))
            raise APIResponseError.from_client_response_error(exc, json_error) from exc

        except Exception:
            error_text = self.format_response(response_text)
            logger.exception('Request to %s %s failed error=%s', method.value, url, error_text)
            raise

    async def request(
        self, method: HttpMethod, url: str, headers: Optional[Dict[str, str]] = None, **kwargs: Any
    ) -> Any:
        """
        Send request and return json/text/raw response.

        Args:
            method (HttpMethod): http method to do request.
            url (str): target url.

        Returns:
            Any: json/text/raw response.
        """
        headers = headers or {}
        if 'Authorization' not in headers:
            assert self.token, 'token doesnt\'t set'
            headers['Authorization'] = f'{self.auth_type} {self.token}'
        return await self._request(method, url, headers=headers, **kwargs)

    async def raw_request(
        self, method: HttpMethod, url: str, headers: Optional[Dict[str, str]] = None, **kwargs: Any
    ) -> Any:
        """
        Send request and return raw response.

        Args:
            method: HttpMethod enum
            url (str): target url.
            **kwargs: any qiorequests params

        Returns:
            raw data from the response
        """
        headers = headers or {}
        if 'Authorization' not in headers:
            assert self.token, 'token doesnt\'t set'
            headers['Authorization'] = f'{self.auth_type} {self.token}'
        kwargs.update(headers=headers)
        kwargs.update(ssl=False)
        target_url = self.make_url(url)
        try:
            return await self.http.request(method=method.value, url=target_url, **kwargs)
        except Exception as exc:
            logger.exception('Request to %s failed: [method %s, kwargs %s]', url, method, kwargs)
            raise exc

    @retry_request(statuses=RETRY_HTTP_CODES)
    async def post(self, url: str, **kwargs: Any) -> Any:
        return await self.request(method=HttpMethod.POST, url=url, **kwargs)

    @retry_request(statuses=RETRY_HTTP_CODES)
    async def get(self, url: str, **kwargs: Any) -> Any:
        return await self.request(method=HttpMethod.GET, url=url, **kwargs)

    @retry_request(statuses=RETRY_HTTP_CODES)
    async def put(self, url: str, **kwargs: Any) -> Any:
        return await self.request(method=HttpMethod.PUT, url=url, **kwargs)

    @retry_request(statuses=RETRY_HTTP_CODES)
    async def patch(self, url: str, **kwargs: Any) -> Any:
        return await self.request(method=HttpMethod.PATCH, url=url, **kwargs)

    @retry_request(statuses=RETRY_HTTP_CODES)
    async def delete(self, url: str, **kwargs: Any) -> Any:
        return await self.request(method=HttpMethod.DELETE, url=url, **kwargs)

    async def gather(self, url: str, **kwargs: Any) -> AsyncIterable:
        has_more = True
        kwargs.update(sort=(kwargs.get('sort') or 'id'))

        while has_more:
            pools = await self.get(url, params=kwargs)
            has_more = pools.get('has_more', False)
            for item in pools.get('items', []):
                yield item

            if has_more:
                kwargs.update(id_gt=pools['items'][-1]['id'])

    async def close(self) -> None:
        await self.http.close()


def run_anyway(async_object: Awaitable, loop: AbstractEventLoop) -> Any:
    if loop is not None:
        return loop.run_until_complete(async_object)

    raise RuntimeError('there is no loop to run')


def make_sync(func: Callable) -> Callable:
    def run_sync(self: Any, *args: Any, **kwargs: Any) -> Any:
        async_func = getattr(self.async_client, func.__name__)
        async_object = async_func(*args, **kwargs)
        return run_anyway(async_object, self.loop)

    return run_sync


def make_sync_generator(func: Callable) -> Callable:
    def run_sync_generator(self: Any, *args: Any, **kwargs: Any) -> Iterable:
        async_func: Callable = getattr(self.async_client, func.__name__)
        async_object: AsyncIterator = async_func(*args, **kwargs)

        async def get_next() -> Tuple[bool, Optional[Any]]:
            try:
                obj = await async_object.__anext__()
                return False, obj
            except StopAsyncIteration:
                return True, None

        done: bool
        sync_obj: Optional[Any]
        while True:
            done, sync_obj = run_anyway(get_next(), self.loop)
            if done:
                break
            yield sync_obj

    return run_sync_generator

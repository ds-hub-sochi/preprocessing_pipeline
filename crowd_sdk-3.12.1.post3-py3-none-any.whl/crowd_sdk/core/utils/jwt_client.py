import logging
import ssl
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Optional, Union

import jwt
from aiohttp.web_exceptions import HTTPUnauthorized

from crowd_sdk.core.utils.common import AuthConfig, urljoin_with_path
from crowd_sdk.core.utils.http import DEFAULT_RATE_LIMIT, HttpWrapper, SyncHttpWrapper
from crowd_sdk.core.utils.http_client import ResponseType  # pylint: disable=unused-import
from crowd_sdk.core.utils.http_client import AuthType, HttpMethod, JsonAPI
from crowd_sdk.core.utils.http_sync_client import JsonSyncAPI

logger = logging.getLogger(__name__)

GRANT_TYPE_CLIENT_CREDENTIALS = "client_credentials"
GRANT_TYPE_PASSWORD = "password"
GRANT_TYPE_REFRESH_TOKEN = "refresh_token"
REFRESH_TOKEN_EXPIRATION_RATIO = 4 / 5
AUTH_TIMEOUT = 10
DEFAULT_EXPIRES_IN = 5 * 60


class Token:
    def __init__(self, config: AuthConfig, http: SyncHttpWrapper, auth_headers: Optional[Dict[str, str]] = None):
        self.auth_headers: Dict[str, str] = auth_headers or {'Content-Type': 'application/x-www-form-urlencoded'}
        self.config = config
        self.http = http
        assert config.auth_url and config.realm
        self.auth_url = urljoin_with_path(config.auth_url, f'/auth/realms/{config.realm}/protocol/openid-connect/token')

        self.access_token = None
        self.expires_in = None
        self.refresh_token: Optional[str] = None
        self.refresh_expires_in: Optional[int] = None
        self.expires_at: Optional[datetime] = None
        self.refresh_expires_at: Optional[datetime] = None
        if config.token:
            try:
                token_object = jwt.decode(config.token)
                expires_in = token_object.exp - datetime.now().timestamp()
            except ImportError:
                expires_in = DEFAULT_EXPIRES_IN

            self.access_token = config.token
            self.expires_in = expires_in
        else:
            self.login()
        self.user_id = jwt.decode(self.access_token, options={'verify_signature': False}).get('sub')

    def update_from_data(
        self,
        access_token: str = None,
        expires_in: int = None,
        refresh_token: Optional[str] = None,
        refresh_expires_in: Optional[int] = None,
        expires_at: Optional[datetime] = None,
        refresh_expires_at: Optional[datetime] = None,
        **_kwargs: Any,
    ) -> None:
        self.access_token = access_token
        self.expires_in = expires_in
        self.refresh_token = refresh_token
        self.refresh_expires_in = refresh_expires_in
        self.expires_at = expires_at
        self.refresh_expires_at = refresh_expires_at

        if self.expires_in:
            self.expires_at = datetime.now() + timedelta(seconds=self.expires_in * REFRESH_TOKEN_EXPIRATION_RATIO)
        if self.refresh_expires_in:
            assert self.expires_in, 'if refresh token exists, there must be regular token expiration info'
            assert (
                self.expires_in < self.refresh_expires_in
            ), 'refresh token must have longer expiration than the regular token'
            self.refresh_expires_at = datetime.now() + timedelta(
                seconds=self.refresh_expires_in * REFRESH_TOKEN_EXPIRATION_RATIO
            )

    def get_access_token(self) -> 'str':
        if not self.expires_at or datetime.now() >= self.expires_at:
            self.__refresh()
        assert self.access_token, 'No access token got during login/refresh'
        return self.access_token

    def __refresh(self) -> None:
        if self.refresh_expires_at and datetime.now() < self.refresh_expires_at:
            logger.debug('Refresh token from refresh token')
            try:
                auth_data = self.__auth_request(
                    grant_type=GRANT_TYPE_REFRESH_TOKEN,
                    refresh_token=self.refresh_token,
                    client_cert_path=self.config.client_cert_path,
                )
                self.update_from_data(**auth_data)
            except HTTPUnauthorized:
                logger.error('Failed to refresh token')

        self.login()

    def login(self) -> None:
        logger.debug('Get token from credentials')
        if self.config.client_secret or self.config.client_cert_path:
            auth_data = self.__auth_request(
                grant_type=GRANT_TYPE_CLIENT_CREDENTIALS,
                client_secret=self.config.client_secret,
                client_cert_path=self.config.client_cert_path,
            )
        else:
            auth_data = self.__auth_request(
                grant_type=GRANT_TYPE_PASSWORD,
                username=self.config.user,
                password=self.config.password,
                client_cert_path=self.config.client_cert_path,
            )

        self.update_from_data(**auth_data)

    def __auth_request(
        self,
        grant_type: str,
        client_cert_path: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        refresh_token: Optional[str] = None,
        client_secret: Optional[str] = None,
    ) -> Dict[str, Any]:
        assert self.config.client_id
        params = {
            'client_id': self.config.client_id,
            'username': username,
            'password': password,
            'refresh_token': refresh_token,
            'client_secret': client_secret,
            'grant_type': grant_type,
        }
        response = self.http.request(
            method='POST',
            url=self.auth_url,
            data=params,
            verify=False,
            cert=client_cert_path,
            headers=self.auth_headers,
        )
        data = response.json()
        if 'error' in data:
            raise HTTPUnauthorized(reason=data)
        response.raise_for_status()
        return data


class JWTAPI(JsonAPI):
    def __init__(
        self,
        config: Union[str, Path, dict, AuthConfig],
        http: Optional[HttpWrapper] = None,
        auth_http: Optional[SyncHttpWrapper] = None,
        rate_limit: int = DEFAULT_RATE_LIMIT,
    ) -> None:
        self.config: AuthConfig = AuthConfig.from_any(config)
        self.auth_http: SyncHttpWrapper = auth_http or SyncHttpWrapper()

        assert self.config.auth_url, 'Auth url not specified'
        assert self.config.url, 'Url not specified'

        self.ssl_context: Optional[ssl.SSLContext] = None
        if self.config.client_cert_path:
            self.ssl_context = ssl.SSLContext()
            self.ssl_context.load_cert_chain(self.config.client_cert_path, self.config.client_cert_path)

        self.token_object = Token(self.config, self.auth_http)

        super().__init__(
            http=http,
            url=self.config.url,
            auth_type=AuthType.BEARER,
            rate_limit=rate_limit,
        )

    def get_base_url(self) -> str:
        assert self.config.auth_url, 'Base url is not set'
        return self.config.auth_url.rstrip('/')

    async def request(
        self, method: HttpMethod, url: str, headers: Optional[Dict[str, str]] = None, **kwargs: Any
    ) -> Any:
        headers = headers or {}
        if 'Authorization' not in headers:
            headers['Authorization'] = f'{self.auth_type} {self.token_object.get_access_token()}'
        return await self._request(method, url, ssl_context=self.ssl_context, headers=headers, **kwargs)


class JWTSyncAPI(JsonSyncAPI):
    def __init__(
        self,
        config: Union[str, Path, dict, AuthConfig],
        http: Optional[SyncHttpWrapper] = None,
        auth_http: Optional[SyncHttpWrapper] = None,
    ) -> None:
        self.config: AuthConfig = AuthConfig.from_any(config)
        self.auth_http: SyncHttpWrapper = auth_http or SyncHttpWrapper()

        assert self.config.auth_url, 'Auth url not specified'
        assert self.config.url, 'Url not specified'

        self.ca_cert: Union[bool, str] = self.config.client_cert_path or False
        self.cl_cert: Optional[str] = self.config.client_cert_path

        self.token_object = Token(self.config, self.auth_http)

        super().__init__(
            http=http,
            url=self.config.url,
            auth_type=AuthType.BEARER,
        )

    def get_base_url(self) -> str:
        assert self.config.auth_url, 'Base url is not set'
        return self.config.auth_url

    def request(self, method: HttpMethod, url: str, headers: Optional[Dict[str, str]] = None, **kwargs: Any) -> Any:
        headers = headers or {}
        if 'Authorization' not in headers:
            headers['Authorization'] = f'{self.auth_type} {self.token_object.get_access_token()}'
        return self._request(method, url, verify=self.ca_cert, cert=self.cl_cert, headers=headers, **kwargs)

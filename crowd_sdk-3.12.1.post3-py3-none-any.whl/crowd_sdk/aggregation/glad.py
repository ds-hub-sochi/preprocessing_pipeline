from dataclasses import dataclass
from typing import Any, List

import pandas as pd
from crowdkit.aggregation import GLAD as CrowdKitGLAD  # pylint: disable=import-error


@dataclass
class GladEntryDataclass:
    task: str
    worker: str
    label: Any


@dataclass
class GladResultDataclass:
    task: str
    pred: Any


def get_glad_pred(data: List[GladEntryDataclass], threshold: float) -> List[GladResultDataclass]:
    labels = {row.label for row in data}
    assert 'task' not in labels, 'Labels cant contains the name "task"!'
    aggregated_labels: pd.DataFrame = CrowdKitGLAD().fit_predict_proba(pd.DataFrame(data))
    aggregated_labels_list = aggregated_labels.reset_index().to_dict('records')
    aggregated_data = []
    for row in aggregated_labels_list:
        tmp_dict = {val: key for key, val in row.items() if key in labels}
        max_item_proba = max(tmp_dict)
        if max_item_proba >= threshold:
            key_with_max_value = tmp_dict[max_item_proba]
            aggregated_row = GladResultDataclass(task=row['task'], pred=key_with_max_value)
            aggregated_data.append(aggregated_row)
    return aggregated_data

from collections import defaultdict
from dataclasses import dataclass
from enum import Enum
from typing import Any, List, Optional, Union

import numpy as np

DEFAULT_IF_TIE_IN_MAJORITY = 'unknown'


class MajoritySpecialMode(Enum):
    AT_LEAST_ONE = 'at_least_one'
    AT_LEAST_ONE_NO_DROP = 'at_least_one_no_drop'
    TIEBREAKER = 'tiebreaker'


@dataclass
class MajorityEntryDataclass:
    task: str
    worker: str
    label: Any


@dataclass
class MajorityResultDataclass:
    task: str
    pred: Union[str, bool, int]


def aggregate_field(  # pylint: disable=too-many-branches
    data: List[MajorityEntryDataclass], threshold: float, special_mode: Optional[str] = None
) -> List[MajorityResultDataclass]:
    """
    A function to aggregate data using majority algorithm.

    Args:
        data (List[MajorityEntryDataclass]): data for aggregation.
        threshold (float): threshold for majority algorithm.
        special_mode (Optional[str], optional): additional mode for majority. Defaults to None.

            special_mode == 'at_least_one' means that we label field as True if
            at least one of the labels is True or 1. Otherwise we do not label.

            special_mode == 'at_least_one_no_drop' means that we label field as True if
            at least one of the labels is True or 1. Otherwise we label as False.

            special_mode == 'tiebreaker' means that if there are two or more
            most popular labels, then we return DEFAULT_IF_TIE_IN_MAJORITY instead one
            of the presented labels.

    Raises:
        ValueError: if get strange special_mode

    Returns:
        List[MajorityResultDataclass]: aggregated data
    """
    field_dict: defaultdict = defaultdict(lambda: defaultdict(int))
    for record in data:
        field_dict[record.task][record.label] += 1

    aggregated_data = []
    if special_mode is None:
        for task in field_dict:
            agg_field_dict = field_dict[task]
            if (
                max(agg_field_dict.values()) / sum(agg_field_dict.values()) >= threshold
                and sum(agg_field_dict.values()) > 1
            ):
                agg_row = MajorityResultDataclass(task=task, pred=max(agg_field_dict, key=agg_field_dict.get))
                aggregated_data.append(agg_row)
    elif special_mode == MajoritySpecialMode.AT_LEAST_ONE.value:
        for task in field_dict:
            agg_field_dict = field_dict[task]
            if True in agg_field_dict or 1 in agg_field_dict:
                agg_row = MajorityResultDataclass(task=task, pred=True)
                aggregated_data.append(agg_row)
    elif special_mode == MajoritySpecialMode.AT_LEAST_ONE_NO_DROP.value:
        for task in field_dict:
            agg_field_dict = field_dict[task]
            if True in agg_field_dict or 1 in agg_field_dict:
                agg_row = MajorityResultDataclass(task=task, pred=True)
                aggregated_data.append(agg_row)
            else:
                agg_row = MajorityResultDataclass(task=task, pred=False)
                aggregated_data.append(agg_row)
    elif special_mode == MajoritySpecialMode.TIEBREAKER.value:
        for task in field_dict:
            agg_field_dict = field_dict[task]
            max_labels_value = max(agg_field_dict.values())
            if max_labels_value / sum(agg_field_dict.values()) >= threshold and sum(agg_field_dict.values()) > 1:
                if np.sum([value == max_labels_value for value in agg_field_dict.values()]) > 1:
                    agg_row = MajorityResultDataclass(task=task, pred=DEFAULT_IF_TIE_IN_MAJORITY)
                else:
                    agg_row = MajorityResultDataclass(task=task, pred=max(agg_field_dict, key=agg_field_dict.get))
                aggregated_data.append(agg_row)
    else:
        raise ValueError(
            f"Can't use '{special_mode}' as special mode! Accepted modes: {[_.value for _ in MajoritySpecialMode]}"
        )
    return aggregated_data

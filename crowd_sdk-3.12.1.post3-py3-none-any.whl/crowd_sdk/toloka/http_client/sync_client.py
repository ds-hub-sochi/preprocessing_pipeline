# pylint: disable=C0302,W0613
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, AsyncIterable, Dict, Iterable, List, Optional, Tuple, Union

from crowd_sdk import DEFAULT_CONFIG
from crowd_sdk.core.utils.common import get_event_loop
from crowd_sdk.core.utils.http_client import HttpWrapper, make_sync, make_sync_generator, run_anyway
from crowd_sdk.toloka.http_client.client import PoolStatus, TolokaClient, TolokaConfig

logger = logging.getLogger(__name__)

DEFAULT_THREADS = 5


class TolokaSyncClient:  # pylint: disable=R0904
    UPLOAD_LIMIT = TolokaClient.UPLOAD_LIMIT
    DOWNLOAD_LIMIT = TolokaClient.DOWNLOAD_LIMIT
    STATUS = PoolStatus

    def __init__(
        self,
        http: Optional[HttpWrapper] = None,
        config: Union[str, Path, dict, TolokaConfig] = DEFAULT_CONFIG,
        is_sandbox: bool = False,
    ) -> None:
        http = http or HttpWrapper()
        self.async_client = None
        self.loop = None
        self.async_client = TolokaClient(http=http, config=config, is_sandbox=is_sandbox)
        self.loop = get_event_loop()

    def __del__(self) -> None:
        if self.async_client is not None and self.loop is not None and not self.loop.is_closed():
            run_anyway(self.async_client.close(), self.loop)

    @staticmethod
    def get_unreached_urls(urls: List[str]) -> Iterable:
        return TolokaClient.get_unreached_urls(urls)

    # -----------------------------------------------------------------------------
    #                                  PROJECT
    # -----------------------------------------------------------------------------

    @make_sync_generator
    def get_projects(  # pylint: disable=R0913
        self,
        status: Optional[str] = None,
        sort: Optional[str] = None,
        owner: Optional[str] = None,
        limit: Optional[int] = None,
        id_gt: Optional[int] = None,
        id_gte: Optional[int] = None,
        id_lt: Optional[int] = None,
        id_lte: Optional[int] = None,
        created_gt: Optional[str] = None,
        created_gte: Optional[str] = None,
        created_lt: Optional[str] = None,
        created_lte: Optional[str] = None,
    ) -> Iterable:
        pass

    @make_sync
    def get_project(self, project_id: int) -> Any:
        pass

    @make_sync
    def set_project(self, project_id: int, project_config: Any) -> Any:
        pass

    @make_sync
    def create_project(self, project_id: int, project_config: Any) -> Any:
        pass

    @make_sync
    def archive_project(self, project_id: int) -> Any:
        pass

    # -----------------------------------------------------------------------------
    #                                  POOL
    # -----------------------------------------------------------------------------

    @make_sync_generator
    def get_pools(  # pylint: disable=R0913
        self,
        project_id: Optional[Union[str, int]] = None,
        status: Optional[str] = None,
        sort: Optional[str] = None,
        limit: Optional[int] = None,
        id_gt: Optional[int] = None,
        id_gte: Optional[int] = None,
        id_lt: Optional[int] = None,
        id_lte: Optional[int] = None,
        created_gt: Optional[str] = None,
        created_gte: Optional[str] = None,
        created_lt: Optional[str] = None,
        created_lte: Optional[str] = None,
        last_started_gt: Optional[str] = None,
        last_started_gte: Optional[str] = None,
        last_started_lt: Optional[str] = None,
        last_started_lte: Optional[str] = None,
    ) -> Iterable:
        pass

    @make_sync_generator
    def get_pools_by_statuses(
        self,
        project_id: Union[int, str],
        statuses: Optional[list] = None,
        created_gte: Optional[datetime] = None,
        created_lte: Optional[datetime] = None,
        last_started_gte: Optional[datetime] = None,
        last_started_lte: Optional[datetime] = None,
    ) -> Iterable:
        pass

    @make_sync
    def get_pool(self, pool_id: int) -> Any:
        pass

    @make_sync
    def set_pool(self, pool_id: int, pool_params: Any) -> Any:
        pass

    @make_sync
    def open_pool(self, pool_id: int) -> Any:
        pass

    @make_sync
    def close_pool(self, pool_id: int) -> Any:
        pass

    @make_sync
    def archive_pool(self, pool_id: int) -> Any:
        pass

    @make_sync
    def clone_pool_and_fix(self, pool_id: int) -> int:
        pass

    @make_sync
    def wait_pool(self, pool_id: int) -> None:
        pass

    async def async_wait_pool(self, pool_id: int) -> None:
        assert self.async_client is not None, 'Run async_wait_pool with None client'
        await self.async_client.wait_pool(pool_id)

    @make_sync_generator
    def wait_for_results(self, pool_id: int) -> Iterable:
        pass

    @make_sync
    def create_pool_from_base(
        self, pool_data: Any, pool_name: str, base_pool_id: int, with_honeypots: bool = True
    ) -> Tuple[int, int]:
        pass

    @make_sync
    def create_pool_from_params(
        self,
        pool_data: Any,
        pool_name: str,
        pool_params: dict,
    ) -> Tuple[int, int]:
        pass

    @make_sync
    def set_pool_priority(self, pool_id: int, priority: int) -> None:
        pass

    # -----------------------------------------------------------------------------
    #                                  OP
    # -----------------------------------------------------------------------------

    @make_sync
    def get_operation(self, op_id: str) -> Any:
        pass

    @make_sync
    def wait_operation(self, operation: Any, key: str) -> Any:
        pass

    # -----------------------------------------------------------------------------
    #                                  TASKS
    # -----------------------------------------------------------------------------

    @staticmethod
    def task_suite_to_rows(task_suite: dict) -> Iterable:
        return TolokaClient.task_suite_to_rows(task_suite)

    @make_sync_generator
    def get_tasks(  # pylint: disable=R0913
        self,
        pool_id: Optional[Union[str, int]] = None,
        sort: Optional[str] = None,
        overlap: Optional[int] = None,
        limit: Optional[int] = None,
        id_gt: Optional[int] = None,
        id_gte: Optional[int] = None,
        id_lt: Optional[int] = None,
        id_lte: Optional[int] = None,
        created_gt: Optional[str] = None,
        created_gte: Optional[str] = None,
        created_lt: Optional[str] = None,
        created_lte: Optional[str] = None,
        overlap_gt: Optional[int] = None,
        overlap_gte: Optional[int] = None,
        overlap_lt: Optional[int] = None,
        overlap_lte: Optional[int] = None,
    ) -> Iterable:
        pass

    @make_sync_generator
    def get_control_tasks(self, pool_id: int) -> Iterable:
        pass

    @make_sync
    def add_exam_tasks(self, pool_id: int, tasks_list: List[Dict[str, str]], overlap: int = 3) -> int:
        pass

    @make_sync
    def add_tasks(self, pool_id: int, tasks_list: List[Dict[str, str]], overlap: int = 3) -> int:
        pass

    @staticmethod
    def row_to_task(row: Dict[str, Any]) -> Dict[str, Any]:
        return TolokaClient.row_to_task(row)

    # -----------------------------------------------------------------------------
    #                                  RESULTS
    # -----------------------------------------------------------------------------

    @make_sync_generator
    def get_assignments(  # pylint: disable=R0913,R0914
        self,
        pool_id: Optional[Union[str, int]] = None,
        status: Optional[str] = None,
        task_id: Optional[str] = None,
        task_suite_id: Optional[str] = None,
        user_id: Optional[str] = None,
        sort: Optional[str] = None,
        limit: Optional[int] = None,
        id_gt: Optional[int] = None,
        id_gte: Optional[int] = None,
        id_lt: Optional[int] = None,
        id_lte: Optional[int] = None,
        created_gt: Optional[str] = None,
        created_gte: Optional[str] = None,
        created_lt: Optional[str] = None,
        created_lte: Optional[str] = None,
        submitted_gt: Optional[int] = None,
        submitted_gte: Optional[int] = None,
        submitted_lt: Optional[int] = None,
        submitted_lte: Optional[int] = None,
        accepted_gt: Optional[int] = None,
        accepted_gte: Optional[int] = None,
        accepted_lt: Optional[int] = None,
        accepted_lte: Optional[int] = None,
        rejected_gt: Optional[int] = None,
        rejected_gte: Optional[int] = None,
        rejected_lt: Optional[int] = None,
        rejected_lte: Optional[int] = None,
        skipped_gt: Optional[int] = None,
        skipped_gte: Optional[int] = None,
        skipped_lt: Optional[int] = None,
        skipped_lte: Optional[int] = None,
        expired_gt: Optional[int] = None,
        expired_gte: Optional[int] = None,
        expired_lt: Optional[int] = None,
        expired_lte: Optional[int] = None,
    ) -> Iterable:
        pass

    @make_sync_generator
    def get_assignments_table(self, pool_id: int) -> Iterable:
        pass

    @make_sync
    def accept_assignment(self, assignment_id: str) -> None:
        pass

    @make_sync_generator
    def accept_assignments(self, assignments: List[str]) -> Iterable:
        pass

    @make_sync_generator
    def get_pool_results_info(self, pool_id: int, accepted_only: bool = True) -> Iterable:
        pass

    @make_sync_generator
    def get_pool_results(self, pool_id: int) -> Iterable:
        pass

    @make_sync
    def get_pool_expenses(self, pool_id: int, date_from: Optional[str] = None) -> float:
        pass

    # -----------------------------------------------------------------------------
    #                                  ATTACHMENTS
    # -----------------------------------------------------------------------------

    @make_sync
    def download_attachment(self, fpath: Union[str, Path], attachment_id: str) -> None:
        pass

    @make_sync_generator
    def download_attachments(self, pool_id: int, out_dir: Union[str, Path], skip_existing: bool = True) -> Iterable:
        pass

    # -----------------------------------------------------------------------------
    #                                  ATTACHMENTS
    # -----------------------------------------------------------------------------

    @make_sync
    def get_skill_exact_value(self, user_id: int, skill_id: int) -> Optional[float]:
        pass

    @make_sync
    def get_skill(self, worker_id: int, skill_id: int) -> Optional[float]:
        pass

    @make_sync_generator
    def set_skill(self, users: List[Dict[str, Tuple[str, float]]], skill_id: int) -> Iterable:
        pass

    @make_sync_generator
    def get_messages(  # pylint: disable=R0913
        self,
        folder: Optional[str] = None,
        folder_ne: Optional[str] = None,
        sort: str = None,
        limit: Optional[int] = None,
        id_gt: Optional[int] = None,
        id_gte: Optional[int] = None,
        id_lt: Optional[int] = None,
        id_lte: Optional[int] = None,
        created_gt: Optional[str] = None,
        created_gte: Optional[str] = None,
        created_lt: Optional[str] = None,
        created_lte: Optional[str] = None,
    ) -> Iterable:
        pass

    @make_sync
    def post(self, url: str, **kwargs: Any) -> Any:
        pass

    @make_sync
    def get(self, url: str, **kwargs: Any) -> Any:
        pass

    @make_sync
    def put(self, url: str, **kwargs: Any) -> Any:
        pass

    @make_sync
    def patch(self, url: str, **kwargs: Any) -> Any:
        pass

    @make_sync
    def delete(self, url: str, **kwargs: Any) -> Any:
        pass

    @make_sync_generator
    def gather(self, url: str, **kwargs: Any) -> Iterable:
        pass

    @make_sync
    def close(self) -> None:
        pass

    @make_sync_generator
    def get_blocked_users(  # pylint: disable=R0913
        self,
        scope: Optional[str] = None,
        project_id: Optional[Union[str, int]] = None,
        pool_id: Optional[Union[str, int]] = None,
        sort: Optional[str] = None,
        limit: Optional[int] = None,
        id_gt: Optional[int] = None,
        id_gte: Optional[int] = None,
        id_lt: Optional[int] = None,
        id_lte: Optional[int] = None,
        created_gt: Optional[str] = None,
        created_gte: Optional[str] = None,
        created_lt: Optional[str] = None,
        created_lte: Optional[str] = None,
    ) -> AsyncIterable:
        pass

    @make_sync
    def send_message(self, user_id: Union[str, int], text: str, topic: str) -> Any:
        pass

    @make_sync
    def balance(self) -> Any:
        pass

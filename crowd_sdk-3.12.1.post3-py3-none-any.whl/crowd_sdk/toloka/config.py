from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Union

import yaml
from dacite import from_dict

from crowd_sdk.core.config import DEFAULT_CONFIG, CrowdConfig

SECTION_NAME = 'toloka'


@dataclass
class TolokaInstanceConfig:
    url: str
    token: str
    is_sandbox: bool = False


@CrowdConfig.crowd_config_section(SECTION_NAME)
@dataclass
class TolokaConfig:
    sandbox: Optional[TolokaInstanceConfig] = None
    prod: Optional[TolokaInstanceConfig] = None
    url: Optional[str] = None
    token: Optional[str] = None
    is_sandbox: bool = False
    auth_type: str = 'OAuth'

    def __post_init__(self) -> None:
        if self.sandbox and self.is_sandbox:
            self.url = self.sandbox.url
            self.token = self.sandbox.token
        if self.prod and not self.is_sandbox:
            self.url = self.prod.url
            self.token = self.prod.token

        assert self.url
        assert self.token

    @classmethod
    def from_dict(cls, config: dict, is_sandbox: bool = False) -> 'TolokaConfig':
        result = from_dict(data_class=cls, data=config)
        result.is_sandbox = is_sandbox
        return result

    @staticmethod
    def from_global_config(path: Union[str, Path] = DEFAULT_CONFIG, is_sandbox: bool = False) -> 'TolokaConfig':
        path = Path(path).expanduser()
        with open(path) as config_file:
            config = yaml.load(config_file, Loader=yaml.Loader)
            server_label = 'sandbox' if is_sandbox else 'prod'
            assert 'toloka' in config, 'toloka: must be in config'
            assert server_label in config['toloka'], f'{server_label}: must be in config["toloka"]'
            assert 'url' in config['toloka'][server_label], 'url: must be in config["toloka"][server_label]'
            assert 'token' in config['toloka'][server_label], 'token: must be in config["toloka"][server_label]'
            # crutch for mypy, because it has unclear glitch with resolution of class TolokaConfig properties here
            return TolokaConfig(  # type: ignore
                url=config['toloka'][server_label]['url'],
                token=config['toloka'][server_label]['token'],
                auth_type=config['toloka'][server_label].get('auth_type') or 'OAuth',
                is_sandbox=is_sandbox,
            )

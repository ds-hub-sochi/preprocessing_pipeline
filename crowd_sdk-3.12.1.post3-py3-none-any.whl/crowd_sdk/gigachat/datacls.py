import logging
from dataclasses import dataclass
from enum import Enum
from typing import List, Optional

from crowd_sdk.core.utils.datacls import AsDictMixin, FromDictMixin

logger = logging.getLogger(__file__)


class RoleType(Enum):
    ASSISTANT = "assistant"
    SYSTEM = "system"
    USER = "user"


@dataclass
class BaseDevicesResponse(AsDictMixin, FromDictMixin):
    created: int
    model: str
    object: str


@dataclass
class Message(AsDictMixin, FromDictMixin):
    role: str
    content: str


@dataclass
class DevicesChatChoice(AsDictMixin, FromDictMixin):
    message: Message
    finish_reason: str
    index: int
    created: Optional[str]


@dataclass
class DevicesChatResponse(BaseDevicesResponse):
    choices: List[DevicesChatChoice]

import logging
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, List, Optional, Tuple, Union

import requests
import yaml
from dacite import DaciteError, from_dict
from requests.auth import HTTPBasicAuth

from crowd_sdk.core.config import DEFAULT_CONFIG, CrowdConfig
from crowd_sdk.core.utils.common import urljoin_with_path
from crowd_sdk.core.utils.datacls import AsDictMixin, FromDictMixin

from .datacls import Message

logger = logging.getLogger(__file__)


GC_TIMEOUT = 10
N_THREADS = 5


@dataclass
class BaseChatParams(AsDictMixin, FromDictMixin):
    def update(
        self,
        params: Any,
        ignore_attrs: Tuple[str, ...] = (),
        ignore_none: bool = False,
    ) -> Any:
        data = self.asdict()
        for key, value in params.asdict().items():
            if key in ignore_attrs or ignore_none and value is None:
                continue
            data[key] = value
        return type(self)(**data)


@dataclass
class DevicesChatParams(BaseChatParams):  # pylint: disable=too-many-instance-attributes
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    n: Optional[int] = None
    max_tokens: Optional[int] = None  # default is 512
    repetition_penalty: Optional[float] = None  # default is 1.07

    def __post_init__(self) -> None:
        if self.temperature:
            assert 0 < self.temperature <= 2, "Parameter `temperature` must be in (0; 2]"
        if self.top_p:
            assert 0 < self.top_p <= 1, "Parameter `temperature` must be in (0; 1]"
        if self.n:
            assert self.n < 5, "Parameter `n` must be in [1; 4]"
        if self.max_tokens is not None:
            assert self.max_tokens > 0, "Parameter `max_tokens` must be bigger than 0"
        if self.repetition_penalty:
            assert self.repetition_penalty >= 0, "Parameter `repetition_penalty` must be in [0; +00]"


SECTION_NAME = 'gigachat'


@CrowdConfig.crowd_config_section(SECTION_NAME)
@dataclass
class GigaChatConfig:
    base_url: str
    model: str
    raw_api: bool = False
    params: DevicesChatParams = field(default_factory=DevicesChatParams)
    n_threads: int = N_THREADS
    auth_url: Optional[str] = None
    user: Optional[str] = None
    password: Optional[str] = None
    client_id: Optional[str] = None
    client_secret: Optional[str] = None
    credentials: Optional[str] = None
    process_chunk_size: Optional[int] = None
    prompts: Optional[List[Message]] = None
    __token: Optional[str] = field(init=False)
    __exp: Optional[int] = field(init=False)

    @staticmethod
    def get_token_basic(base_url: str, user: str, password: str) -> dict:
        url = urljoin_with_path(base_url, "/token")
        response = requests.post(url=url, auth=HTTPBasicAuth(user, password), timeout=GC_TIMEOUT, verify=False)
        response.raise_for_status()
        return response.json()

    @staticmethod
    def get_token_credentials(auth_url: str, credentials: str) -> dict:
        url = urljoin_with_path(auth_url, "/v2/oauth")

        response = requests.post(
            url=url,
            timeout=GC_TIMEOUT,
            verify=False,
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Authorization": f"Bearer {credentials}",
                "RqUID": "6f0b1291-c7f3-43c6-bb2e-9f3efb2dc98e",
            },
            data={"scope": "GIGACHAT_API_CORP"},
        )
        response.raise_for_status()
        return response.json()

    @staticmethod
    def get_token_client_id(auth_url: str, client_id: str, client_secret: str) -> dict:
        url = urljoin_with_path(auth_url, "/v2/oauth")

        response = requests.post(
            url=url,
            timeout=GC_TIMEOUT,
            verify=False,
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "RqUID": "6f0b1291-c7f3-43c6-bb2e-9f3efb2dc98e",
                "client_id": client_id,
                "client_secret": client_secret,
            },
            data={
                "scope": "GIGACHAT_API_CORP",
            },
        )
        response.raise_for_status()
        return response.json()

    def update_token(self) -> None:
        if self.credentials:
            assert self.auth_url
            token_info = self.get_token_credentials(self.auth_url, self.credentials)
            assert 'access_token' in token_info
            assert 'expires_at' in token_info
            self.__token = token_info['access_token']
            self.__exp = token_info['expires_at']
        elif self.client_id and self.client_secret:
            assert self.auth_url
            token_info = self.get_token_client_id(self.auth_url, self.client_id, self.client_secret)
            assert 'access_token' in token_info
            assert 'expires_at' in token_info
            self.__token = token_info['access_token']
            self.__exp = token_info['expires_at']
        elif self.user and self.password:
            assert self.auth_url
            token_info = self.get_token_basic(self.auth_url, self.user, self.password)
            assert 'tok' in token_info
            assert 'exp' in token_info
            self.__token = token_info['tok']
            self.__exp = token_info['exp']
        else:
            self.__token = None
            self.__exp = None

    def __post_init__(self) -> None:
        if not self.raw_api:
            self.base_url += '/v1'
        if self.auth_url is None:
            self.auth_url = self.base_url
        self.update_token()

    @property
    def token(self) -> Optional[str]:
        if self.__exp is None or self.__exp < datetime.now().timestamp():
            self.update_token()
        return self.__token

    @staticmethod
    def from_path(config_path: Union[Path, str] = DEFAULT_CONFIG) -> 'GigaChatConfig':
        config_path = Path(config_path).expanduser()

        if not config_path.is_file():
            raise ValueError(f'Config path is not a file: {config_path}')

        with config_path.open('r') as f:
            file_data = yaml.safe_load(f)

        if SECTION_NAME in file_data:
            file_data = file_data[SECTION_NAME]

        try:
            return from_dict(data_class=GigaChatConfig, data=file_data)
        except DaciteError as exp:
            raise TypeError(f'Expecting {config_path} to be a dict compatible to AuthConfig') from exp

from dataclasses import dataclass
from enum import Enum
from typing import List, Optional


class SearchThemesFilter(Enum):
    ALL = "all"
    ANY = "any"
    EXCLUDE = "exclude"


class SearchStatus(Enum):
    NOT_APPROVED = "not_approved"
    EDITOR_APPROVED = "editor_approved"
    PROOFREADER_APPROVED = "proofreader_approved"
    APPROVED = "approved"


class Status(Enum):
    OK = "ok"
    ERROR = "error"


class Side(Enum):
    USER = "user"
    BOT = "bot"


@dataclass
class Message:
    id: int
    uuid: str
    side: Side
    text: str
    created_at: str
    updated_at: str
    dialog_id: Optional[int]


@dataclass
class DialogItem:
    id: int
    uuid: str
    bot_character: Optional[str]
    bucket_name: Optional[str]
    name: str
    messages_count: int
    messages: List[Message]
    created_at: str
    updated_at: str
    editor_approved: bool
    proofreader_approved: bool
    segments: Optional[List[str]]
    themes: Optional[List[str]]


@dataclass
class GetAllData:
    dialogs: List[DialogItem]
    timestamp: int


@dataclass
class GetAllResponse:
    status: Status
    data: GetAllData

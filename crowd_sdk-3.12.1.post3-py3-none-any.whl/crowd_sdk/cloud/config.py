from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Union

import yaml

from crowd_sdk.core.config import DEFAULT_CONFIG, CrowdConfig

from .cloud import Cloud


@dataclass
class CloudInstanceConfig:
    endpoint: str
    key: str
    secret: str


SECTION_NAME = 'cloud'


@CrowdConfig.crowd_config_section(SECTION_NAME)
@dataclass
class Clouds:
    def __init__(self, config: Union[str, Path, Dict[str, Any]] = DEFAULT_CONFIG) -> None:
        """
        Constructs clouds collection for further using in data pipelines
        Args:
            config: Path to file with config or dictionary in format:
                'main': {
                    'key': '...',
                    'secret': '...',
                    'endpoint': '...',
                }
                File format is needed to be yaml, we supports two yaml-formats:
                    - good style is to have cloud-section in dict-format specified above
        """
        if isinstance(config, (str, Path)):
            with open(Path(config).expanduser()) as f:
                config_ = yaml.safe_load(f)
                if not isinstance(config_, dict):
                    raise TypeError(f'File config {str} must be a dict')
                if 'cloud' in config_ and isinstance(config_, dict) and config_['cloud'].get('main'):
                    config = config_['cloud']
                else:
                    raise ValueError(f'There\'s no cloud section in the config={config} data={config_}')

        if not isinstance(config, dict):
            raise TypeError(f'Wrong type for cloud config: {type(config)}')
        self.instances = {name: Cloud(instance_cfg) for name, instance_cfg in config.items()}
        self.config = config
        assert 'main' in config, f'Key main must be in the cloud config {config}'

    @property
    def main(self) -> Cloud:
        return self.instances['main']

    def get(self, name: str) -> Cloud:
        return self.instances[name]

    def get_config(self, name: str) -> Any:
        return self.config[name]

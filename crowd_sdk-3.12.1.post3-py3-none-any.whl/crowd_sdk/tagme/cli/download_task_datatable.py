import logging
from typing import Optional

import click

from crowd_sdk.core.utils.common import get_event_loop
from crowd_sdk.core.utils.table import save_results
from crowd_sdk.tagme import DEFAULT_CONFIG, TagmeClientAdvanced, TagmeConfig
from crowd_sdk.tagme.cli.group import tagme_commands

logger = logging.getLogger(__name__)


DEFAULT_FORMAT = 'tsv'
DEFAULT_RESULTS = 'results.tsv'


async def download_task_data(
    config: TagmeConfig, task_id: str, destination: str, ext: str, organization_id: Optional[str] = None
) -> None:
    async with TagmeClientAdvanced(config=config) as client:
        results = await client.get_task_src_flat(task_id=task_id, organization_id=organization_id)
    save_results(results, destination, ext)


@tagme_commands.command(name='download_src_table')
@click.option('-t', '--task-id', required=True, help='Task identifier')
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
@click.option('-d', '--destination', help='Destination file to save markup', default=DEFAULT_RESULTS)
@click.option(
    '-e',
    '--ext',
    type=click.Choice(['csv', 'tsv', 'json', 'xlsx'], case_sensitive=False),
    help='Format',
    default=DEFAULT_FORMAT,
)
@click.option('-o', '--organization-name', required=False, help='Organization key')
@click.option('--organization-id', required=False, help='Organization id')
def download_task_datatable_cli(
    task_id: str,
    config_path: str,
    destination: str,
    ext: str,
    organization_name: Optional[str],
    organization_id: Optional[str],
) -> None:
    """
    Download dataset (table) from the task to specified distination file
    """
    config = TagmeConfig.cli_initialize(config_path, organization_name, organization_id)
    file_count = get_event_loop().run_until_complete(
        download_task_data(config, task_id, destination, ext, organization_id=organization_id)
    )
    if file_count:
        logger.info(f'Downloaded {file_count} files to {destination}!')

import json
import logging
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import click

from crowd_sdk.core.utils.common import get_event_loop
from crowd_sdk.tagme import DEFAULT_CONFIG, TagmeClientAdvanced
from crowd_sdk.tagme.cli.group import tagme_commands
from crowd_sdk.tagme.config import TagmeConfig

logger = logging.getLogger(__name__)


async def extend_task_results(
    config_path: Path,
    export_file: str,
    destination_file: Union[str, Path],
    organization_name: Optional[str],
    organization_id: Optional[str],
) -> None:
    config = TagmeConfig.cli_initialize(config_path, organization_name, organization_id)
    destination_file = Path(destination_file)

    async with TagmeClientAdvanced(config) as client:
        markers = await client.get_employees(with_info=True, organization_id=organization_id)
        marker_info_dict = {marker.person_id: marker.person for marker in markers}

        with open(destination_file.with_suffix('.markers'), 'w') as markers_file:
            json.dump(list(marker_info_dict.keys()), markers_file, sort_keys=True, indent=4, ensure_ascii=False)

        with open(export_file) as export_f:
            templates: List[Dict[str, Any]] = json.load(export_f)
            for item in templates:
                task = await client.get_task(item['task_id'], organization_id=organization_id)
                item['task'] = task.name
                item['person'] = asdict(marker_info_dict.get(item['person_id']))

                for marker in item['result']:
                    if marker not in marker_info_dict:
                        marker_info = None
                    else:
                        marker_info = asdict(marker_info_dict.get(marker))

                    item['result'][marker]['person'] = marker_info
    with open(destination_file, 'w') as destination_f:
        json.dump(templates, destination_f, sort_keys=True, indent=4, ensure_ascii=False)


@tagme_commands.command(name='extend_results')
@click.option('-e', '--export-file', required=True, help='File exported from TagMe')
@click.option('-d', '--destination-file', required=True, help='Destination file to save extended result')
@click.option('-o', '--organization-name', help='Organization name.')
@click.option('--organization-id', required=False, help='Organization id')
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
def extend_task_results_cli(
    export_file: str,
    destination_file: str,
    organization_name: Optional[str],
    organization_id: Optional[str],
    config_path: Union[str, Path],
) -> None:
    """
    Update TagMe export file with task author's and markers' full names as well as task name
    """

    get_event_loop().run_until_complete(
        extend_task_results(
            config_path=Path(config_path),
            export_file=export_file,
            destination_file=destination_file,
            organization_name=organization_name,
            organization_id=organization_id,
        )
    )

    logger.info('ExtendExportFile done')

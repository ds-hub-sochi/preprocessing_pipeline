import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, AsyncGenerator, Optional, Union

import aiohttp
import click
import pandas as pd
import yaml
from dacite import from_dict

from crowd_sdk.core.utils.common import get_event_loop
from crowd_sdk.tagme import DEFAULT_CONFIG, TagmeClientAdvanced, types
from crowd_sdk.tagme.cli.group import tagme_commands
from crowd_sdk.tagme.http_client.base_client import row_to_task

logger = logging.getLogger(__name__)

FORMAT = '%(message)s'


TASK_TYPES = {
    "exam": {
        "type": types.TaskType.EXAM,
        "priority": 100,
    },
    "study": {
        "type": types.TaskType.STUDY,
        "priority": 99,
    },
    "prod": {
        "type": types.TaskType.PROD,
        "priority": 10,
    },
    "retry": {
        "type": types.TaskType.RETRY,
        "priority": 0,
    },
}


def read_file(path: Union[Path, str]) -> Any:
    path = Path(path)
    with path.open() as f:
        return f.read()


async def get_url(url_path: str) -> Optional[str]:
    async with aiohttp.ClientSession() as session:
        async with session.get(url_path, verify_ssl=False) as resp:
            if resp.status == 200:
                return await resp.text()
    return None


def find_proper_file(filepath: Union[str, Path], key: str) -> Any:
    for ext in ['tsv', 'json', 'csv', 'xlsx']:
        curpath = Path(filepath) / (key + '.' + ext)
        if curpath.exists():
            return curpath, ext

    for ext in ['tsv', 'json', 'csv', 'xlsx']:
        curpath = Path(filepath) / ('study.' + ext)
        if curpath.exists():
            return curpath, ext

    return None, None


def read_ext(filepath: Union[str, Path], ext: str) -> Any:
    if ext == 'json':
        with open(filepath) as f:
            data = json.load(f)
            for row in data:
                yield row
            return

    if ext == 'xlsx':
        df = pd.read_excel(filepath, index_col=None, na_filter=False, engine='openpyxl')
    elif ext == 'csv':
        df = pd.read_csv(filepath, index_col=None, na_filter=False)
    elif ext == 'tsv':
        df = pd.read_csv(filepath, index_col=None, na_filter=False, sep='\t')
    else:
        raise NotImplementedError(f'ext processor not found {ext}')

    for row in df.to_dict('records'):
        yield row
    return


def data_from_study(filepath: Union[str, Path], key: str, ext: str) -> Any:
    filepath = Path(filepath)
    json_data = []

    for row in read_ext(filepath, ext):
        data = row_to_task(row)
        if key == 'study':
            pass
        elif key == 'exam':
            if 'hint' in data:
                del data['hint']
        elif key == 'prod':
            if 'hint' in data:
                del data['hint']
            if 'control' in data:
                del data['control']
        elif key == 'retry':
            if 'hint' in data:
                del data['hint']
            if 'control' in data:
                del data['control']
        else:
            raise RuntimeError(f'unknown key type {key}')
        json_data.append(data)

    return json_data


@dataclass
class TemplateConfig:
    name: str
    path: Union[str, Path]
    description: str = ''
    inner_comment: str = ''
    html: Optional[Union[str, Path]] = None
    css: Optional[Union[str, Path]] = None
    instruction: Optional[Union[str, Path]] = None

    js: Optional[Union[str, dict, Path]] = None
    config: Optional[Union[str, dict, Path]] = None
    example: Optional[Union[str, dict, Path]] = None

    def __post_init__(self) -> None:  # pylint: disable=too-many-branches
        self.path = Path(self.path)
        assert self.path.exists(), f'Path not exists {self.path}'

        if self.html is None:
            self.html = Path(self.path) / 'index.html'
        if isinstance(self.html, Path) and self.html.exists():
            self.html = self.html.read_text()

        if self.html is None:
            raise RuntimeError(f'Html not found {self.html}')

        if self.instruction is None:
            self.instruction = Path(self.path) / 'instruction.html'
        if isinstance(self.instruction, Path) and self.instruction.exists():
            self.instruction = self.instruction.read_text()

        if self.instruction is None:
            raise RuntimeError(f'instruction not found {self.instruction}')

        if self.css is None and (Path(self.path) / 'index.css').exists():
            self.css = Path(self.path) / 'index.css'
        if isinstance(self.css, Path) and self.css.exists():
            self.css = self.css.read_text()

        if not self.css:
            self.css = ''

        if self.js is None and (Path(self.path) / 'index.js').exists():
            self.js = Path(self.path) / 'index.js'
        if isinstance(self.js, Path) and self.js.exists():
            self.js = self.js.read_text()

        if not self.js:
            self.js = ''

        if self.config is None and (Path(self.path) / 'config.json').exists():
            self.config = Path(self.path) / 'config.json'
        if isinstance(self.config, Path) and self.config.exists():
            self.config = self.config.read_text()

        if not self.config:
            self.config = ''

        if self.example is None and (Path(self.path) / 'example.json').exists():
            self.example = Path(self.path) / 'example.json'
        if isinstance(self.example, Path) and self.example.exists():
            self.example = self.example.read_text()

        if not self.example:
            self.example = ''

    @staticmethod
    async def from_tagme_template(data: dict, path: str, base_url: str) -> 'TemplateConfig':
        return TemplateConfig(
            name=data['title'],
            path=path,
            description=data['description'],
            html=(await get_url(base_url + '/index.html') or ''),
            js=(await get_url(base_url + '/index.js') or ''),
            css=(await get_url(base_url + '/index.css') or '/* empty css */'),
            example=(await get_url(base_url + '/example.json') or '{}'),
            config=(await get_url(base_url + '/config.json') or '{}'),
        )

    @staticmethod
    def __to_str(value: Optional[Union[str, dict, Path]], default: str) -> str:
        if isinstance(value, str):
            return value
        if isinstance(value, dict):
            return json.dumps(value, ensure_ascii=False, indent=2)
        if value is None:
            return default
        return default

    @staticmethod
    def __to_dict(value: Optional[Union[str, dict, Path]], default: dict) -> dict:
        if value is None:
            return default

        if isinstance(value, Path) or (isinstance(value, str) and len(value) < 256 and Path(value).exists()):
            data = read_file(value)
            return json.loads(data)

        if isinstance(value, str):
            return json.loads(value)

        return value

    def to_method(self) -> types.MethodForms:
        return types.MethodForms(
            html=self.__to_str(self.html, ''),
            css=self.__to_str(self.css, ''),
            js=self.__to_str(self.js, '{}'),
            config=self.__to_dict(self.config, {}),
            example=self.__to_dict(self.example, {}),
        )


class TestsCreator:
    """
    Create TagMe test projects and tasks
    """

    def __init__(
        self,
        crowd_config: Union[str, Path] = DEFAULT_CONFIG,
        tests_config: str = 'tests.yaml',
        verbose: bool = False,
        fill_premarkup: bool = False,
        markers_key: str = 'autotest_markers',
    ) -> None:
        self._client: TagmeClientAdvanced = TagmeClientAdvanced(crowd_config)

        config_path = Path(tests_config).expanduser()
        self._base_path = config_path.parent
        with config_path.open('r') as f:
            config_data = f.read()
            self._config = yaml.safe_load(config_data)

        self._fill_premarkup = fill_premarkup
        self._markers_key = markers_key
        self._found_pool: Optional[str] = None

        self._users: dict = {}
        self._project_configs: dict = {}
        logging.basicConfig(level=logging.DEBUG if verbose else logging.INFO, format=FORMAT)

    async def __find_or_create_markers_pool(self) -> str:
        if self._found_pool is not None:
            return self._found_pool

        pools = await self._client.get_organization_pools()
        for pool in sorted(pools, key=lambda x: x.uid):
            if self._markers_key in (pool.name, pool.uid):
                self._found_pool = pool.uid
                return pool.uid
        current_user = await self._client.get_self_person()
        pool = await self._client.create_pool(name=self._markers_key, markers=[current_user.email])
        self._found_pool = pool.uid
        return pool.uid

    async def run_external(self) -> None:
        logger.info('Creating external tasks...')
        for key, ext_template_data in self._config['external'].items():
            ext_template_data['name'] = ext_template_data.get('name', key)
            if 'path' in ext_template_data:
                ext_template_data['path'] = self._base_path / ext_template_data['path']
            template_config = from_dict(data_class=TemplateConfig, data=ext_template_data)

            async for url in self.run_external_template(template_config):
                logger.info(f'NEW_TASK: {url} {ext_template_data["name"]}')

    async def run_tagme(self) -> None:
        logger.info('Creating tagme tasks...')
        base_url = (self._client.client.config.auth_url or '').rstrip('/')
        async with aiohttp.ClientSession() as session:
            async with session.get(base_url + '/templates/templates.json', verify_ssl=False) as resp:
                all_templates = await resp.json()

        for templates_category in all_templates:
            for tm_template_data in templates_category['templates']:
                folder = tm_template_data['path'][len('/templates/') :]
                path = self._base_path / self._config['tagme']['data'] / folder
                if path.exists():
                    logger.info(f'TASK_FOUND: {path}, skipping')

                    template_base_url = base_url + tm_template_data['path']

                    logger.info(f'Creating tagme task {path}')
                    template_config = await TemplateConfig.from_tagme_template(
                        tm_template_data, path=path, base_url=template_base_url
                    )
                    async for url in self.run_external_template(template_config):
                        logger.info(f'NEW_TASK: {url} {path}')
                else:
                    logger.info(f'TASK_NOT_FOUND: {path}, skipping')
                    template_config = TemplateConfig(
                        path='./',
                        name='💥 ' + tm_template_data['title'],
                        description=tm_template_data['description'],
                        inner_comment=f'Fill data {path} for the project',
                        html='',
                        css='/* empty css */',
                        instruction='',
                        js='',
                        config='{}',
                        example='{}',
                    )
                    template_config.path = path
                    try:
                        async for url in self.run_external_template(template_config):
                            logger.info(f'NEW_TASK: {url} {path}')
                    except RuntimeError:
                        pass

    async def run(self) -> None:
        await self.run_tagme()
        await self.run_external()

    async def run_external_template(self, template_config: TemplateConfig) -> AsyncGenerator:
        pool_id = await self.__find_or_create_markers_pool()

        project = await self._client.create_project(
            name=template_config.name,
            description=template_config.description,
            inner_comment=template_config.inner_comment,
        )
        method_data = types.MethodData(
            uid=project.method_id,
            name=template_config.name,
            forms=template_config.to_method(),
            marker_brief=str(template_config.instruction) if template_config.instruction else '',
        )
        await self._client.update_method(method=method_data)

        await self._client.add_users_to_project(project_id=project.uid, pool_id=pool_id)

        if not find_proper_file(template_config.path, 'study'):
            logger.warning(f'No data for the task {template_config.name} {template_config.path}')
            return

        for key, type_config in TASK_TYPES.items():
            task_type = type_config['type']
            priority = type_config['priority']
            assert isinstance(task_type, types.TaskType)
            assert isinstance(priority, int)
            task_data = types.TaskDataRequest(  # type: ignore
                project_id=project.uid,
                organization_id=project.organization_id,
                name=template_config.name + '_' + key,
                overlap=1,
                type=task_type,
                price=0,
                priority=priority,
            )
            task = await self._client.create_task(task_data)

            task.out_skill_id = self._config['skill_id']
            await self._client.update_task(task)

            filepath, ext = find_proper_file(template_config.path, key)

            if filepath is not None and filepath.exists():
                json_data = data_from_study(filepath, key, ext)

                await self._client.upload_json_data(
                    task_id=task.uid,
                    json_data=json_data,
                    base_path=template_config.path,
                )
            else:
                raise RuntimeError(f'Task data {template_config.path} {key} not found: {filepath}')

            await self._client.start_task(task_id=task.uid)

            yield await self._client.gen_task_url(
                project_id=task.project_id,
                task_id=task.uid,
                organization_id=task.organization_id,
            )


async def run_qa(
    config_path: Union[str, Path],
    tests_config: str,
    verbose: bool,
    markers_key: str,
) -> None:
    tc = TestsCreator(crowd_config=config_path, tests_config=tests_config, verbose=verbose, markers_key=markers_key)
    await tc.run()


@tagme_commands.command(name='qa')
@click.option('-t', '--tests-config', type=click.Path(exists=True), help='Path to QA .yaml config file')
@click.option('-v', '--verbose', is_flag=True, default=False, help='Verbose')
@click.option('-m', '--markers-key', default='autotest_markers', help='Autotest markers group')
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
def qa_cli(
    tests_config: str = 'tests.yaml',
    verbose: bool = False,
    markers_key: str = 'autotest_markers',
    config_path: Union[str, Path] = DEFAULT_CONFIG,
) -> None:
    """
    Скрипт, который создает проекты и задачи для тестирования всех шаблонов,
    включая наши шаблоны и включая внешние шаблоны.

    Сценарий использования:
    - запускаем скрипт, выбирая с помощью конфига среду запуска и тестовую организацию
    - скрипт читает так же yaml-конфиг, в котором описаны задания и данные которые надо залить
    - скрипт бежит по конфигу и создает:
    - проекты с базовой настройкой (название (имя+дата), подпись: имя; дата; тип данных; тип задания)
    - заполняет интерфыейсы и инструкцию
    - создает задачи:
        - обучение
        - экзамен
        - реабилитация
        - боевое
    - запускает задачи
    """
    get_event_loop().run_until_complete(run_qa(config_path, tests_config, verbose, markers_key))

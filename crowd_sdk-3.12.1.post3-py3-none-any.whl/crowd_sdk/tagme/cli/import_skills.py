import asyncio
import logging
from dataclasses import dataclass
from itertools import chain
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Union

import click
from tqdm import tqdm

from crowd_sdk.core.utils.common import chunks, get_event_loop
from crowd_sdk.core.utils.table import save_results, tsv_load
from crowd_sdk.tagme import DEFAULT_CONFIG, TagmeClientAdvanced
from crowd_sdk.tagme.cli.group import tagme_commands
from crowd_sdk.tagme.config import TagmeConfig
from crowd_sdk.tagme.types import Person, Skill

logger = logging.getLogger(__name__)


EMAILS_BATCH_SIZE = 50  # by characters limit for get parameters
DEFAULT_FORMAT = 'tsv'


@tagme_commands.command(name='import_skills')
@click.option('-p', '--path', type=click.Path(exists=True, path_type=Path), help='Skills TSV table')
@click.option('-o', '--organization', required=False, help='Organization key')
@click.option('--dry-run', is_flag=True, default=False, help='Do not push changes, just print actions')
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
def import_skills_cli(
    organization: Optional[str],
    dry_run: bool,
    config_path: Union[str, Path],
    path: Path,
) -> None:
    """
    Set skills from the local tsv file with heared: 'mail', 'skill', 'value'
    """
    config = TagmeConfig.from_any(config_path)
    config.prompt_user_and_password_if_missing()

    get_event_loop().run_until_complete(
        import_skills_cli_(
            organization=organization or config.org,
            config_path=config_path,
            dry_run=dry_run,
            path=path,
        )
    )


@tagme_commands.command(name='export_skills')
@click.option('-d', '--dst', type=click.Path(path_type=Path), help='Skills TSV table')
@click.option('-p', '--project_name', required=False, help='Project key')
@click.option('-o', '--organization', required=False, help='Organization key')
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
@click.option(
    '-e',
    '--ext',
    type=click.Choice(['csv', 'tsv', 'json', 'xlsx'], case_sensitive=False),
    help='Format',
    default=DEFAULT_FORMAT,
)
def export_skills_cli(
    organization: Optional[str],
    config_path: Union[str, Path],
    dst: Path,
    project_name: Optional[str],
    ext: str,
) -> None:
    """
    Download skills table: skill, user, value
    """
    config = TagmeConfig.from_any(config_path)
    config.prompt_user_and_password_if_missing()

    get_event_loop().run_until_complete(
        export_skills_cli_(
            organization=organization or config.org,
            config_path=config_path,
            project_name=project_name,
            path=dst,
            ext=ext,
        )
    )


@dataclass
class PersonSkill:
    person: Person
    skill: Skill
    value: int


async def get_skill_map(
    client: TagmeClientAdvanced,
    skill_names: Iterable[str],
    organization_id: Optional[str] = None,
    dry_run: bool = False,
) -> Dict[str, Skill]:
    skills_list = {x.strip() for x in skill_names if x and x.strip()}
    existing_skills = await client.get_skills_list(organization_id=organization_id)

    skills = {}
    for skill in existing_skills:
        if skill.name in skills_list:
            skills[skill.name] = skill
            skills_list.discard(skill.name)

        if skill.uid in skills_list:
            skills[skill.uid] = skill
            skills_list.discard(skill.uid)

    for skill_name in skills_list:
        if not dry_run:
            skill = await client.create_skill(skill_name, organization_id)
        else:
            logger.info(f'creating skill with name "{skill_name}"')
            skill = Skill(name=skill_name, uid='', person_id='')

        skills[skill_name] = skill

    return skills


async def get_person_map(client: TagmeClientAdvanced, emails: Sequence[str]) -> Dict[str, Person]:
    persons = {}
    coros = [client.client.get_persons(emails=e) for e in chunks(emails, n=EMAILS_BATCH_SIZE)]
    for p in chain(*(await asyncio.gather(*coros))):  # type: Person
        persons[p.email] = p

    return persons


async def get_person_skill_from_table(
    client: TagmeClientAdvanced, path: Path, organization_id: Optional[str] = None, dry_run: bool = False
) -> List[PersonSkill]:
    rows = list(tsv_load(path))
    if not rows or not all(x in rows[0] for x in ('mail', 'skill', 'value')):
        raise ValueError('missing values in skills table')

    skills = await get_skill_map(client, {x['skill'] for x in rows}, organization_id, dry_run)
    persons = await get_person_map(client, list({x['mail'] for x in rows if x['mail']}))

    result = []
    for row in rows:
        if not row['mail'] or not row['skill'].strip() or not row['value']:
            logger.warning(f'missing value in row: {row}')
            continue

        if row['mail'] not in persons:
            logger.warning(f"user with email {row['mail']} is not found")
            continue

        result.append(PersonSkill(person=persons[row['mail']], skill=skills[row['skill']], value=int(row['value'])))

    return result


async def import_skills_cli_(
    organization: Optional[str],
    config_path: Union[str, Path],
    dry_run: bool,
    path: Path,
) -> None:
    client = TagmeClientAdvanced(config=config_path)
    org = await (client.get_organization(organization) if organization else client.client.get_current_organization())
    logger.info(f'org {org.name}')

    if dry_run:
        person_skills = await get_person_skill_from_table(client, path, org.uid, dry_run)
        for ps in tqdm(person_skills):
            logger.info(
                f'set person {ps.person.first_name} {ps.person.last_name}({ps.person.uid}) '
                f'skill {ps.skill.name}({ps.skill.uid}) ={ps.value}'
            )
    else:
        await client.set_markers_skills(table_path=path)


async def export_skills_cli_(
    organization: Optional[str],
    config_path: Union[str, Path],
    path: Path,
    project_name: Optional[str],
    ext: str,
) -> None:
    client = TagmeClientAdvanced(config=config_path)
    if organization:
        org = await client.get_organization(organization)
        client.client.config.org = org.name

    target_skills = None
    if project_name:
        projects = await client.get_projects(query=project_name)

        target_skills = set()
        for p in projects:
            for task in await client.get_tasks(project_id=p.uid):
                if task.out_skill_id:
                    target_skills.add(task.out_skill_id)

    skills = await client.get_markers_skills_list(with_info=True)

    results = []
    for skill in skills:
        if target_skills is None or skill.uid in target_skills:
            assert skill.person
            results.append(
                {
                    'skill': skill.name,
                    'value': skill.value,
                    'mail': skill.person.email,
                    'user_id': skill.person_id,
                    'project_name': project_name,
                }
            )

    save_results(results, str(path), ext)

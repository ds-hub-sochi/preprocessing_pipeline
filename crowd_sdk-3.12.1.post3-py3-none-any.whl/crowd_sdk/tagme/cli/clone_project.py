from typing import Optional

import click

from crowd_sdk.core.utils.common import get_event_loop
from crowd_sdk.tagme import DEFAULT_CONFIG, TagmeClientAdvanced
from crowd_sdk.tagme.cli.group import tagme_commands
from crowd_sdk.tagme.config import TagmeConfig


async def clone_project(
    config: TagmeConfig,
    project_id: str,
    src_organization_id: Optional[str],
    dst_organization_id: Optional[str],
    clone_all_files: bool,
) -> str:
    client = TagmeClientAdvanced(config=config)
    project_id = await client.clone_project_with_data(
        project_id=project_id,
        organization_id=src_organization_id,
        dst_organization_id=dst_organization_id,
        clone_all_files=clone_all_files,
    )
    await client.close()
    return project_id


@tagme_commands.command(name='clone_project')
@click.option('-p', '--project-id', required=True)
@click.option('-o', '--organization-name', required=False, help='Organization key to clone project from')
@click.option('--organization-id', required=False, help='Organization id to clone project from')
@click.option('--target-organization-id', required=False, help='Organization to clone project to')
@click.option('-a', '--all-files', required=False, is_flag=True)
@click.option(
    '-c', '--config-path', type=click.Path(exists=True), help='Path to TagMe .cfg file', default=DEFAULT_CONFIG
)
def clone_project_cli(
    project_id: str,
    organization_name: Optional[str],
    organization_id: Optional[str],
    target_organization_id: Optional[str],
    config_path: str,
    all_files: bool,
) -> str:
    """
    clone project and task. Uploads all unmarked files to newly created task. If overlap
    is >= 1 and file was not marked by all markers, then it will be uploaded still.
    """
    config = TagmeConfig.cli_initialize(config_path, organization_name, organization_id)
    project_id = get_event_loop().run_until_complete(
        clone_project(
            config,
            project_id=project_id,
            src_organization_id=organization_id,
            dst_organization_id=target_organization_id,
            clone_all_files=all_files,
        )
    )
    return project_id

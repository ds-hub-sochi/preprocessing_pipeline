# pylint: disable=too-many-lines
import json
import logging
from dataclasses import dataclass, field, fields
from datetime import date, datetime
from enum import Enum
from mimetypes import guess_extension
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import aiofiles
import pytz
from aiohttp import StreamReader
from dacite.core import is_instance

from crowd_sdk.core.utils.common import DATE_TIME_UTC_FORMATS, dataclass_to_dict, md5_str, parse_date

logger = logging.getLogger(__name__)

# -----------------------------------------------------------------------------
#                                  PROJECT
# -----------------------------------------------------------------------------


class ExportFormat(Enum):
    CSV = 'csv'
    JSON = 'json'
    XLS = 'xls'
    TSV = 'tsv'


EXPORT_SUFFIX = {
    ExportFormat.CSV: '.csv',
    ExportFormat.JSON: '.json',
    ExportFormat.XLS: '.xlsx',
    ExportFormat.TSV: '.tsv',
}

utctz = pytz.timezone("UTC")


def fmt_date(d: Optional[datetime]) -> Optional[str]:
    if not d:
        return None
    return d.astimezone(utctz).isoformat().replace("+00:00", "Z")


class ExportTypes(Enum):
    MARKERS = 'MARKERS'
    TASKS = 'TASKS'


@dataclass
class Project:
    organization_id: str
    name: str
    description: str
    inner_comment: str
    pools: List[str]
    uid: str
    method_id: str
    person_id: str
    created_date: Optional[datetime]
    running_tasks_count: Optional[int]
    tasks_count: Optional[int]
    is_archived: bool = False
    method: Optional['MethodData'] = None
    is_bookmarked: bool = False
    pipeline: Optional[dict] = None
    is_pipeline_enabled: Optional[bool] = False


@dataclass
class ProjectStatistic:
    project_id: str
    markers_count: Optional[int] = None
    pools_count: Optional[int] = None
    objects_count: Optional[int] = None
    marked_count: Optional[int] = None
    status: Optional[str] = None
    tasks_count: Optional[int] = None


@dataclass
class TypeCasting:
    def __post_init__(self) -> None:
        for dataclass_field in fields(self):
            field_type = dataclass_field.type
            value = getattr(self, dataclass_field.name)

            if not is_instance(value, field_type):
                if is_instance(0.5, field_type) and isinstance(value, str):
                    setattr(self, dataclass_field.name, float(value))
                elif is_instance(1, field_type) and isinstance(value, str):
                    # TODO: (cerikoff) remove after TAGME-6694
                    try:
                        attr_value = int(value)
                    except ValueError:
                        attr_value = int(float(value))
                    setattr(self, dataclass_field.name, attr_value)
                elif str(field_type) == "<class 'datetime.datetime'>" and isinstance(value, str):
                    setattr(self, dataclass_field.name, parse_date(value))
                else:
                    setattr(self, dataclass_field.name, field_type(value))


@dataclass
class MarkersStatistic(TypeCasting):
    date: str
    organization: str
    project: str
    project_id: str
    task: str
    task_id: str
    marker_id: str
    email: str
    fio: str
    avg_time: float
    overall_time: float
    sum_price: float
    blocked_price: float
    begin: datetime
    end: datetime
    marked: int = 0
    skipped: int = 0
    accepted: int = 0
    rejected: int = 0
    submitted: int = 0
    expired: int = 0
    avg_quality: Optional[float] = None
    avg_consistency: Optional[float] = None


@dataclass
class TasksStatistic(TypeCasting):
    date: str
    organization: str
    project: str
    project_id: str
    task: str
    task_id: str
    overlap: int
    count_markers: int
    active_markers: int
    avg_time: float
    overall_time: float
    sum_price: float
    blocked_price: float
    count_assignments: int = 0
    count_items: int = 0
    completed_items: int = 0
    completed_assignments: int = 0
    accepted_assignments: int = 0
    rejected_assignments: int = 0
    submitted_assignments: int = 0
    skipped_assignments: int = 0
    expired_assignments: int = 0
    avg_consistency: Optional[float] = None
    avg_quality: Optional[float] = None
    task_type: Optional[str] = None


# -----------------------------------------------------------------------------
#                                    METHOD
# -----------------------------------------------------------------------------


@dataclass
class ExampleData:
    filename: Union[str, Dict, None] = ''
    explanation: Optional[str] = None
    control: Optional[Dict[str, Any]] = None
    premarkup: Optional[Dict[str, Any]] = None


@dataclass
class MethodForms:
    example: dict = field(default_factory=dict)
    config: dict = field(default_factory=dict)
    specification: dict = field(default_factory=dict)
    html: Optional[str] = ''
    css: Optional[str] = ''
    js: Optional[str] = ''


@dataclass
class MethodData:
    uid: str
    name: str
    forms: MethodForms
    marker_brief: str

    organization_id: Optional[str] = None
    person_id: Optional[str] = None
    modification_date: Optional[str] = None


# -----------------------------------------------------------------------------
#                                    TASKS
# -----------------------------------------------------------------------------


class TaskType(Enum):
    STUDY = 'STUDY'
    PROD = 'PROD'
    EXAM = 'EXAM'
    RETRY = 'RETRY'
    HONEYPOT = 'HONEYPOT'


class TaskSkipStrategy(Enum):
    COUNT_AS_MARKUP = 'COUNT_AS_MARKUP'
    IGNORE = 'IGNORE'
    NON_SKIPPABLE = 'NON_SKIPPABLE'


class TaskState(Enum):
    INITIAL = 'INITIAL'
    RUNNING = 'RUNNING'
    PAUSED = 'PAUSED'
    STOPPED = 'STOPPED'
    DONE = 'DONE'
    COMPILING = 'COMPILING'
    COMPILED = 'COMPILED'
    ARCHIVE = 'ARCHIVE'


@dataclass
class TaskDataRequest:
    project_id: str
    organization_id: str
    name: str
    overlap: int = 1
    type: TaskType = TaskType.PROD
    skip_strategy: TaskSkipStrategy = TaskSkipStrategy.NON_SKIPPABLE
    description: Optional[str] = ''  # HOTFIX for https://jira.sberbank.ru/browse/TAGME-4166
    price: Optional[float] = None
    priority: Optional[int] = None
    data_classification_level: Optional[str] = None
    data_source: Optional[str] = None
    control_count: Optional[int] = None
    control_fraction: Optional[int] = None
    item_timeout_seconds: Optional[int] = None
    out_skill_id: Optional[str] = None
    depersonalize: Optional[bool] = None
    deadline: Optional[date] = None
    expected_consistency: Optional[float] = None
    expected_quality: Optional[float] = None
    expected_sum: Optional[float] = None
    filter: Optional[dict] = None
    is_auto_accept: bool = True
    auto_accept_period_day: Optional[int] = None
    auto_accept_threshold: Optional[float] = None


@dataclass
class DatasetRequest:
    name: str
    data_classification_level: Optional[str] = None
    data_source: Optional[str] = None


@dataclass
class Dataset:
    id: str
    access: str
    owner_id: str
    created_date: datetime
    files_count: int
    name: str
    data_classification_level: Optional[str] = None
    data_source: Optional[str] = None


@dataclass
class TaskData:  # pylint: disable=too-many-instance-attributes
    project_id: str
    organization_id: str
    name: str
    uid: str
    person_id: str
    estimated_files_count: Optional[int]
    storage_id: Optional[str]
    item_timeout_seconds: Optional[int]
    use_project_method: Optional[bool]
    payload: Optional[dict]
    data_classification_level: Optional[str]
    data_source: Optional[str]
    control_count: Optional[int]
    control_fraction: Optional[int]
    created_date: Optional[datetime]
    start_date: Optional[datetime]
    finished_date: Optional[datetime]
    in_skill_id: Optional[str]
    in_skill_percent: Optional[int]
    out_skill_id: Optional[str]
    deadline: Optional[date]
    expected_consistency: Optional[float]
    expected_quality: Optional[float]
    expected_sum: Optional[float]
    filter: Optional[dict]
    type: TaskType = TaskType.PROD
    state: TaskState = TaskState.INITIAL
    is_active: bool = False
    overlap: int = 1
    skip_strategy: TaskSkipStrategy = TaskSkipStrategy.NON_SKIPPABLE
    deleted: bool = False
    description: Optional[str] = ''
    depersonalize: bool = False
    price: float = 0
    priority: int = 0
    is_auto_accept: bool = True
    auto_accept_period_day: Optional[int] = None
    auto_accept_threshold: Optional[float] = None


@dataclass
class TaskHierarchy:
    project_id: str
    organization_id: str


class CheckStatus(Enum):
    OK = "OK"
    WARNING = "WARNING"
    ERROR = "ERROR"


@dataclass
class CheckResult:
    status: CheckStatus
    message: Optional[str] = None


@dataclass
class SkillCheckResult(CheckResult):
    uid: Optional[str] = None


@dataclass
class CheckTaskResult:
    brief: Optional[CheckResult] = None
    form: Optional[CheckResult] = None
    markers: Optional[CheckResult] = None
    price: Optional[CheckResult] = None
    data_count: Optional[CheckResult] = None
    filter: Optional[CheckResult] = None
    control_count: Optional[CheckResult] = None
    out_skill: Optional[SkillCheckResult] = None
    one_active: Optional[CheckResult] = None
    data_classification_level: Optional[CheckResult] = None
    data_source: Optional[CheckResult] = None
    control_fraction: Optional[CheckResult] = None


@dataclass  # pylint: disable=R0902
class TaskStats:
    task_id: str
    total_marked_time: float
    objects_count: int
    marked_count: int
    total_skipped_objects_count: int
    total_marked_objects_count: int
    current_overlap: int
    total_objects_count: int
    avg_object_count_marker: float
    status: TaskState
    one_object_avg_time: float
    active_markers: int
    total_markers: int
    finished_marker: Optional[int]
    pretending_marker: Optional[int]
    cost: Optional[float]
    avg_quality: Optional[float]
    avg_consistency: Optional[float]


@dataclass
class TaskStatsAdvanced:
    estimation_date: Optional[date]
    in_progress_count: int


@dataclass
class TaskMarkup:
    pools: List[str]
    pick_date: datetime
    submit_date: datetime
    result: Dict[str, Any]


@dataclass  # pylint: disable=R0902
class TaskResult:
    uid: str
    entity_id: str
    task_id: str
    organization_id: str
    person_id: str
    storage_id: Optional[str]
    file_name: str
    entity_type: Optional[str]
    price: Optional[float]

    skip: Dict[str, Any] = field(default_factory=dict)
    result: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    consistency_percentage: Optional[float] = None
    consistent_result: Optional[bool] = None
    consistent_skip: Optional[bool] = None

    def to_dict(self) -> dict:
        return dataclass_to_dict(self)

    def append_assignment(self, assignment: 'Assignment') -> None:
        if assignment.status.lower() == 'skipped':
            if assignment.marker_id in self.skip:
                logger.debug(f'Duplicated skip {assignment.marker_id}')
            self.skip[assignment.marker_id] = assignment.to_skip_data()
        elif assignment.status.lower() == 'accepted':
            if assignment.marker_id in self.result:
                logger.debug(f'Duplicated result {assignment.marker_id}')
            self.result[assignment.marker_id] = assignment.to_result_data()
        else:
            logger.debug(f'Pass unhandled status {assignment.status.lower()}')

    @classmethod
    def from_assignments(cls, item_id: str, assignments: List['Assignment']) -> 'TaskResult':
        result = cls(
            uid=item_id,
            entity_id=item_id,
            task_id=assignments[0].task_id,
            organization_id=assignments[0].organization_id,
            person_id=assignments[0].person_id,
            storage_id=assignments[0].task_id,
            file_name=assignments[0].file_name,
            entity_type=assignments[0].item_type,
            price=assignments[0].price,
        )

        for assignment in assignments:
            result.append_assignment(assignment)

        return result


# -----------------------------------------------------------------------------
#                                    POOLS
# -----------------------------------------------------------------------------


@dataclass
class Member:
    uid: str
    person: 'Person'


@dataclass
class PoolOrganization:
    uid: str
    name: str


@dataclass
class Pool:
    name: str
    uid: str
    person_id: str
    person: Optional['Person'] = None
    members_count: Optional[int] = 0
    members: List[Member] = field(default_factory=list)
    organization_id: Optional[str] = None
    organization: Optional[PoolOrganization] = None


@dataclass
class InvitePerson:
    email: str
    first_name: str
    last_name: str
    middle_name: Optional[str]
    phone_number: Optional[str]
    source_platform: Optional[str]


@dataclass
class InviteApplication:
    state: str
    invite_id: str
    created_date: datetime
    person_id: str
    uid: str
    invite_name: Optional[str]
    person: Optional[InvitePerson]


@dataclass
class InviteData:
    state: str
    current_new_requests_count: int
    acceptance_strategy: str
    organization_id: str
    expired_date: Optional[datetime]
    uid: str
    current_requests_count: int
    invite_name: str
    max_requests_count: Optional[int]
    created_date: datetime
    author_id: str
    pools_to_assign: Optional[List[str]]
    auto_accept_emails: Optional[str]


@dataclass
class InviteRequest:
    acceptance_strategy: str
    organization_id: str
    invite_name: str
    state: Optional[str] = None
    max_requests_count: Optional[int] = None
    expired_date: Optional[datetime] = None
    pools_to_assign: Optional[List[str]] = None
    auto_accept_emails: Optional[str] = None


@dataclass
class MarkersError:
    email_list: List[str]
    error_message: str


@dataclass
class ErrorMarkersResponse:
    status: int
    errors: List[MarkersError]


# -----------------------------------------------------------------------------
#                                    PERSON
# -----------------------------------------------------------------------------


@dataclass
class Organization:
    uid: str
    name: str
    employ_date: Optional[datetime]
    employee_id: str
    roles: List[str] = field(default_factory=list)
    profile: Dict[str, Any] = field(default_factory=dict)
    report: Dict[str, Any] = field(default_factory=dict)
    config: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Person:
    email: str
    first_name: str
    last_name: str
    uid: str
    middle_name: Optional[str] = None
    organizations: Optional[List[Organization]] = None
    phone_number: Optional[str] = None
    source_platform: Optional[str] = None

    def get_organization(self, organization: str) -> Optional[Organization]:
        assert self.organizations
        for org in self.organizations:
            if organization in (org.uid, org.name):
                return org
        return None

    def get_fio(self) -> str:
        if self.middle_name:
            return self.first_name + ' ' + self.middle_name + ' ' + self.last_name
        else:
            return self.first_name + ' ' + self.last_name

    def get_roles(self, organization: str) -> Optional[List[str]]:
        org = self.get_organization(organization)
        return org.roles if org else None

    def get_config(self, organization: str) -> Optional[Dict[str, Any]]:
        org = self.get_organization(organization)
        return org.config if org else None

    def get_report(self, organization: str) -> Optional[Dict[str, Any]]:
        org = self.get_organization(organization)
        return org.report if org else None

    def get_profile(self, organization: str) -> Optional[Dict[str, Any]]:
        org = self.get_organization(organization)
        return org.profile if org else None


# -----------------------------------------------------------------------------
#                               MARKUP TASKS
# -----------------------------------------------------------------------------


@dataclass
class MarkupTask:
    id: str
    project_name: str
    assignment_timeout_seconds: float
    skippable: bool
    brief_url: str
    file_url: str
    form_url: str
    premarkup_url: str
    price: float
    item_id: str
    empty: bool = False

    @staticmethod
    def build_empty_task() -> 'MarkupTask':
        return MarkupTask(
            id='',
            project_name='',
            assignment_timeout_seconds=0,
            skippable=False,
            brief_url='',
            file_url='',
            form_url='',
            premarkup_url='',
            price=0,
            item_id='',
            empty=True,
        )


@dataclass
class MarkupReview:
    assignment_id: str
    status: str
    comment: Optional[str] = None
    quality: Optional[float] = None


@dataclass
class MarkupResultItem:
    id: str
    type: str
    file_name: str
    control: Optional[Dict]


@dataclass
class MarkupResult:
    id: str
    project_id: str
    task_id: str
    marker_id: str
    items: List[MarkupResultItem]
    status: str
    start_date: datetime
    end_date: Optional[datetime]
    quality: Optional[float]
    consistency: Optional[float]
    result: Optional[dict]
    submitted_at: Optional[datetime]
    accepted_at: Optional[datetime]
    skipped_at: Optional[datetime]
    expired_at: Optional[datetime]
    rejected_at: Optional[datetime]
    reviewer_id: Optional[str]
    reviewer_comment: Optional[str]


@dataclass
class MarkupResults:
    items: List[MarkupResult]
    has_next: bool


class MarkupResultSortField(Enum):
    ACCEPTED = 'accepted'
    CONSISTENCY = 'consistency'
    EXPIRED = 'expired'
    ITEM_ID = 'item_id'
    ITEM_TYPE = 'item_type'
    MARKUP_DURATION = 'markup_duration'
    QUALITY = 'quality'
    REJECTED = 'rejected'
    SKIPPED = 'skipped'
    STATUS = 'status'
    SUBMITTED = 'submitted'


class SortOrder(Enum):
    ASC = 'asc'
    DESC = 'desc'


@dataclass
class MarkupReviewResult:
    failed_assignment_ids: Optional[Dict[str, str]]


@dataclass
class MarkupTaskFile:
    name: str
    content_type: str
    content: StreamReader
    __bytes: Optional[bytes] = None

    async def read(self) -> bytes:
        if self.__bytes is None:
            self.__bytes = await self.content.read()

        return self.__bytes

    async def as_dict(self) -> Any:
        res = await self.read()
        return json.loads(res)

    async def save(self, path: Union[Path, str]) -> Path:
        path = Path(path)
        if path.is_dir():
            file_ext = guess_extension(self.content_type)
            path = path / f'{self.name}.{file_ext}'

        async with aiofiles.open(path, 'wb') as f:
            await f.write(await self.read())

        return path


@dataclass
class ProjectStat:
    avg_income: Optional[float]
    min_price: Optional[float]
    max_price: Optional[float]
    study_price: Optional[float]
    exam_price: Optional[float]


@dataclass
class TaskflowTaskData:
    id: str
    brief_url: str
    project_name: str
    description: str
    project_description: Optional[str]
    form_url: str
    price: float
    status: str
    type: str
    project_stat: ProjectStat
    is_auto_accept: bool


# -----------------------------------------------------------------------------
#                               MARKERS
# -----------------------------------------------------------------------------


@dataclass
class EmployeePool:
    name: str
    uid: str


@dataclass
class Assignment:
    file_name: str
    item_id: str
    marker_id: str
    organization_id: str
    person_id: str
    price: Optional[float]
    result: Optional[dict]
    status: str
    task_id: str
    start_date: datetime
    end_date: Optional[datetime] = None
    submitted_at: Optional[datetime] = None
    expired_at: Optional[datetime] = None
    skipped_at: Optional[datetime] = None
    accepted_at: Optional[datetime] = None
    rejected_at: Optional[datetime] = None
    item_type: Optional[str] = None
    control: Optional[dict] = None
    control_passed: Optional[Union[bool, float, int]] = None
    consistency: Optional[float] = None
    quality: Optional[float] = None
    assignment_id: Optional[str] = None
    time_spent: Optional[float] = None
    email: Optional[str] = None
    input_data: Optional[dict] = None
    enabled: Optional[bool] = True
    assignment_link: Optional[str] = None

    def get_safe_result_field(self, key: str) -> Any:
        if isinstance(self.result, dict):
            return self.result.get(key)
        return None

    def get_quality(self) -> Optional[float]:
        if self.quality is not None:
            return self.quality

        if self.control_passed is None:
            return None

        return 1 if self.control_passed else 0

    def to_skip_data(self) -> Dict[str, Any]:
        return {
            'pick_date': fmt_date(self.start_date),
            'submit_date': fmt_date(self.end_date),
            'price': self.price,
            'control': self.control,
            'control_passed': self.control_passed,
            'quality': self.get_quality(),
            'assignment_id': self.assignment_id,
            'pools': [],
        }

    def to_result_data(self) -> Dict[str, Any]:
        return {
            'pools': [],
            'pick_date': fmt_date(self.start_date),
            'submit_date': fmt_date(self.end_date),
            'price': self.price,
            'control': self.control,
            'control_passed': self.control_passed,
            'quality': self.get_quality(),
            'consistency': self.consistency,
            'result': self.result,
            'assignment_id': self.assignment_id,
        }

    def __post_init__(self) -> None:
        if not self.end_date:
            self.end_date = (
                self.submitted_at or self.accepted_at or self.expired_at or self.rejected_at or self.skipped_at
            )

        if isinstance(self.end_date, str):
            self.end_date = parse_date(self.end_date, datetime_formats=DATE_TIME_UTC_FORMATS)

    @staticmethod
    def from_assignment_data(
        user_id: str,
        item_data: TaskResult,
        assignment_data: dict,
        status: str,
    ) -> 'Assignment':
        item_id = item_data.entity_id
        task_id = item_data.task_id
        file_name = item_data.file_name
        item_type = item_data.entity_type
        person_id = item_data.person_id
        price = item_data.price
        organization_id = item_data.organization_id

        start_date = parse_date(assignment_data['pick_date'], datetime_formats=DATE_TIME_UTC_FORMATS)
        end_date = parse_date(assignment_data['submit_date'], datetime_formats=DATE_TIME_UTC_FORMATS)
        time_spent = round(float((end_date - start_date).total_seconds()), 2)

        if 'price' in assignment_data:
            price = assignment_data['price']

        if 'status' in assignment_data:
            status = assignment_data['status']

        if 'user_id' in assignment_data:
            user_id = assignment_data['user_id']

        assignment_id = md5_str(item_id + user_id)

        consistency = None
        quality: Optional[float] = None
        control = None
        if status == 'accepted':
            if 'control' in assignment_data:
                control = assignment_data['control']
            if 'assignment_id' in assignment_data:
                assignment_id = assignment_data['assignment_id']
            if 'control_passed' in assignment_data:
                if isinstance(assignment_data['control_passed'], bool):
                    quality = 1 if assignment_data['control_passed'] else 0
                if isinstance(assignment_data['control_passed'], float):
                    quality = assignment_data['control_passed']
                if isinstance(assignment_data['control_passed'], int):
                    quality = float(assignment_data['control_passed'])

            if 'consistency' in assignment_data:
                consistency = assignment_data['consistency']

        return Assignment(
            organization_id=organization_id,
            item_id=item_id,
            file_name=file_name,
            start_date=start_date,
            end_date=end_date,
            marker_id=user_id,
            person_id=person_id,
            status=status,
            price=price or 0,
            result=assignment_data['result'],
            consistency=consistency,
            control=control,
            control_passed=quality,
            quality=assignment_data.get('quality', quality),
            item_type=item_type,
            task_id=task_id,
            assignment_id=assignment_id,
            time_spent=time_spent,
        )


class PluginTypes(Enum):
    CUSTOMER = 'CUSTOMER'
    MARKER = 'MARKER'


@dataclass
class Plugin:
    type: PluginTypes
    route: str
    icon: str
    title: str
    bundle: str
    data: Optional[dict]


@dataclass
class Employee:
    person_id: str
    organization_id: str
    uid: str
    employ_date: Optional[datetime]
    active: bool
    roles: Optional[List[str]] = None
    profile: Dict[str, Any] = field(default_factory=dict)
    report: Dict[str, Any] = field(default_factory=dict)
    config: Dict[str, Any] = field(default_factory=dict)
    person: Optional[Person] = None
    pools: Optional[List[EmployeePool]] = None


# -----------------------------------------------------------------------------
#                               UI
# -----------------------------------------------------------------------------


class FileType(Enum):
    CONTROL = 'CONTROL'
    STUDY = 'STUDY'
    DATA = 'DATA'


class MetaType(Enum):
    CONTROL = 'control'
    PREMARKUP = 'premarkup'
    EXPLANATION = 'explanation'


@dataclass
class TaskFile:
    content_type: str
    name: str
    size: int
    metadata: List[MetaType]
    bucket: str
    hashsum: Optional[str]
    data: Optional[str]
    uid: str
    file_type: FileType
    enabled: Optional[bool]


@dataclass
class DatasetFile:
    url: str
    name: str
    id: str


@dataclass
class SPInfo:
    report_url: str
    checking_files_count: int
    rejected_files_count: int
    error_files_count: int


@dataclass
class MetaData:
    control: Optional[dict] = None
    premarkup: Optional[dict] = None
    explanation: Optional[Any] = None


@dataclass
class FileMetaData:
    file_id: str
    filehash: Optional[str] = None
    premarkup: Optional[dict] = None
    control: Optional[dict] = None
    explanation: Optional[Any] = None


@dataclass
class UpdateMetaDataRequest:
    data: MetaData
    fileId: Optional[str] = None
    filename: Optional[str] = None


@dataclass
class File:
    filename: str
    uid: str


@dataclass
class FileError:
    filename: str
    status: int
    error: str


@dataclass
class UploadFilesResult:
    created_files: List[File]
    errors: List[Union[FileError, str]]


# -----------------------------------------------------------------------------
#                               SKILLS
# -----------------------------------------------------------------------------


@dataclass
class Skill:
    uid: str
    name: str
    person_id: str
    window_size: Optional[int] = 64
    enabled: bool = True
    organization_id: Optional[str] = None
    marker_count: Optional[int] = None
    created_date: Optional[datetime] = None


@dataclass
class MarkerSkill:
    uid: str
    name: str
    person_id: str
    organization_id: str
    value: int
    created_date: Optional[datetime]
    person: Optional[Person]


@dataclass
class SetMarkerSkillResponse:
    value: int
    person_id: str
    skill_id: str


@dataclass
class MarkerSkillDataError:
    code: str
    message: str
    value: Optional[Any]
    row: int


@dataclass
class MarkerSkillUpdated:
    person: str
    skill: str
    row: int


@dataclass
class SetMarkersSkillsResponse:
    data_errors: Optional[List[MarkerSkillDataError]]
    updated_skills: List[MarkerSkillUpdated]


# -----------------------------------------------------------------------------
#                               ORGANIZATIONS
# -----------------------------------------------------------------------------


@dataclass
class OrganizationConfig:
    help_center_url: Optional[str]
    marker_faq_url: Optional[str]
    price_instruction_lnk: Optional[str]


@dataclass
class OrganizationEmployee:
    first_name: str
    last_name: str
    uid: str


@dataclass
class FullOrganization:
    uid: str
    name: str
    creation_date: Optional[datetime] = None
    config: Optional[OrganizationConfig] = None
    active_employees_cnt: Optional[int] = None
    all_employees_cnt: Optional[int] = None
    employees: Optional[List[OrganizationEmployee]] = None

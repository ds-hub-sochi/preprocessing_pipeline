import os
from dataclasses import dataclass
from getpass import getpass
from pathlib import Path
from typing import Dict, Optional, Union

import yaml

from crowd_sdk import DEFAULT_CONFIG
from crowd_sdk.core.config import CrowdConfig
from crowd_sdk.core.utils.common import AuthConfig, dataclass_to_dict, logger
from crowd_sdk.core.utils.http import DEFAULT_RATE_LIMIT

with open(Path(__file__).parent.absolute() / 'stands.yaml') as f:
    STANDS_URLS_DICT: Dict[str, str] = yaml.safe_load(f)


SECTION_NAME = 'tagme'
STANDS = list(STANDS_URLS_DICT.keys())
DEFAULT_CLIENT_ID = 'tagme'
LEGACY_CLIENT_ID = 'web-ui'
ALLOWED_CLIENT_IDS = [DEFAULT_CLIENT_ID, LEGACY_CLIENT_ID]


@CrowdConfig.crowd_config_section(SECTION_NAME)
@dataclass
class TagmeConfig(AuthConfig):
    stand: Optional[str] = None
    org: Optional[str] = None
    data_category: Optional[str] = None
    data_source: Optional[str] = None
    sentry_dsn: Optional[str] = None
    disable_sentry: bool = True
    sentry_debug: bool = False
    rate_limit: int = DEFAULT_RATE_LIMIT

    def __post_init__(self) -> None:
        if self.url and self.url.endswith('api/v0'):
            self.url = self.url[: -len('api/v0')]
        if not self.client_id:
            self.client_id = DEFAULT_CLIENT_ID
        if not self.url or not self.auth_url:
            assert self.stand, 'Specify tagme.stand or (tagme.url + tagme.auth_url), none of them specified.'
            assert self.stand in STANDS_URLS_DICT, f'Given tagme.stand={self.stand} not in available stands {STANDS}'

            self.url = STANDS_URLS_DICT[self.stand]
            self.auth_url = STANDS_URLS_DICT[self.stand]

        else:
            url_ = self.url.rstrip('/')
            for stand, urls in STANDS_URLS_DICT.items():
                if urls == url_:
                    self.stand = stand
                    break

            else:
                self.stand = 'unknown'
                logger.warning(f'unknown stand with baseurl "{self.url}"')

        assert (
            self.client_id in ALLOWED_CLIENT_IDS
        ), f'client_id={self.client_id} not in allowed list: {ALLOWED_CLIENT_IDS}'

        self.prompt_user_and_password_if_missing()

        super().__post_init__()

    def to_dict(self) -> dict:
        return dataclass_to_dict(self)

    @staticmethod
    def from_any(  # type: ignore[override]
        config: Union[str, Path, dict, 'CrowdConfig', 'TagmeConfig'] = DEFAULT_CONFIG,
    ) -> 'TagmeConfig':
        config_path = ''  # for logging purposes, will not show any if no path specified
        if isinstance(config, (str, Path)):
            config_path = str(config)
            config = CrowdConfig.from_path(config)
        elif isinstance(config, dict):
            config = CrowdConfig.from_dict(data=config)

        if isinstance(config, CrowdConfig):
            assert config.tagme is not None, f'Fill section tagme in {config} {config_path}'
            return config.tagme

        if isinstance(config, TagmeConfig):
            return config

        raise TypeError(f'Wrong type for the config {type(config)}')

    @staticmethod
    def cli_initialize(
        config: Union[str, Path, dict, 'CrowdConfig', 'TagmeConfig'] = DEFAULT_CONFIG,
        organization_name: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> 'TagmeConfig':
        result = TagmeConfig.from_any(config)
        result.prompt_user_and_password_if_missing()
        assert (
            organization_id is None or organization_name is None
        ), 'Do not specify both organization_id and organization_name in config'
        if organization_name is not None:
            result.org = organization_name
        return result

    def prompt_user_and_password_if_missing(self) -> None:
        if self.client_secret or self.client_cert_path:
            return

        if not self.user:
            if os.environ.get('TAGME_USERNAME'):
                self.user = os.environ.get('TAGME_USERNAME')
            else:
                self.user = input('TagMe username: ')
                os.environ['TAGME_USERNAME'] = self.user

        if not self.password:
            if os.environ.get('TAGME_PASSWORD'):
                self.password = os.environ.get('TAGME_PASSWORD')
            else:
                self.password = getpass(prompt='TagMe password: ')
                os.environ['TAGME_PASSWORD'] = self.password


CrowdTagmeConfig = TagmeConfig

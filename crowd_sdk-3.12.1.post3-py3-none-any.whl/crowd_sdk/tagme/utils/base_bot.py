import asyncio
import logging
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Type, Union

from dacite import from_dict
from tqdm import tqdm

from crowd_sdk.core.utils.http_client import HttpWrapper, ResponseType
from crowd_sdk.core.utils.os import TempDir
from crowd_sdk.tagme import TagmeBotClient
from crowd_sdk.tagme.config import DEFAULT_CONFIG, CrowdConfig, TagmeConfig
from crowd_sdk.tagme.types import MarkupTask

logger = logging.getLogger(__name__)


@dataclass
class BotTaskConfig:
    result_field: str
    task_type: str
    enable: bool = False
    instruction: Any = None


@dataclass
class RunStats:
    solved_count: int = 0
    error_count: int = 0
    task_count: int = 0


class TagmeBaseBot:
    INTERVAL: int = 30
    _task_handlers: Dict[str, Callable]

    def __init__(
        self,
        config: Union[str, Path, CrowdConfig, TagmeConfig] = DEFAULT_CONFIG,
        http: Optional[HttpWrapper] = None,
        task_handlers: Optional[Dict[str, Callable]] = None,
    ):
        self.client = TagmeBotClient(config=config, http=http)
        self._task_handlers = task_handlers or {}
        self._cache: dict = {}

    def set_task_handler(self, task_type: str, handler: Callable) -> None:
        self._task_handlers[task_type] = handler

    async def handle_task(self, task: MarkupTask, tmp_dir: str, task_config: BotTaskConfig) -> Any:
        for task_type, handler in self._task_handlers.items():
            if task_config.task_type == task_type:
                return await handler(task=task, tmp_dir=tmp_dir, task_config=task_config)

    @staticmethod
    async def build_markup_result(result: Any, task_config: BotTaskConfig) -> Dict:
        if not isinstance(result, (str, int, float, dict)):
            raise NotImplementedError

        return {task_config.result_field: result}

    async def get_task_config(  # pylint: disable=no-self-use
        self, task_form: Any, instruction: Any, config_cls: Type[BotTaskConfig] = BotTaskConfig
    ) -> BotTaskConfig:
        task_payload = task_form.get('config', {})
        bot_config = from_dict(config_cls, task_payload.get('bot', {}))
        bot_config.instruction = instruction
        return bot_config

    async def get_cached_url(
        self, url: str, ttl: int = 60, response_type: ResponseType = ResponseType.JSON_RESPONSE
    ) -> Any:
        if url in self._cache:
            content, lastget = self._cache[url]
            if datetime.utcnow() < lastget + timedelta(seconds=ttl):
                return content
        content = await self.client.client.get(url, response_type=response_type)
        if response_type == ResponseType.RAW_RESPONSE:
            content = content.decode('utf-8')
        self._cache[url] = (content, datetime.utcnow())
        return content

    async def run_once(self) -> RunStats:
        stats = RunStats()
        try:
            tasks = await self.client.get_tasks()
        except Exception:  # pylint: disable=broad-except
            logger.exception('Error while getting tasks')
            return stats

        for t in tasks:
            if t.status != 'RUN':
                continue

            try:
                logger.info(t.id)
                task_form = await self.get_cached_url('api/v0/' + t.form_url.strip('/'))
                instruction = await self.get_cached_url(
                    'api/v0/' + t.brief_url.strip('/'), response_type=ResponseType.RAW_RESPONSE
                )
                task_config = await self.get_task_config(task_form, instruction)
                if not task_config.enable:
                    continue

                stats.task_count += 1
                with tqdm(unit='task') as counter:
                    with TempDir() as tmp_dir:
                        while True:
                            task = await self.client.get_markup_task(t.id)
                            if task.empty:
                                break

                            try:
                                result = await self.handle_task(task=task, tmp_dir=tmp_dir, task_config=task_config)
                                markup_result = await self.build_markup_result(result=result, task_config=task_config)
                                stats.solved_count += 1

                            except ValueError as e:
                                markup_result = {'success': False, 'error': str(e)}
                                stats.error_count += 1

                            await self.client.submit_markup_task(t.id, task.id, markup_result)
                        counter.update()

            except Exception:  # pylint: disable=broad-except
                logger.exception(f'Error with task {t.id}')

        return stats

    async def serve_forever(self) -> None:
        while True:
            stats = await self.run_once()
            logger.info(str(stats))
            await asyncio.sleep(self.INTERVAL)

import asyncio
import json
import logging
import sys
from collections import defaultdict
from enum import Enum
from hashlib import md5
from itertools import chain
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple, Union

from dacite import Config, DaciteError, from_dict
from tqdm import tqdm

from crowd_sdk.core.utils.common import cast_params, dataclass_to_dict, merge
from crowd_sdk.core.utils.http_client import APIResponseError, HttpWrapper
from crowd_sdk.core.utils.jwt_client import ResponseType
from crowd_sdk.core.utils.os import TempDir
from crowd_sdk.tagme import TagmeClientAdvanced
from crowd_sdk.tagme.config import DEFAULT_CONFIG, CrowdConfig, TagmeConfig
from crowd_sdk.tagme.types import Dataset, MetaType, Project, TaskData, TaskDataRequest, TaskFile, TaskResult, TaskState
from crowd_sdk.tagme.utils.datacls import AggregatedResults, ConsistencyFilter, ResultAggregation, SyncSettings
from crowd_sdk.tagme.utils.quality import filter_dict, get_dict_hash

logger = logging.getLogger(__name__)


def get_value(src: List[str], task_data: dict, result: Union[dict, AggregatedResults]) -> Any:
    if src[0] == 'file.url':
        value = task_data['file.url']
    elif src[0] == 'file':
        value = json.loads(task_data['file_data'])
    elif src[0] == 'result':
        value = result
    elif src[0] == 'premarkup':
        value = task_data['premarkup']
    else:
        raise NotImplementedError(f'src={src[0]}')

    for key in src[1:]:
        value = value.get(key)

    return value


def aggregate_result(consistency_table: Dict[str, int], hash_result: Dict[str, dict], total: int) -> AggregatedResults:
    results = AggregatedResults()
    for k, v in consistency_table.items():
        results.add(weight=v / total, result=hash_result[k])

    return results


def is_successful(x: Dict) -> bool:
    return x.get('success', True)


def do_nothing(_x: Dict) -> bool:
    return True


class TagmePipeline:
    _result_filters: Dict[str, Callable[[Dict], bool]] = {
        'is_successful': is_successful,
        'all': do_nothing,
    }

    def __init__(
        self,
        executor: str,
        config: Union[str, Path, CrowdConfig, TagmeConfig] = DEFAULT_CONFIG,
        http: Optional[HttpWrapper] = None,
        client: Optional[TagmeClientAdvanced] = None,
        scan_delay: int = 600,
    ) -> None:
        self.executor = executor
        self.client = client or TagmeClientAdvanced(config=config, http=http)
        self._task_scheduled: List[TaskData] = []
        self.scan_delay = scan_delay

    @classmethod
    def register_result_filter(cls, name: str, handler: Callable[[Dict], bool]) -> None:
        cls._result_filters[name] = handler

    @staticmethod
    def strip_filename(fname: str, is_target: bool = False) -> str:
        if fname.endswith('.json'):
            fname = fname[: -len('.json')]
        if is_target:
            return fname.split('_', 1)[-1]
        return fname

    async def prepare_data(
        self,
        target_task: TaskData,
        source_task: TaskData,
        sync_settings: SyncSettings,
        tmp_dir: str,
        limit: Optional[int] = None,
    ) -> List[dict]:
        source_task_results = await self.client.get_task_results(source_task.uid)
        if not source_task_results:
            return []

        json_data: List[dict] = []
        target_task_filenames = {
            self.strip_filename(target_file.name, is_target=True)
            for target_file in await self.client.get_task_files(task_id=target_task.uid)
        }

        for item in tqdm(source_task_results):  # type: TaskResult
            if self.strip_filename(item.file_name) in target_task_filenames:
                continue

            if source_task.overlap > len(item.result):
                continue

            json_data.extend(await self.process_item(item, sync_settings, tmp_dir))

            if limit is not None and len(json_data) >= limit:
                break

        if not json_data:
            logger.info(f'nothing to upload for task "{target_task.name}" ({target_task.uid})')

        index = target_task.estimated_files_count or 0
        for i, data in enumerate(json_data, index):
            data['id'] = f'{i}_{data["id"]}'

        return json_data

    async def load_task_data(self, item: Union[TaskResult, TaskFile], with_premarkup: bool = False) -> dict:
        if isinstance(item, TaskResult):
            task_id, entity_id, file_name = item.task_id, item.entity_id, item.file_name
        else:
            task_id, entity_id, file_name = item.bucket, item.uid, item.name

        file_data = await self.client.download_file(task_id, entity_id)
        result: Dict[str, Any] = {'file_name': file_name, 'file_data': file_data, 'task_id': task_id}
        if with_premarkup:
            meta = await self.client.get_meta_data(task_id, entity_id, types=[MetaType.PREMARKUP])
            if not meta or not meta.premarkup:
                raise ValueError(f'not found required premarkup in item {entity_id} of task {task_id}')

            result['premarkup'] = meta.premarkup

        return result

    async def get_dataset(self, task_id: str) -> Dataset:
        ds: Optional[Dataset] = None
        for dataset in await self.client.get_datasets(query=f'pipeline_{task_id}'):
            if dataset.name == f'pipeline_{task_id}':
                ds = dataset
                break
        else:
            ds = await self.client.create_dataset(name=f'pipeline_{task_id}')

        return ds

    async def upload_file_data(self, file_path: Union[str, Path], task_id: str) -> str:
        file_path = str(file_path)
        ds = await self.get_dataset(task_id)
        files = await self.client.upload_dataset_files(ds.id, filepaths=[file_path])
        assert len(files.created_files) == 1

        if files.errors:
            raise ValueError(f'Can\'t upload {file_path} to {ds.id}: {files.errors}')

        return self.client.gen_file_url(files.created_files[0].uid)

    async def upload_attachment(self, url: str, prefix: str, base_path: str, task_id: str) -> str:
        organization_id = await self.client.get_current_organization_id()
        unique_filename = md5(url.encode()).hexdigest() + '.wav'
        with open(Path(base_path) / unique_filename, 'wb') as f:
            file_data = await self.client.client.get(
                url=url[len(prefix) :],
                response_type=ResponseType.RAW_RESPONSE,
                params=cast_params(organization_id=organization_id),
            )

            f.write(file_data)

        return await self.upload_file_data(Path(base_path) / unique_filename, task_id)

    async def result_to_data(
        self,
        result: Union[dict, AggregatedResults],
        task_data: dict,
        sync_settings: SyncSettings,
        base_path: str,
        extra_fields: Optional[dict] = None,
    ) -> dict:
        file_name = task_data['file_name']
        file_data = task_data['file_data']
        task_id = task_data['task_id']
        data = {'id': file_name}

        for src_, dst_ in sync_settings.fields:
            src, dst = src_.split('.'), dst_.split('.')

            if src == ['file']:  # binary
                unique_filename = md5(file_data).hexdigest()
                with open(Path(base_path) / unique_filename, 'wb') as f:
                    f.write(file_data)
                if dst == ['file']:
                    data['upload_file'] = unique_filename
                    continue

                task_data['file.url'] = await self.upload_file_data(Path(base_path) / unique_filename, task_id)
                src = ['file.url']

            if dst[0] == 'file':
                dst[0] = 'task'

            target = data
            for key in dst[:-1]:
                target = target.setdefault(key, {})
            target_value = get_value(src, task_data, result)
            if (
                isinstance(target_value, str)
                and target_value.startswith('https://tagme.sberdevices.ru/')
                and '/attachment/' in target_value
            ):
                target_value = await self.upload_attachment(
                    target_value, 'https://tagme.sberdevices.ru/', base_path, task_id
                )
                base_url = self.client.client.get_base_url().rstrip('/') + '/'
                if base_url != 'https://tagme.sberdevices.ru/':
                    target_value = target_value.replace(base_url, 'https://tagme.sberdevices.ru/')
            target[dst[-1]] = target_value

        if extra_fields:
            data.setdefault('premarkup', {}).update(extra_fields)

        if 'task' in data and 'upload_file' in data:
            raise ValueError('incorrect fields in pipeline config')

        return data

    async def process_item(self, item: TaskResult, sync_settings: SyncSettings, tmp_dir: str) -> List[dict]:
        hash_result: Dict[str, dict] = {}
        consistency_table: Dict[str, int] = defaultdict(int)

        # Filter Assignments if needed
        assert sync_settings.result_filter in self._result_filters, (
            f'No assignments filter "{sync_settings.result_filter}" registered in '
            f'TagmePipeline._result_filters: {list(TagmePipeline._result_filters.keys())}'
        )
        result_filter = self._result_filters[sync_settings.result_filter]
        results = [x['result'] for x in item.result.values() if result_filter(x['result'])]

        # Filter Item if needed
        total = len(results)
        if not results:
            return []

        for result in results:
            if sync_settings.ignore_fields:
                filter_dict(result, sync_settings.ignore_fields, 1)

            hash_ = get_dict_hash(result)
            consistency_table[hash_] += 1
            if hash_ not in hash_result:
                hash_result[hash_] = result

        extra_fields = {
            'source_entity_id': item.entity_id,
            'source_task_id': item.task_id,
            'source_file_name': item.file_name,
        }

        if sync_settings.consistency_filter == ConsistencyFilter.UNSURE:
            # TODO should validate all results or most consistent for unsure?
            # TODO более глубокий анализ результатов на консистентность
            assert sync_settings.consistency_share_threshold is not None
            max_share = max(consistency_table.values()) / total
            if max_share >= sync_settings.consistency_share_threshold:
                return []

        elif sync_settings.consistency_filter != ConsistencyFilter.ALL_UNIQUE:
            raise NotImplementedError

        # Aggregate, transform
        if sync_settings.result_aggregation == ResultAggregation.SEPARATE:
            values = hash_result.values()  # type: Iterable
        elif sync_settings.result_aggregation == ResultAggregation.AGGREGATE:
            values = (aggregate_result(consistency_table, hash_result, total),)
        else:
            raise NotImplementedError

        task_data = await self.load_task_data(
            item, with_premarkup=any(x[0].startswith('premarkup.') for x in sync_settings.fields)
        )
        return [await self.result_to_data(v, task_data, sync_settings, tmp_dir, extra_fields) for v in values]

    def check_executor(self, config: Optional[dict]) -> bool:
        conf_executor = None
        if isinstance(config, dict):
            conf_executor = config.get('pipeline', {}).get('executor')

        return conf_executor == self.executor or (conf_executor is None and self.executor == 'tagme')

    async def _create_task_from_source(
        self, task: TaskData, project_id: str, organization_id: str, base_task: Optional[TaskData] = None
    ) -> TaskData:
        new_task_request = TaskDataRequest(
            organization_id=organization_id,
            project_id=project_id,
            name=task.name,
            description=f'validation for {task.description}',
            data_source=task.data_source,
            data_classification_level=task.data_classification_level,
            depersonalize=task.depersonalize,
        )

        if base_task:
            new_task_request.control_count = base_task.control_count
            new_task_request.control_fraction = base_task.control_fraction
            new_task_request.out_skill_id = base_task.out_skill_id
            new_task_request.expected_consistency = base_task.expected_consistency
            new_task_request.expected_quality = base_task.expected_quality
            new_task_request.filter = base_task.filter
            new_task_request.overlap = base_task.overlap
            new_task_request.description = base_task.description
            new_task_request.price = base_task.price
            new_task_request.skip_strategy = base_task.skip_strategy
            new_task_request.item_timeout_seconds = base_task.item_timeout_seconds

        new_task = await self.client.create_task(new_task_request)
        new_task.payload = await self.client.set_task_payload(new_task.uid, {'pipeline': {'source_task': task.uid}})
        if not new_task.payload:
            await self.client.load_task_payload(new_task)

        return new_task

    async def _process_source_tasks(
        self,
        project_id: str,
        organization_id: str,
        source_proj_tasks: List[TaskData],
        target_links: set,
        config: Dict[str, dict],
        project_task_map: Dict[str, List[TaskData]],
        tasks: List[TaskData],
        base_task: Optional[TaskData] = None,
    ) -> None:
        for task in source_proj_tasks:
            if task.organization_id != organization_id:
                logging.warning(f"Task {task.uid} not in organization {organization_id}")
                continue

            if task.uid not in target_links and task.name not in target_links:
                try:
                    new_task = await self._create_task_from_source(
                        task=task,
                        project_id=project_id,
                        organization_id=organization_id,
                        base_task=base_task,
                    )
                except APIResponseError:
                    logging.warning(f"Failed to bind with source task {task.uid}")
                    continue

                logger.info('created new task %s', new_task)

                if new_task.payload is not None:
                    merge(new_task.payload, config, override=False)

                tasks.append(new_task)
                project_task_map[project_id].append(new_task)

    async def _get_project_organization_id(self, project_id: str, projects: Dict[str, Project]) -> str:
        if project_id in projects:
            return projects[project_id].organization_id

        project = await self.client.get_project(project_id=project_id)
        return project.organization_id

    async def _check_projects_organizations(
        self, target_project_id: str, source_project_id: str, projects: Dict[str, Project]
    ) -> None:
        target_organization_id = await self._get_project_organization_id(target_project_id, projects)
        source_organization_id = await self._get_project_organization_id(source_project_id, projects)

        if target_organization_id != source_organization_id:
            raise RuntimeError(
                f"Target project {target_project_id} and source project {source_project_id} "
                f"are not in the same organization"
            )

    async def scan_project_tasks(
        self,
        project_ids: Sequence[str] = None,
    ) -> List[TaskData]:
        organization_id = await self.client.get_current_organization_id()
        tasks: List[TaskData] = []

        projects: Dict[str, Project] = {
            p.uid: p
            for p in await self.client.get_projects_advanced(
                project_ids=project_ids,
                organization_id=organization_id,
                with_pipeline=True,
                archived=False,
                is_pipelined=True,
            )
        }
        project_pipelines = {
            p.uid: {"pipeline": p.pipeline} for p in projects.values() if p.pipeline and p.is_pipeline_enabled
        }  # type: ignore[union-attr]

        tasks.extend(
            await self.client.get_tasks_advanced(
                project_ids=list(projects.keys()),
                with_payload=True,
                with_empty=True,
                with_project_pipeline=project_pipelines,
            )
        )
        project_task_map: Dict[str, List[TaskData]] = defaultdict(list)
        for task in tasks:
            project_task_map[task.project_id].append(task)

        for project_id, config_ in list(project_pipelines.items()):
            if 'pipeline' not in config_:
                continue

            try:
                config = from_dict(data_class=SyncSettings, data=config_['pipeline'], config=Config(cast=[Enum, Tuple]))
                if not config.source_project or not config.auto_create_task:
                    continue

            except (AssertionError, DaciteError):
                continue

            try:
                await self._check_projects_organizations(project_id, config.source_project, projects)
            except (APIResponseError, RuntimeError) as ex:
                logging.warning(ex)
                continue

            if config.source_project not in project_task_map:
                try:
                    project_task_map[config.source_project] = await self.client.get_tasks(
                        project_id=config.source_project, organization_id=organization_id
                    )
                except APIResponseError as ex:
                    logging.warning(f"Project {project_id}: {ex}")
                    continue

            source_proj_tasks = project_task_map[config.source_project]
            target_proj_tasks = project_task_map[project_id]
            target_links = set(
                chain(
                    *[
                        (t.payload.get('pipeline', {}).get('source_task'), t.name)
                        for t in target_proj_tasks
                        if t.payload and self.check_executor(t.payload)
                    ]
                )
            )
            base_task = None
            if config.base_task:
                try:
                    base_task = await self.client.get_task(task_id=config.base_task)
                except APIResponseError:
                    logging.warning(f"Project {project_id}: {config.base_task}")
                    continue

            await self._process_source_tasks(
                project_id=project_id,
                organization_id=projects[project_id].organization_id,
                source_proj_tasks=source_proj_tasks,
                target_links=target_links,
                config=config_,
                project_task_map=project_task_map,
                tasks=tasks,
                base_task=base_task,
            )

        return tasks

    async def scan_tasks(
        self,
        task_ids: Optional[Sequence[str]] = None,
        project_ids: Optional[Sequence[str]] = None,
    ) -> List[TaskData]:
        tasks: List[TaskData] = []

        if task_ids:
            tasks.extend(
                await self.client.get_tasks_advanced(
                    task_ids=task_ids, with_payload=True, with_empty=True, with_project_pipeline=True
                )
            )

        if not task_ids or project_ids:
            tasks.extend(await self.scan_project_tasks(project_ids=project_ids))

        self._task_scheduled = tasks
        return tasks

    async def process_pipeline(self, task: TaskData, dry_run: bool = False, limit: Optional[int] = None) -> None:
        if not task.payload or not task.payload.get('pipeline'):
            return

        sync_settings = from_dict(
            data_class=SyncSettings, data=task.payload['pipeline'], config=Config(cast=[Enum, Tuple])
        )

        logger.info((task.uid, task.name, sync_settings))
        if sync_settings.source_project and not sync_settings.source_task:
            source_task_query = await self.client.get_tasks(
                project_id=sync_settings.source_project, query=f'{task.name}'
            )
            source_task_query = [x for x in source_task_query if x.name == task.name]
            if not source_task_query:
                return

            source_task = source_task_query[0]

        else:
            source_task = await self.client.get_task(sync_settings.source_task)  # type: ignore[arg-type]

        if source_task.organization_id != task.organization_id:
            logging.warning(f"Task {source_task.uid} not in organization {task.organization_id}")
            return

        with TempDir() as tmp_dir:
            json_data = await self.prepare_data(task, source_task, sync_settings, tmp_dir, limit)
            if not json_data:
                return

            if dry_run:
                json.dump(json_data, sys.stdout, ensure_ascii=False, indent=2)
                return

            started = task.state == TaskState.RUNNING
            if started:
                await self.client.stop_task(task_id=task.uid)

            if sync_settings.auto_start_task and task.state in (TaskState.DONE, TaskState.INITIAL):
                started = True

            await self.client.upload_json_data(
                task_id=task.uid,
                json_data=json_data,
                base_path=tmp_dir,
            )

            if started:
                try:
                    await self.client.start_task(task_id=task.uid)
                except APIResponseError as exc:
                    logger.error(f'failed to start task {task.uid}: {exc.json_error}')

    async def process_tasks(
        self,
        tasks: List[TaskData],
        dry_run: bool = False,
        limit: Optional[int] = None,
        batch_size: int = 4,  # pylint: disable=unused-argument
    ) -> None:
        # TODO(volerog): use aiopool for parallel run
        # with AIOPool(workers=batch_size) as pool:
        #     async for _result in pool.map_async(self.process_pipeline, map(lambda x: (x, dry_run, limit), tasks)):
        #         pass

        for task in tasks:
            try:
                await self.process_pipeline(task, dry_run, limit)
            except Exception as ex:  # pylint: disable=broad-except
                logging.error(f"Failed to process task {task.uid}: {ex}")

    async def link(
        self,
        source_task: Union[str, TaskData],
        target_task: Union[str, TaskData],
        config: Union[dict, SyncSettings],
    ) -> None:
        if isinstance(target_task, str):
            target_task = await self.client.get_task(task_id=target_task)

        if isinstance(source_task, str):
            source_task = await self.client.get_task(task_id=source_task)

        if source_task.organization_id != target_task.organization_id:
            raise RuntimeError("Source and target tasks must be in the same organization")

        if isinstance(config, SyncSettings):
            config = dataclass_to_dict(config)

        config['source_task'] = source_task.uid
        config['executor'] = config['executor'] or self.executor

        await self.client.set_task_payload(target_task.uid, {'pipeline': config})
        # Markup results transfer
        await self.client.load_task_payload(target_task)
        self._task_scheduled.append(target_task)

    async def run_once(self) -> None:
        await self.process_tasks(self._task_scheduled)

    async def run(
        self,
        task_ids: Optional[Sequence[str]] = None,
        project_ids: Optional[Sequence[str]] = None,
    ) -> None:
        while True:
            await self.scan_tasks(task_ids, project_ids)
            await self.run_once()
            await asyncio.sleep(self.scan_delay)
